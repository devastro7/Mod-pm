#include "ModData.h"

#include "pch.h"

#include <mod/amlmod.h>
#include <sys/stat.h>
#include "IniReaderWriter.hpp"
#include <fstream>

#include "Callouts.h"

ModData::ModData(std::string folderName)
{
    std::string dataRootPath = aml->GetAndroidDataRootPath();

    // Cria pasta principal do mod
    CreateFolder(dataRootPath + "/mods/mods_data/" + folderName + "/");

    // Cria pasta de logs
    CreateFolder(dataRootPath + "/mods/mods_data/logs/");

    this->modFolderPath = dataRootPath + "/mods/mods_data/" + folderName + "/";
}

std::string ModData::GetFileFromAssets(const std::string& localPath)
{
    // Retorna o caminho completo de um arquivo dentro de mods_data/assets/
    return modFolderPath + "/assets/" + localPath;
}

std::string ModData::GetFile(const std::string& localPath)
{
    // Retorna o caminho completo de um arquivo dentro da pasta do mod
    return modFolderPath + "/" + localPath;
}


std::string ModData::GetFileFromMenuSZK(const std::string& localPath)
{
    std::string dataRootPath = aml->GetAndroidDataRootPath();
    std::string menuSZKPath = dataRootPath + "/mods/mods_data/" + "menuSZK" + "/";

    return menuSZKPath + localPath;
}

void ModData::LoadSettings()
{
    auto pathSettings = GetFile("settings.ini");

    // Se nao existe, cria com defaults
    if(!file_exists(pathSettings))
    {
        SaveSettings();
        return;
    }

    IniReaderWriter ini;
    ini.LoadFromFile(pathSettings);

    CHASE_VEHICLE_MAX_SPEED = ini.GetInt("settings", "chase_vehicle_max_speed", CHASE_VEHICLE_MAX_SPEED);
    CHASE_POLICE_MAX_SPEED = ini.GetInt("settings", "chase_police_max_speed", CHASE_POLICE_MAX_SPEED);
    CHASE_MIN_TIME_TO_SURRENDER = ini.GetInt("settings", "chase_minimum_time_to_surrender", CHASE_MIN_TIME_TO_SURRENDER);
    g_secondsBetweenCallouts = ini.GetInt("settings", "seconds_between_callouts", g_secondsBetweenCallouts);
    CREATE_INJURED_PED = ini.GetBool("settings", "create_injured_ped", CREATE_INJURED_PED);
    DISABLE_CALLOUTS_RADIO_SOUND = ini.GetBool("settings", "disable_callouts_radio_sound", DISABLE_CALLOUTS_RADIO_SOUND);

    // Logs (0 = desativado, melhora FPS quando ambos em 0)
    g_enableLog = ini.GetBool("settings", "enable_log", g_enableLog);
    g_enableDeepLog = ini.GetBool("settings", "enable_deeplog", g_enableDeepLog);

    RADIO_PLAY_ACCEPT_CALLOUT_SOUND = ini.GetBool("radio", "play_accept_callout_sound", RADIO_PLAY_ACCEPT_CALLOUT_SOUND);
    RADIO_CALLOUT_VOLUME = ini.GetInt("radio", "callout_volume", RADIO_CALLOUT_VOLUME);
    RADIO_CALLOUT_DISTANCE = ini.GetInt("radio", "callout_distance", RADIO_CALLOUT_DISTANCE);
    RADIO_VEHICLE_RADIO_ENABLED = ini.GetBool("radio", "vehicle_radio_enabled", RADIO_VEHICLE_RADIO_ENABLED);
    RADIO_SOUND_INDEX = ini.GetInt("radio", "sound_index", RADIO_SOUND_INDEX);
    RADIO_SOUND_VOLUME = ini.GetInt("radio", "sound_volume", RADIO_SOUND_VOLUME);
    RADIO_SOUND_DISTANCE = ini.GetInt("radio", "sound_distance", RADIO_SOUND_DISTANCE);

    CALLOUT_UI_STYLE = ini.GetInt("callouts", "ui_style", CALLOUT_UI_STYLE);
    CALLOUT_UI_DURATION_MS = ini.GetInt("callouts", "ui_duration_ms", CALLOUT_UI_DURATION_MS);
    CALLOUT_UI_POS_X = ini.GetInt("callouts", "ui_pos_x", CALLOUT_UI_POS_X);
    CALLOUT_UI_POS_Y = ini.GetInt("callouts", "ui_pos_y", CALLOUT_UI_POS_Y);
    CALLOUT_UI_SIZE = ini.GetInt("callouts", "ui_size", CALLOUT_UI_SIZE);
    CALLOUT_UI_ANIM = ini.GetInt("callouts", "ui_anim", CALLOUT_UI_ANIM);
    CALLOUT_UI_ANIM_MS = ini.GetInt("callouts", "ui_anim_ms", CALLOUT_UI_ANIM_MS);
    FRISK_UI_STYLE = ini.GetInt("callouts", "frisk_ui_style", FRISK_UI_STYLE);
    FRISK_UI_MAX_POPUPS = ini.GetInt("callouts", "frisk_ui_max_popups", FRISK_UI_MAX_POPUPS);
    FRISK_UI_POPUP_GAP = ini.GetInt("callouts", "frisk_ui_popup_gap", FRISK_UI_POPUP_GAP);
    FRISK_UI_DURATION_MS = ini.GetInt("callouts", "frisk_ui_duration_ms", FRISK_UI_DURATION_MS);
    CALLOUT_UI_BADGE_CODE = ini.GetInt("callouts", "ui_badge_code", CALLOUT_UI_BADGE_CODE);

    // clamp
    if (RADIO_CALLOUT_VOLUME < 30) RADIO_CALLOUT_VOLUME = 30;
    if (RADIO_CALLOUT_VOLUME > 500) RADIO_CALLOUT_VOLUME = 500;
    if (RADIO_CALLOUT_DISTANCE < 30) RADIO_CALLOUT_DISTANCE = 30;
    if (RADIO_CALLOUT_DISTANCE > 500) RADIO_CALLOUT_DISTANCE = 500;
    if (RADIO_SOUND_VOLUME < 30) RADIO_SOUND_VOLUME = 30;
    if (RADIO_SOUND_VOLUME > 500) RADIO_SOUND_VOLUME = 500;
    if (RADIO_SOUND_DISTANCE < 30) RADIO_SOUND_DISTANCE = 30;
    if (RADIO_SOUND_DISTANCE > 500) RADIO_SOUND_DISTANCE = 500;
    if (RADIO_SOUND_INDEX < 0) RADIO_SOUND_INDEX = 0;
    if (CALLOUT_UI_STYLE < 0) CALLOUT_UI_STYLE = 0;
    if (CALLOUT_UI_STYLE > 2) CALLOUT_UI_STYLE = 2;
    if (CALLOUT_UI_DURATION_MS < 3000) CALLOUT_UI_DURATION_MS = 3000;
    if (CALLOUT_UI_DURATION_MS > 60000) CALLOUT_UI_DURATION_MS = 60000;
    if (CALLOUT_UI_POS_X < -50000) CALLOUT_UI_POS_X = -50000;
    if (CALLOUT_UI_POS_X > 50000) CALLOUT_UI_POS_X = 50000;
    if (CALLOUT_UI_POS_Y < -50000) CALLOUT_UI_POS_Y = -50000;
    if (CALLOUT_UI_POS_Y > 50000) CALLOUT_UI_POS_Y = 50000;
    if (CALLOUT_UI_SIZE < 0) CALLOUT_UI_SIZE = 0;
    if (CALLOUT_UI_SIZE > 100) CALLOUT_UI_SIZE = 100;
    if (CALLOUT_UI_ANIM < 0) CALLOUT_UI_ANIM = 0;
    if (CALLOUT_UI_ANIM > 5) CALLOUT_UI_ANIM = 5;
    if (FRISK_UI_STYLE < 0) FRISK_UI_STYLE = 0;
    if (FRISK_UI_STYLE > 2) FRISK_UI_STYLE = 2;
    if (FRISK_UI_MAX_POPUPS < 1) FRISK_UI_MAX_POPUPS = 1;
    if (FRISK_UI_MAX_POPUPS > 5) FRISK_UI_MAX_POPUPS = 5;
    if (FRISK_UI_POPUP_GAP < 0) FRISK_UI_POPUP_GAP = 0;
    if (FRISK_UI_POPUP_GAP > 50) FRISK_UI_POPUP_GAP = 50;
    if (FRISK_UI_DURATION_MS < 3000) FRISK_UI_DURATION_MS = 3000;
    if (FRISK_UI_DURATION_MS > 60000) FRISK_UI_DURATION_MS = 60000;
    if (CALLOUT_UI_ANIM_MS < 100) CALLOUT_UI_ANIM_MS = 100;
    if (CALLOUT_UI_ANIM_MS > 3000) CALLOUT_UI_ANIM_MS = 3000;
    if (CALLOUT_UI_BADGE_CODE < 0) CALLOUT_UI_BADGE_CODE = 0;
    if (CALLOUT_UI_BADGE_CODE >= CALLOUT_UI_BADGE_CODE_COUNT) CALLOUT_UI_BADGE_CODE = 0;
    FLEE_DURING_APPROACH_MIN_SECONDS = ini.GetInt("settings", "flee_during_approach_min_seconds", FLEE_DURING_APPROACH_MIN_SECONDS);
    FLEE_DURING_APPROACH_MAX_SECONDS = ini.GetInt("settings", "flee_during_approach_max_seconds", FLEE_DURING_APPROACH_MAX_SECONDS);

    CHANCE_BEEING_WANTED_BY_JUSTICE = ini.GetDouble("chances", "chance_of_beeing_wanted_by_justice", CHANCE_BEEING_WANTED_BY_JUSTICE);
    CHANCE_RUNNING_AWAY_WHEN_VEHICLE_IRREGULAR = ini.GetDouble("chances", "chance_of_suspect_running_away_when_vehicle_is_irregular", CHANCE_RUNNING_AWAY_WHEN_VEHICLE_IRREGULAR);
    CHANCE_CRIMINAL_KILL_COPS = ini.GetDouble("chances", "chance_of_criminal_try_to_kill_cops_when_pulled_over", CHANCE_CRIMINAL_KILL_COPS);
    CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED = ini.GetDouble("chances", "chance_of_pedestrian_running_away_when_approached", CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED);
    CHANCE_FLEE_DURING_APPROACH = ini.GetDouble("chances", "chance_of_fleeing_during_approach", CHANCE_FLEE_DURING_APPROACH);
    CHANCE_FLEE_DRIVING_DURING_APPROACH = ini.GetDouble("chances", "chance_of_fleeing_driving_during_approach", CHANCE_FLEE_DRIVING_DURING_APPROACH);
    CHANCE_KIDNAP_DRIVE_OFF = ini.GetDouble("chances", "chance_of_kidnap_drive_off", CHANCE_KIDNAP_DRIVE_OFF);
    CHANCE_KIDNAP_FLEE_ON_PULLOVER = ini.GetDouble("chances", "chance_of_kidnap_flee_on_pullover", CHANCE_KIDNAP_FLEE_ON_PULLOVER);
    CHANCE_MEDIC_REANIMATE_SUCCESS = (float)ini.GetDouble("chances", "chance_of_medic_reanimate_success", CHANCE_MEDIC_REANIMATE_SUCCESS);
    if (CHANCE_MEDIC_REANIMATE_SUCCESS < 0.0f) CHANCE_MEDIC_REANIMATE_SUCCESS = 0.0f;
    if (CHANCE_MEDIC_REANIMATE_SUCCESS > 1.0f) CHANCE_MEDIC_REANIMATE_SUCCESS = 1.0f;
    KIDNAP_WAIT_MIN_SECONDS = ini.GetInt("settings", "kidnap_wait_min_seconds", KIDNAP_WAIT_MIN_SECONDS);
    KIDNAP_WAIT_MAX_SECONDS = ini.GetInt("settings", "kidnap_wait_max_seconds", KIDNAP_WAIT_MAX_SECONDS);
    FLEE_DRIVING_DURING_APPROACH_MIN_SECONDS = ini.GetInt("settings", "flee_driving_during_approach_min_seconds", FLEE_DRIVING_DURING_APPROACH_MIN_SECONDS);
    FLEE_DRIVING_DURING_APPROACH_MAX_SECONDS = ini.GetInt("settings", "flee_driving_during_approach_max_seconds", FLEE_DRIVING_DURING_APPROACH_MAX_SECONDS);
    FLEE_TASK_MIN_SECONDS = ini.GetInt("settings", "flee_task_min_seconds", FLEE_TASK_MIN_SECONDS);
    FLEE_TASK_MAX_SECONDS = ini.GetInt("settings", "flee_task_max_seconds", FLEE_TASK_MAX_SECONDS);
    if (FLEE_TASK_MIN_SECONDS < 5) FLEE_TASK_MIN_SECONDS = 5;
    if (FLEE_TASK_MAX_SECONDS < FLEE_TASK_MIN_SECONDS) FLEE_TASK_MAX_SECONDS = FLEE_TASK_MIN_SECONDS;
    VEHICLE_STOPPED_EXIT_SECONDS = ini.GetInt("settings", "vehicle_stopped_exit_seconds", VEHICLE_STOPPED_EXIT_SECONDS);
    if (VEHICLE_STOPPED_EXIT_SECONDS < 3) VEHICLE_STOPPED_EXIT_SECONDS = 3;
    if (VEHICLE_STOPPED_EXIT_SECONDS > 120) VEHICLE_STOPPED_EXIT_SECONDS = 120;

    CALLOUT_WEIGHT_ATM = ini.GetInt("callouts", "weight_atm", CALLOUT_WEIGHT_ATM);
    CALLOUT_WEIGHT_STOLEN_CAR = ini.GetInt("callouts", "weight_stolen_car", CALLOUT_WEIGHT_STOLEN_CAR);
    CALLOUT_WEIGHT_DRUG_DEALER = ini.GetInt("callouts", "weight_drug_dealer", CALLOUT_WEIGHT_DRUG_DEALER);
    CALLOUT_WEIGHT_HOME_INVASION = ini.GetInt("callouts", "weight_home_invasion", CALLOUT_WEIGHT_HOME_INVASION);
    CALLOUT_WEIGHT_KIDNAP = ini.GetInt("callouts", "weight_kidnap", CALLOUT_WEIGHT_KIDNAP);
    CALLOUT_WEIGHT_BANK_ROBBERY = ini.GetInt("callouts", "weight_bank_robbery", CALLOUT_WEIGHT_BANK_ROBBERY);
    CALLOUT_WEIGHT_ARMORED_CAR = ini.GetInt("callouts", "weight_armored_car", CALLOUT_WEIGHT_ARMORED_CAR);
    CALLOUT_WEIGHT_WANTED_SEARCH = ini.GetInt("callouts", "weight_wanted_search", CALLOUT_WEIGHT_WANTED_SEARCH);
    CALLOUT_WEIGHT_SHOOTOUT = ini.GetInt("callouts", "weight_shootout", CALLOUT_WEIGHT_SHOOTOUT);
    CALLOUT_WEIGHT_FAVELA_SHOOTOUT = ini.GetInt("callouts", "weight_favela_shootout", CALLOUT_WEIGHT_FAVELA_SHOOTOUT);

    // Nivel de cada ocorrencia (1..5) — default 1
    auto clampLvl = [](int v) {
        if (v < 1) return 1;
        if (v > 5) return 5;
        return v;
    };
    CALLOUT_LEVEL_ATM = clampLvl(ini.GetInt("callouts", "level_atm", CALLOUT_LEVEL_ATM));
    CALLOUT_LEVEL_STOLEN_CAR = clampLvl(ini.GetInt("callouts", "level_stolen_car", CALLOUT_LEVEL_STOLEN_CAR));
    CALLOUT_LEVEL_DRUG_DEALER = clampLvl(ini.GetInt("callouts", "level_drug_dealer", CALLOUT_LEVEL_DRUG_DEALER));
    CALLOUT_LEVEL_HOME_INVASION = clampLvl(ini.GetInt("callouts", "level_home_invasion", CALLOUT_LEVEL_HOME_INVASION));
    CALLOUT_LEVEL_KIDNAP = clampLvl(ini.GetInt("callouts", "level_kidnap", CALLOUT_LEVEL_KIDNAP));
    CALLOUT_LEVEL_BANK_ROBBERY = clampLvl(ini.GetInt("callouts", "level_bank_robbery", CALLOUT_LEVEL_BANK_ROBBERY));
    CALLOUT_LEVEL_ARMORED_CAR = clampLvl(ini.GetInt("callouts", "level_armored_car", CALLOUT_LEVEL_ARMORED_CAR));
    CALLOUT_LEVEL_WANTED_SEARCH = clampLvl(ini.GetInt("callouts", "level_wanted_search", CALLOUT_LEVEL_WANTED_SEARCH));
    CALLOUT_LEVEL_SHOOTOUT = clampLvl(ini.GetInt("callouts", "level_shootout", CALLOUT_LEVEL_SHOOTOUT));
    CALLOUT_LEVEL_FAVELA_SHOOTOUT = clampLvl(ini.GetInt("callouts", "level_favela_shootout", CALLOUT_LEVEL_FAVELA_SHOOTOUT));

    // 0 = Todas | 1..5 = filtro de nivel
    CALLOUT_LEVEL_FILTER = ini.GetInt("callouts", "selected_callout_level", CALLOUT_LEVEL_FILTER);
    if (CALLOUT_LEVEL_FILTER < 0) CALLOUT_LEVEL_FILTER = 0;
    if (CALLOUT_LEVEL_FILTER > 5) CALLOUT_LEVEL_FILTER = 5;

    g_acceptCalloutsOtherCities = ini.GetInt("callouts", "accept_callouts_other_cities", g_acceptCalloutsOtherCities);
    if (g_acceptCalloutsOtherCities != 0) g_acceptCalloutsOtherCities = 1;
    CHANCE_WANTED_SEARCH_USE_HOUSE = (float)ini.GetDouble("chances", "chance_of_wanted_search_use_house_location", CHANCE_WANTED_SEARCH_USE_HOUSE);
    if (CHANCE_WANTED_SEARCH_USE_HOUSE < 0.0f) CHANCE_WANTED_SEARCH_USE_HOUSE = 0.0f;
    if (CHANCE_WANTED_SEARCH_USE_HOUSE > 1.0f) CHANCE_WANTED_SEARCH_USE_HOUSE = 1.0f;
    CHANCE_ARMED_SURRENDER = (float)ini.GetDouble("chances", "chance_of_armed_surrender", CHANCE_ARMED_SURRENDER);
    if (CHANCE_ARMED_SURRENDER < 0.0f) CHANCE_ARMED_SURRENDER = 0.0f;
    if (CHANCE_ARMED_SURRENDER > 1.0f) CHANCE_ARMED_SURRENDER = 1.0f;
    g_aguiaNoBanco = ini.GetInt("callouts", "aguia_no_banco", g_aguiaNoBanco);
    if (g_aguiaNoBanco != 0) g_aguiaNoBanco = 1;

    // Aguia automatico so na favela ([aguia_favela])
    AGUIA_FAVELA_ENABLED = ini.GetInt("aguia_favela", "enabled", AGUIA_FAVELA_ENABLED);
    if (AGUIA_FAVELA_ENABLED != 0) AGUIA_FAVELA_ENABLED = 1;
    AGUIA_FAVELA_MODEL_ID = ini.GetInt("aguia_favela", "model_id", AGUIA_FAVELA_MODEL_ID);
    if (AGUIA_FAVELA_MODEL_ID < 400) AGUIA_FAVELA_MODEL_ID = 497;
    AGUIA_FAVELA_HEIGHT = ini.GetInt("aguia_favela", "height", AGUIA_FAVELA_HEIGHT);
    AGUIA_FAVELA_RADIUS = ini.GetInt("aguia_favela", "radius", AGUIA_FAVELA_RADIUS);
    AGUIA_FAVELA_SPEED = ini.GetInt("aguia_favela", "speed", AGUIA_FAVELA_SPEED);
    AGUIA_FAVELA_ANGLE = ini.GetInt("aguia_favela", "angle", AGUIA_FAVELA_ANGLE);
    AGUIA_FAVELA_DIRECTION = ini.GetInt("aguia_favela", "direction", AGUIA_FAVELA_DIRECTION);
    if (AGUIA_FAVELA_DIRECTION != 0) AGUIA_FAVELA_DIRECTION = 1;
    if (AGUIA_FAVELA_RADIUS < 10) AGUIA_FAVELA_RADIUS = 10;
    if (AGUIA_FAVELA_RADIUS > 200) AGUIA_FAVELA_RADIUS = 200;
    {
        auto isVar = [](int v) { return v == 1001 || v == 1002 || v == 1003 || v == 1004 || v == 999; };
        if (!isVar(AGUIA_FAVELA_HEIGHT)) {
            if (AGUIA_FAVELA_HEIGHT < 10) AGUIA_FAVELA_HEIGHT = 10;
            if (AGUIA_FAVELA_HEIGHT > 200) AGUIA_FAVELA_HEIGHT = 200;
        }
        if (!isVar(AGUIA_FAVELA_SPEED)) {
            if (AGUIA_FAVELA_SPEED < 10) AGUIA_FAVELA_SPEED = 10;
            if (AGUIA_FAVELA_SPEED > 200) AGUIA_FAVELA_SPEED = 200;
        }
    }

    // Destino automatico no mapa (GPS)

    // Veiculo roubado na regiao (pega carro ja existente)
    STOLEN_NEARBY_INTERVAL_SECONDS = ini.GetInt("stolen_nearby", "interval_seconds", STOLEN_NEARBY_INTERVAL_SECONDS);
    STOLEN_NEARBY_CHANCE = ini.GetDouble("stolen_nearby", "chance", STOLEN_NEARBY_CHANCE);
    STOLEN_NEARBY_SHOW_BLIP_3D = ini.GetInt("stolen_nearby", "show_blip_3d", STOLEN_NEARBY_SHOW_BLIP_3D);
    STOLEN_NEARBY_BLIP_3D_SECONDS = ini.GetInt("stolen_nearby", "blip_3d_seconds", STOLEN_NEARBY_BLIP_3D_SECONDS);
    STOLEN_NEARBY_SHOW_BIG_CIRCLE = ini.GetInt("stolen_nearby", "show_big_circle", STOLEN_NEARBY_SHOW_BIG_CIRCLE);
    STOLEN_NEARBY_WEAPON_CHANCE = ini.GetDouble("stolen_nearby", "weapon_chance", STOLEN_NEARBY_WEAPON_CHANCE);
    if (STOLEN_NEARBY_INTERVAL_SECONDS < 5) STOLEN_NEARBY_INTERVAL_SECONDS = 5;
    if (STOLEN_NEARBY_CHANCE < 0.0) STOLEN_NEARBY_CHANCE = 0.0;
    if (STOLEN_NEARBY_CHANCE > 1.0) STOLEN_NEARBY_CHANCE = 1.0;
    if (STOLEN_NEARBY_SHOW_BLIP_3D != 0) STOLEN_NEARBY_SHOW_BLIP_3D = 1;
    if (STOLEN_NEARBY_BLIP_3D_SECONDS < 0) STOLEN_NEARBY_BLIP_3D_SECONDS = 0;
    if (STOLEN_NEARBY_SHOW_BIG_CIRCLE != 0) STOLEN_NEARBY_SHOW_BIG_CIRCLE = 1;
    if (STOLEN_NEARBY_WEAPON_CHANCE < 0.0) STOLEN_NEARBY_WEAPON_CHANCE = 0.0;
    if (STOLEN_NEARBY_WEAPON_CHANCE > 1.0) STOLEN_NEARBY_WEAPON_CHANCE = 1.0;
    // chance 0 = sistema desligado na pratica
    STOLEN_NEARBY_ENABLED = (STOLEN_NEARBY_CHANCE > 0.0) ? 1 : 0;

    g_widgetsStartPosition.x = ini.GetDouble("widgets", "position_x", g_widgetsStartPosition.x);
    g_widgetsStartPosition.y = ini.GetDouble("widgets", "position_y", g_widgetsStartPosition.y);

    // Regrava o arquivo para incluir chaves novas (sem secao dualpatrol)
    SaveSettings();
}

void ModData::SaveSettings()
{
    // Garante pasta do mod
    CreateFolder(modFolderPath);

    auto pathSettings = GetFile("settings.ini");
    fileLog->Log(std::string("ModData::SaveSettings -> ") + pathSettings);

    IniReaderWriter ini;
    // Nao carrega o antigo de proposito: reescreve so as secoes do mod principal
    // (dualpatrol fica em data/dualpatrol/settings.ini)

    ini.SetInt("settings", "chase_vehicle_max_speed", CHASE_VEHICLE_MAX_SPEED);
    ini.SetInt("settings", "chase_police_max_speed", CHASE_POLICE_MAX_SPEED);
    ini.SetInt("settings", "chase_minimum_time_to_surrender", CHASE_MIN_TIME_TO_SURRENDER);
    ini.SetInt("settings", "seconds_between_callouts", g_secondsBetweenCallouts);
    ini.SetBool("settings", "create_injured_ped", CREATE_INJURED_PED);
    ini.SetBool("settings", "disable_callouts_radio_sound", DISABLE_CALLOUTS_RADIO_SOUND);

    // Logs
    ini.SetBool("settings", "enable_log", g_enableLog);
    ini.SetBool("settings", "enable_deeplog", g_enableDeepLog);

    ini.SetBool("radio", "play_accept_callout_sound", RADIO_PLAY_ACCEPT_CALLOUT_SOUND);
    ini.SetInt("radio", "callout_volume", RADIO_CALLOUT_VOLUME);
    ini.SetInt("radio", "callout_distance", RADIO_CALLOUT_DISTANCE);
    ini.SetBool("radio", "vehicle_radio_enabled", RADIO_VEHICLE_RADIO_ENABLED);
    ini.SetInt("radio", "sound_index", RADIO_SOUND_INDEX);
    ini.SetInt("radio", "sound_volume", RADIO_SOUND_VOLUME);
    ini.SetInt("radio", "sound_distance", RADIO_SOUND_DISTANCE);

    ini.SetInt("callouts", "ui_style", CALLOUT_UI_STYLE);
    ini.SetInt("callouts", "ui_duration_ms", CALLOUT_UI_DURATION_MS);
    ini.SetInt("callouts", "ui_pos_x", CALLOUT_UI_POS_X);
    ini.SetInt("callouts", "ui_pos_y", CALLOUT_UI_POS_Y);
    ini.SetInt("callouts", "ui_size", CALLOUT_UI_SIZE);
    ini.SetInt("callouts", "ui_anim", CALLOUT_UI_ANIM);
    ini.SetInt("callouts", "ui_anim_ms", CALLOUT_UI_ANIM_MS);
    ini.SetInt("callouts", "frisk_ui_style", FRISK_UI_STYLE);
    ini.SetInt("callouts", "frisk_ui_max_popups", FRISK_UI_MAX_POPUPS);
    ini.SetInt("callouts", "frisk_ui_popup_gap", FRISK_UI_POPUP_GAP);
    ini.SetInt("callouts", "frisk_ui_duration_ms", FRISK_UI_DURATION_MS);
    ini.SetInt("callouts", "ui_badge_code", CALLOUT_UI_BADGE_CODE);
    ini.SetInt("settings", "flee_during_approach_min_seconds", FLEE_DURING_APPROACH_MIN_SECONDS);
    ini.SetInt("settings", "flee_during_approach_max_seconds", FLEE_DURING_APPROACH_MAX_SECONDS);

    ini.SetDouble("chances", "chance_of_beeing_wanted_by_justice", CHANCE_BEEING_WANTED_BY_JUSTICE);
    ini.SetDouble("chances", "chance_of_suspect_running_away_when_vehicle_is_irregular", CHANCE_RUNNING_AWAY_WHEN_VEHICLE_IRREGULAR);
    ini.SetDouble("chances", "chance_of_criminal_try_to_kill_cops_when_pulled_over", CHANCE_CRIMINAL_KILL_COPS);
    ini.SetDouble("chances", "chance_of_pedestrian_running_away_when_approached", CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED);
    ini.SetDouble("chances", "chance_of_fleeing_during_approach", CHANCE_FLEE_DURING_APPROACH);
    ini.SetDouble("chances", "chance_of_fleeing_driving_during_approach", CHANCE_FLEE_DRIVING_DURING_APPROACH);
    ini.SetDouble("chances", "chance_of_kidnap_drive_off", CHANCE_KIDNAP_DRIVE_OFF);
    ini.SetDouble("chances", "chance_of_kidnap_flee_on_pullover", CHANCE_KIDNAP_FLEE_ON_PULLOVER);
    ini.SetDouble("chances", "chance_of_medic_reanimate_success", CHANCE_MEDIC_REANIMATE_SUCCESS);
    ini.SetInt("settings", "kidnap_wait_min_seconds", KIDNAP_WAIT_MIN_SECONDS);
    ini.SetInt("settings", "kidnap_wait_max_seconds", KIDNAP_WAIT_MAX_SECONDS);
    ini.SetInt("settings", "flee_driving_during_approach_min_seconds", FLEE_DRIVING_DURING_APPROACH_MIN_SECONDS);
    ini.SetInt("settings", "flee_driving_during_approach_max_seconds", FLEE_DRIVING_DURING_APPROACH_MAX_SECONDS);
    ini.SetInt("settings", "flee_task_min_seconds", FLEE_TASK_MIN_SECONDS);
    ini.SetInt("settings", "flee_task_max_seconds", FLEE_TASK_MAX_SECONDS);
    ini.SetInt("settings", "vehicle_stopped_exit_seconds", VEHICLE_STOPPED_EXIT_SECONDS);

    ini.SetInt("callouts", "weight_atm", CALLOUT_WEIGHT_ATM);
    ini.SetInt("callouts", "weight_stolen_car", CALLOUT_WEIGHT_STOLEN_CAR);
    ini.SetInt("callouts", "weight_drug_dealer", CALLOUT_WEIGHT_DRUG_DEALER);
    ini.SetInt("callouts", "weight_home_invasion", CALLOUT_WEIGHT_HOME_INVASION);
    ini.SetInt("callouts", "weight_kidnap", CALLOUT_WEIGHT_KIDNAP);
    ini.SetInt("callouts", "weight_bank_robbery", CALLOUT_WEIGHT_BANK_ROBBERY);
    ini.SetInt("callouts", "weight_armored_car", CALLOUT_WEIGHT_ARMORED_CAR);
    ini.SetInt("callouts", "weight_wanted_search", CALLOUT_WEIGHT_WANTED_SEARCH);
    ini.SetInt("callouts", "weight_shootout", CALLOUT_WEIGHT_SHOOTOUT);
    ini.SetInt("callouts", "weight_favela_shootout", CALLOUT_WEIGHT_FAVELA_SHOOTOUT);

    ini.SetInt("callouts", "level_atm", CALLOUT_LEVEL_ATM);
    ini.SetInt("callouts", "level_stolen_car", CALLOUT_LEVEL_STOLEN_CAR);
    ini.SetInt("callouts", "level_drug_dealer", CALLOUT_LEVEL_DRUG_DEALER);
    ini.SetInt("callouts", "level_home_invasion", CALLOUT_LEVEL_HOME_INVASION);
    ini.SetInt("callouts", "level_kidnap", CALLOUT_LEVEL_KIDNAP);
    ini.SetInt("callouts", "level_bank_robbery", CALLOUT_LEVEL_BANK_ROBBERY);
    ini.SetInt("callouts", "level_armored_car", CALLOUT_LEVEL_ARMORED_CAR);
    ini.SetInt("callouts", "level_wanted_search", CALLOUT_LEVEL_WANTED_SEARCH);
    ini.SetInt("callouts", "level_shootout", CALLOUT_LEVEL_SHOOTOUT);
    ini.SetInt("callouts", "level_favela_shootout", CALLOUT_LEVEL_FAVELA_SHOOTOUT);
    ini.SetInt("callouts", "selected_callout_level", CALLOUT_LEVEL_FILTER);

    ini.SetInt("callouts", "accept_callouts_other_cities", g_acceptCalloutsOtherCities);
    ini.SetDouble("chances", "chance_of_wanted_search_use_house_location", CHANCE_WANTED_SEARCH_USE_HOUSE);
    ini.SetDouble("chances", "chance_of_armed_surrender", CHANCE_ARMED_SURRENDER);
    ini.SetInt("callouts", "aguia_no_banco", g_aguiaNoBanco);

    ini.SetInt("aguia_favela", "enabled", AGUIA_FAVELA_ENABLED);
    ini.SetInt("aguia_favela", "model_id", AGUIA_FAVELA_MODEL_ID);
    ini.SetInt("aguia_favela", "height", AGUIA_FAVELA_HEIGHT);
    ini.SetInt("aguia_favela", "radius", AGUIA_FAVELA_RADIUS);
    ini.SetInt("aguia_favela", "speed", AGUIA_FAVELA_SPEED);
    ini.SetInt("aguia_favela", "angle", AGUIA_FAVELA_ANGLE);
    ini.SetInt("aguia_favela", "direction", AGUIA_FAVELA_DIRECTION);

    // Nova categoria: veiculo roubado na regiao
    ini.SetInt("stolen_nearby", "interval_seconds", STOLEN_NEARBY_INTERVAL_SECONDS);
    ini.SetDouble("stolen_nearby", "chance", STOLEN_NEARBY_CHANCE);
    ini.SetInt("stolen_nearby", "show_blip_3d", STOLEN_NEARBY_SHOW_BLIP_3D);
    ini.SetInt("stolen_nearby", "blip_3d_seconds", STOLEN_NEARBY_BLIP_3D_SECONDS);
    ini.SetInt("stolen_nearby", "show_big_circle", STOLEN_NEARBY_SHOW_BIG_CIRCLE);
    ini.SetDouble("stolen_nearby", "weapon_chance", STOLEN_NEARBY_WEAPON_CHANCE);

    ini.SetDouble("widgets", "position_x", g_widgetsStartPosition.x);
    ini.SetDouble("widgets", "position_y", g_widgetsStartPosition.y);

    bool ok = ini.SaveToFile(pathSettings);
    if (!ok)
    {
        fileLog->Error(std::string("ModData::SaveSettings FALHOU ao gravar: ") + pathSettings);
        // fallback ofstream direto
        std::ofstream f(pathSettings);
        if (f.is_open())
        {
            f << "[settings]\n";
            f << "chase_vehicle_max_speed = " << CHASE_VEHICLE_MAX_SPEED << "\n";
            f << "chase_police_max_speed = " << CHASE_POLICE_MAX_SPEED << "\n";
            f << "chase_minimum_time_to_surrender = " << CHASE_MIN_TIME_TO_SURRENDER << "\n";
            f << "seconds_between_callouts = " << g_secondsBetweenCallouts << "\n";
            f << "create_injured_ped = " << (CREATE_INJURED_PED ? 1 : 0) << "\n";
            f << "disable_callouts_radio_sound = " << (DISABLE_CALLOUTS_RADIO_SOUND ? 1 : 0) << "\n";
            f << "enable_log = " << (g_enableLog ? 1 : 0) << "\n";
            f << "enable_deeplog = " << (g_enableDeepLog ? 1 : 0) << "\n";
            f << "\n[radio]\n";
            f << "play_accept_callout_sound = " << (RADIO_PLAY_ACCEPT_CALLOUT_SOUND ? 1 : 0) << "\n";
            f << "callout_volume = " << RADIO_CALLOUT_VOLUME << "\n";
            f << "callout_distance = " << RADIO_CALLOUT_DISTANCE << "\n";
            f << "vehicle_radio_enabled = " << (RADIO_VEHICLE_RADIO_ENABLED ? 1 : 0) << "\n";
            f << "sound_index = " << RADIO_SOUND_INDEX << "\n";
            f << "sound_volume = " << RADIO_SOUND_VOLUME << "\n";
            f << "sound_distance = " << RADIO_SOUND_DISTANCE << "\n";
            f << "flee_during_approach_min_seconds = " << FLEE_DURING_APPROACH_MIN_SECONDS << "\n";
            f << "flee_during_approach_max_seconds = " << FLEE_DURING_APPROACH_MAX_SECONDS << "\n";
            f << "flee_driving_during_approach_min_seconds = " << FLEE_DRIVING_DURING_APPROACH_MIN_SECONDS << "\n";
            f << "flee_driving_during_approach_max_seconds = " << FLEE_DRIVING_DURING_APPROACH_MAX_SECONDS << "\n";
            f << "flee_task_min_seconds = " << FLEE_TASK_MIN_SECONDS << "  ; duracao minima da fuga (s)\n";
            f << "flee_task_max_seconds = " << FLEE_TASK_MAX_SECONDS << "  ; duracao maxima da fuga (s)\n";
            f << "vehicle_stopped_exit_seconds = " << VEHICLE_STOPPED_EXIT_SECONDS << "  ; parado N s = desce do carro\n\n";
            f << "[chances]\n";
            f << "chance_of_beeing_wanted_by_justice = " << CHANCE_BEEING_WANTED_BY_JUSTICE << "\n";
            f << "chance_of_suspect_running_away_when_vehicle_is_irregular = " << CHANCE_RUNNING_AWAY_WHEN_VEHICLE_IRREGULAR << "\n";
            f << "chance_of_criminal_try_to_kill_cops_when_pulled_over = " << CHANCE_CRIMINAL_KILL_COPS << "\n";
            f << "chance_of_pedestrian_running_away_when_approached = " << CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED << "\n";
            f << "chance_of_fleeing_during_approach = " << CHANCE_FLEE_DURING_APPROACH << "\n";
            f << "chance_of_fleeing_driving_during_approach = " << CHANCE_FLEE_DRIVING_DURING_APPROACH << "\n";
            f << "chance_of_kidnap_drive_off = " << CHANCE_KIDNAP_DRIVE_OFF << "\n";
            f << "chance_of_kidnap_flee_on_pullover = " << CHANCE_KIDNAP_FLEE_ON_PULLOVER << "\n\n";
            f << "[callouts]\n";
            f << "weight_atm = " << CALLOUT_WEIGHT_ATM << "\n";
            f << "weight_stolen_car = " << CALLOUT_WEIGHT_STOLEN_CAR << "\n";
            f << "weight_drug_dealer = " << CALLOUT_WEIGHT_DRUG_DEALER << "\n";
            f << "weight_home_invasion = " << CALLOUT_WEIGHT_HOME_INVASION << "\n";
            f << "weight_kidnap = " << CALLOUT_WEIGHT_KIDNAP << "\n";
            f << "weight_bank_robbery = " << CALLOUT_WEIGHT_BANK_ROBBERY << "\n";
            f << "weight_favela_shootout = " << CALLOUT_WEIGHT_FAVELA_SHOOTOUT << "\n";
            f << "weight_armored_car = " << CALLOUT_WEIGHT_ARMORED_CAR << "\n";
            f << "aguia_no_banco = " << g_aguiaNoBanco << "  ; 1=aguia auto no banco, 0=nao\n";
            f << "ui_style = " << CALLOUT_UI_STYLE << "  ; 0=padrao 1=novo 2=ambos\n";
            f << "ui_duration_ms = " << CALLOUT_UI_DURATION_MS << "\n";
            f << "ui_pos_x = " << CALLOUT_UI_POS_X << "\n";
            f << "ui_pos_y = " << CALLOUT_UI_POS_Y << "\n";
            f << "ui_size = " << CALLOUT_UI_SIZE << "\n";
            f << "ui_anim = " << CALLOUT_UI_ANIM << "  ; 0=off 1=cima 2=baixo 3=esq 4=dir 5=fade\n";
            f << "ui_anim_ms = " << CALLOUT_UI_ANIM_MS << "\n";
            f << "frisk_ui_style = " << FRISK_UI_STYLE << "  ; 0=menu 1=painel 2=ambos\n";
            f << "frisk_ui_max_popups = " << FRISK_UI_MAX_POPUPS << "  ; 1..5 pop-ups simultaneos\n";
            f << "frisk_ui_popup_gap = " << FRISK_UI_POPUP_GAP << "  ; 0..50 espaco entre pop-ups\n";
            f << "frisk_ui_duration_ms = " << FRISK_UI_DURATION_MS << "  ; 3000..60000 tempo pop-ups\n";
            f << "ui_badge_code = " << CALLOUT_UI_BADGE_CODE << "  ; 0=911 1=190 2=192 3=193 4=197 5=153\n\n";
            f << "[widgets]\n";
            f << "position_x = " << g_widgetsStartPosition.x << "\n";
            f << "position_y = " << g_widgetsStartPosition.y << "\n";
            f.close();
            fileLog->Log("ModData::SaveSettings fallback OK");
        }
        else
        {
            fileLog->Error("ModData::SaveSettings fallback tambem falhou");
        }
    }
    else
    {
        fileLog->Log("ModData::SaveSettings OK");
    }
}


void ModData::CreateFolder(const std::string& path)
{
    // Cria pasta se não existir
    mkdir(path.c_str(), 0777);
}