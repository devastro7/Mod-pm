#include "TestWindow.h"

#include "CleoFunctions.h"
#include "ModelLoader.h"
#include "Peds.h"
#include "BottomMessage.h"
#include "Chase.h"
#include "Callouts.h"
#include "Vehicles.h"
#include "Partners.h"
#include "ModData.h"
#include "DispatchPanel.h"

void TestWindow::OpenWindow()
{
    static int calloutIndex = 0;
    // Garante que o menu mostra o que esta salvo no ini
    modData->LoadSettings();

    auto window = menuSZK->CreateWindow(200, 200, 800, "Mod Policia - tests");

    {
        auto button = window->AddButton("Equip");
        button->onClick->Add([window]() {
            window->Close();

            g_onService = true;
            TestEquip();
        });
    }

    // Servico: sessao apenas (nao salva)
    {
        static int serviceInt = 0;
        serviceInt = g_onService ? 1 : 0;
        auto item = window->AddIntRange("Servico (0=Off 1=On)", &serviceInt, 0, 1);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            g_onService = (serviceInt == 1);
            if (g_onService)
                BottomMessage::SetMessage("~g~Servico ~w~ligado - ocorrencias ativas", 2500);
            else
                BottomMessage::SetMessage("~r~Servico ~w~desligado - sem ocorrencias", 2500);
        });
    }

    // Estilo: 0=Padrao 1=Novo 2=Ambos  — IntRange le o valor real (SetOptionIndex do MenuSZK falha)
    {
        auto item = window->AddIntRange("Estilo", &CALLOUT_UI_STYLE, 0, 2);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            if (CALLOUT_UI_STYLE < 0) CALLOUT_UI_STYLE = 0;
            if (CALLOUT_UI_STYLE > 2) CALLOUT_UI_STYLE = 2;
            modData->SaveSettings();
            const char* names[] = { "Padrao", "Novo (Ocorrencia)", "Ambos" };
            BottomMessage::SetMessage(std::string("~w~Estilo: ~y~") + names[CALLOUT_UI_STYLE], 2000);
        });
    }

    // Estilo consulta (revista/RG/CNH/veiculo/bafometro)
    {
        auto item = window->AddIntRange("Estilo consulta", &FRISK_UI_STYLE, 0, 2);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            if (FRISK_UI_STYLE < 0) FRISK_UI_STYLE = 0;
            if (FRISK_UI_STYLE > 2) FRISK_UI_STYLE = 2;
            modData->SaveSettings();
            const char* names[] = { "Padrao (menu)", "Novo (painel)", "Ambos" };
            BottomMessage::SetMessage(std::string("~w~Consulta: ~y~") + names[FRISK_UI_STYLE], 2000);
        });
    }

    // Max de pop-ups simultaneos (1..5)
    {
        auto item = window->AddIntRange("Max pop-ups", &FRISK_UI_MAX_POPUPS, 1, 5);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            if (FRISK_UI_MAX_POPUPS < 1) FRISK_UI_MAX_POPUPS = 1;
            if (FRISK_UI_MAX_POPUPS > 5) FRISK_UI_MAX_POPUPS = 5;
            modData->SaveSettings();
            BottomMessage::SetMessage("~w~Max pop-ups: ~y~" + std::to_string(FRISK_UI_MAX_POPUPS), 2000);
        });
    }

    // Espaco entre pop-ups (0..50)
    {
        auto item = window->AddIntRange("Espaco pop-ups", &FRISK_UI_POPUP_GAP, 0, 50);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            if (FRISK_UI_POPUP_GAP < 0) FRISK_UI_POPUP_GAP = 0;
            if (FRISK_UI_POPUP_GAP > 50) FRISK_UI_POPUP_GAP = 50;
            modData->SaveSettings();
            BottomMessage::SetMessage("~w~Espaco pop-ups: ~y~" + std::to_string(FRISK_UI_POPUP_GAP), 2000);
        });
    }

    // Tempo dos pop-ups (s)
    {
        static int popupDurationSec = 8;
        popupDurationSec = FRISK_UI_DURATION_MS / 1000;
        if (popupDurationSec < 3) popupDurationSec = 3;
        if (popupDurationSec > 60) popupDurationSec = 60;
        auto item = window->AddIntRange("Tempo pop-ups (s)", &popupDurationSec, 3, 60);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            FRISK_UI_DURATION_MS = popupDurationSec * 1000;
            modData->SaveSettings();
            BottomMessage::SetMessage("~w~Tempo pop-ups: ~y~" + std::to_string(popupDurationSec) + "s", 2000);
        });
    }



    // Tempo do aviso em segundos (mostra segundos, salva ms)
    {
        static int durationSec = 12;
        durationSec = CALLOUT_UI_DURATION_MS / 1000;
        if (durationSec < 3) durationSec = 3;
        if (durationSec > 60) durationSec = 60;
        auto item = window->AddIntRange("Tempo do aviso (s)", &durationSec, 3, 60);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            CALLOUT_UI_DURATION_MS = durationSec * 1000;
            modData->SaveSettings();
            BottomMessage::SetMessage("~w~Tempo do aviso: ~y~" + std::to_string(durationSec) + "s", 2000);
        });
    }

    // Pos X — MenuSZK IntRange ignora addBy (sempre +1), forca passo 10 no callback
    {
        static int lastPosX = 0;
        lastPosX = CALLOUT_UI_POS_X;
        auto item = window->AddIntRange("Ocorrencia Pos X", &CALLOUT_UI_POS_X, -50000, 50000);
        item->addBy = 10;
        item->onOptionChange->Add([]() {
            int cur = CALLOUT_UI_POS_X;
            if (cur == lastPosX + 1)
                CALLOUT_UI_POS_X = lastPosX + 10;
            else if (cur == lastPosX - 1)
                CALLOUT_UI_POS_X = lastPosX - 10;
            if (CALLOUT_UI_POS_X > 50000) CALLOUT_UI_POS_X = 50000;
            if (CALLOUT_UI_POS_X < -50000) CALLOUT_UI_POS_X = -50000;
            // alinha em multiplo de 10
            CALLOUT_UI_POS_X = (CALLOUT_UI_POS_X / 10) * 10;
            lastPosX = CALLOUT_UI_POS_X;
            modData->SaveSettings();
            DispatchPanel::ApplyLayout();
        });
    }

    // Pos Z — mesmo passo 10 (usa POS_Y no codigo)
    {
        static int lastPosZ = 0;
        lastPosZ = CALLOUT_UI_POS_Y;
        auto item = window->AddIntRange("Ocorrencia Pos Z", &CALLOUT_UI_POS_Y, -50000, 50000);
        item->addBy = 10;
        item->onOptionChange->Add([]() {
            int cur = CALLOUT_UI_POS_Y;
            if (cur == lastPosZ + 1)
                CALLOUT_UI_POS_Y = lastPosZ + 10;
            else if (cur == lastPosZ - 1)
                CALLOUT_UI_POS_Y = lastPosZ - 10;
            if (CALLOUT_UI_POS_Y > 50000) CALLOUT_UI_POS_Y = 50000;
            if (CALLOUT_UI_POS_Y < -50000) CALLOUT_UI_POS_Y = -50000;
            CALLOUT_UI_POS_Y = (CALLOUT_UI_POS_Y / 10) * 10;
            lastPosZ = CALLOUT_UI_POS_Y;
            modData->SaveSettings();
            DispatchPanel::ApplyLayout();
        });
    }

    // Tamanho
    {
        auto item = window->AddIntRange("Ocorrencia Tamanho", &CALLOUT_UI_SIZE, 0, 100);
        item->addBy = 5;
        item->onOptionChange->Add([]() {
            modData->SaveSettings();
            DispatchPanel::ApplyLayout();
        });
    }

    // Animacao: 0=Off 1=Cima 2=Baixo 3=Esq 4=Dir 5=Fade
    {
        auto item = window->AddIntRange("Animacao", &CALLOUT_UI_ANIM, 0, 5);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            if (CALLOUT_UI_ANIM < 0) CALLOUT_UI_ANIM = 0;
            if (CALLOUT_UI_ANIM > 5) CALLOUT_UI_ANIM = 5;
            modData->SaveSettings();
            const char* names[] = { "Desligada", "De cima", "De baixo", "Da esquerda", "Da direita", "Fade" };
            BottomMessage::SetMessage(std::string("~w~Animacao: ~y~") + names[CALLOUT_UI_ANIM], 2000);
        });
    }

    // Tempo da animacao — MenuSZK IntRange ignora addBy (sempre +1), forca passo 50 no callback
    {
        static int lastAnimMs = 0;
        lastAnimMs = CALLOUT_UI_ANIM_MS;
        auto item = window->AddIntRange("Tempo animacao (ms)", &CALLOUT_UI_ANIM_MS, 100, 1500);
        item->addBy = 50;
        item->onOptionChange->Add([]() {
            int cur = CALLOUT_UI_ANIM_MS;
            if (cur == lastAnimMs + 1)
                CALLOUT_UI_ANIM_MS = lastAnimMs + 50;
            else if (cur == lastAnimMs - 1)
                CALLOUT_UI_ANIM_MS = lastAnimMs - 50;
            if (CALLOUT_UI_ANIM_MS > 1500) CALLOUT_UI_ANIM_MS = 1500;
            if (CALLOUT_UI_ANIM_MS < 100) CALLOUT_UI_ANIM_MS = 100;
            // alinha em multiplo de 50
            CALLOUT_UI_ANIM_MS = (CALLOUT_UI_ANIM_MS / 50) * 50;
            if (CALLOUT_UI_ANIM_MS < 100) CALLOUT_UI_ANIM_MS = 100;
            lastAnimMs = CALLOUT_UI_ANIM_MS;
            modData->SaveSettings();
            BottomMessage::SetMessage("~w~Tempo anim: ~y~" + std::to_string(CALLOUT_UI_ANIM_MS) + "ms", 2000);
        });
    }

    // Badge codigo: 0=911 1=190 2=192 3=193 4=197 5=153
    {
        auto item = window->AddIntRange("Codigo badge", &CALLOUT_UI_BADGE_CODE, 0, CALLOUT_UI_BADGE_CODE_COUNT - 1);
        item->addBy = 1;
        item->onOptionChange->Add([]() {
            if (CALLOUT_UI_BADGE_CODE < 0) CALLOUT_UI_BADGE_CODE = 0;
            if (CALLOUT_UI_BADGE_CODE >= CALLOUT_UI_BADGE_CODE_COUNT) CALLOUT_UI_BADGE_CODE = CALLOUT_UI_BADGE_CODE_COUNT - 1;
            modData->SaveSettings();
            DispatchPanel::ApplyLayout();
            BottomMessage::SetMessage(std::string("~w~Badge: ~y~") + GetCalloutBadgeText(), 2000);
        });
    }

    {
        auto item = window->AddIntRange("Callout: ID", &calloutIndex, 0, CalloutRegistry::m_callouts.size() - 1);
        item->addBy = 1;
    }

    {
        auto button = window->AddButton("Callout: Spawn");
        button->onClick->Add([window]() {
            window->Close();

            auto callouts = CalloutRegistry::m_callouts;
            auto ptr = callouts[calloutIndex];;

            Callouts::BroadcastCallout(ptr);
        });
    }

    {
        auto button = window->AddButton("Freeze criminals");
        button->onClick->Add([window]() {
            window->Close();

            auto vehicles = Chase::vehiclesInChase;

            for(auto vehicle : vehicles)
            {
                SET_CAR_MAX_SPEED(vehicle->ref, 0);
            }

            BottomMessage::SetMessage("Velocity limited to 0", 2000);
        });
    }

    {
        auto button = window->AddButton("Spawn dangerous ped");
        button->onClick->Add([window]() {
            window->Close();
            
            BottomMessage::SetMessage("Spawnando pedestre que reage a abordagem", 3000);

            ModelLoader::AddModelToLoad(80);
            ModelLoader::LoadAll([]() {

                auto playerPosition = GetPlayerPosition();
                auto pedPath = STORE_PED_PATH_COORDS_CLOSEST_TO(playerPosition.x, playerPosition.y, playerPosition.z);

                auto pedRef = CREATE_ACTOR_PEDTYPE(PedType::CivMale, 80, pedPath.x, pedPath.y, pedPath.z);
                auto ped = Peds::RegisterPed(pedRef);
                ped->flags.willSurrender = false;

                ped->ShowBlip(CRGBA(0, 255, 255));
            });
        });
    }

    {
        auto button = window->AddButton("Accept callout");
        button->onClick->Add([window]() {
            window->Close();
            
            Callouts::AcceptCallout();
        });
    }

    {
        auto button = window->AddButton("Partner");
        button->onClick->Add([window]() {
            window->Close();
            
            Partners::CreateSpawnPartnerMenu();
        });
    }

    {
        auto button = window->AddButton("Create chase car");
        button->onClick->Add([window]() {
            window->Close();
            
            ModelLoader::AddModelToLoad(404);
            ModelLoader::AddModelToLoad(15);
            ModelLoader::LoadAll([]() {

                auto playerPosition = GetPlayerPosition();
                auto spawnPosition = GET_CLOSEST_CAR_NODE(playerPosition.x, playerPosition.y, playerPosition.z);

                auto carRef = CREATE_CAR_AT(404, spawnPosition.x, spawnPosition.y, spawnPosition.z);
                auto car = Vehicles::RegisterVehicle(carRef);

                auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, 15);
                auto driver = Peds::RegisterPed(driverRef);

                auto passengerRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::Special, 15, 0);
                auto passenger = Peds::RegisterPed(passengerRef);

                car->originalDoc.isStolen = true;
                car->TryInitializePedsInside();
                car->ShowBlip(CRGBA(0, 255, 255));

                driver->flags.willSurrender = false;
                passenger->flags.willSurrender = false;
            });
        });
    }

    {
        auto button = window->AddButton("~r~" + GetTranslatedText("close"));
        button->onClick->Add([window]() {
            window->Close();
        });
    }
}

void TestWindow::TestEquip()
{
    g_onService = true;

    SET_MAX_WANTED_LEVEL_TO(0);
    SET_PLAYER_WANTED_LEVEL(0, 0);
    
    int playerActor = GET_PLAYER_ACTOR(0);
    
    if(!PedHasWeaponId(playerActor, 10))
    {
        GIVE_ACTOR_WEAPON(playerActor, 10, 1);
    }
    
    ModelLoader::AddModelToLoad(356);
    ModelLoader::AddModelToLoad(346);
    ModelLoader::AddModelToLoad(280);
    ModelLoader::LoadAll([playerActor]() {
        GIVE_ACTOR_WEAPON(playerActor, 31, 800);
        GIVE_ACTOR_WEAPON(playerActor, 22, 200);
        CHANGE_PLAYER_MODEL_TO(0, 280);
    });

    BottomMessage::SetMessage("Mod iniciado", 3000);

    if(g_enableDeepLog)
    {
        BottomMessage::SetMessage("Mod iniciado. ~r~DEEP LOG ~w~ativado", 3000);
    }
}