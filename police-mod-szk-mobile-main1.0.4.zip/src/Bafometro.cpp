#include "Bafometro.h"

#include "ModData.h"
#include "BottomMessage.h"
#include "IniReaderWriter.hpp"
#include "Logger.h"
#include "Peds.h"
#include "CleoFunctions.h"
#include "FriskPanel.h"

#include <filesystem>
#include <sstream>
#include <vector>
#include <iomanip>

float Bafometro::chanceLow = 0.7f;
float Bafometro::chanceMid = 0.2f;
float Bafometro::chanceHigh = 0.1f;
bool Bafometro::s_loaded = false;
std::map<int, float> Bafometro::s_resultsByPed;

std::string Bafometro::GetFolder()
{
    // mods/mods_data/policeModSZK/data/bafometro/
    return modData->GetFile("data/bafometro");
}

void Bafometro::Initialize()
{
    LoadSettings();
}

void Bafometro::LoadSettings()
{
    ModData::CreateFolder(modData->GetFile("data"));
    std::string folder = GetFolder();
    ModData::CreateFolder(folder);

    std::string path = folder + "/settings.ini";
    IniReaderWriter ini;
    if (ini.LoadFromFile(path))
    {
        chanceLow = (float)ini.GetDouble("chances", "chance_0_00_to_0_04", chanceLow);
        chanceMid = (float)ini.GetDouble("chances", "chance_0_05_to_0_33", chanceMid);
        chanceHigh = (float)ini.GetDouble("chances", "chance_above_0_34", chanceHigh);
    }
    else
    {
        SaveSettings();
    }

    if (chanceLow < 0.0f) chanceLow = 0.0f;
    if (chanceMid < 0.0f) chanceMid = 0.0f;
    if (chanceHigh < 0.0f) chanceHigh = 0.0f;

    s_loaded = true;
    fileLog->Log("Bafometro: chances low=" + std::to_string(chanceLow) +
                 " mid=" + std::to_string(chanceMid) +
                 " high=" + std::to_string(chanceHigh));
}

void Bafometro::SaveSettings()
{
    std::string folder = GetFolder();
    ModData::CreateFolder(folder);
    std::string path = folder + "/settings.ini";

    IniReaderWriter ini;
    ini.SetDouble("chances", "chance_0_00_to_0_04", chanceLow);
    ini.SetDouble("chances", "chance_0_05_to_0_33", chanceMid);
    ini.SetDouble("chances", "chance_above_0_34", chanceHigh);
    ini.SaveToFile(path);
}

float Bafometro::RollResult()
{
    if (!s_loaded)
        LoadSettings();

    float total = chanceLow + chanceMid + chanceHigh;
    if (total <= 0.0001f)
    {
        chanceLow = 0.7f;
        chanceMid = 0.2f;
        chanceHigh = 0.1f;
        total = 1.0f;
    }

    float r = (float)getRandomNumber(0, 9999) / 10000.0f;
    float nLow = chanceLow / total;
    float nMid = chanceMid / total;

    float value = 0.0f;
    if (r < nLow)
    {
        int v = getRandomNumber(0, 4);
        value = v / 100.0f;
    }
    else if (r < nLow + nMid)
    {
        int v = getRandomNumber(5, 33);
        value = v / 100.0f;
    }
    else
    {
        int v = getRandomNumber(34, 40);
        value = v / 100.0f;
    }
    return value;
}

float Bafometro::GetOrCreateResult(int pedRef)
{
    auto it = s_resultsByPed.find(pedRef);
    if (it != s_resultsByPed.end())
        return it->second;

    float value = RollResult();
    s_resultsByPed[pedRef] = value;
    return value;
}

void Bafometro::ShowResultMessage(float result)
{
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2) << result;

    std::string msg = "~b~Bafometro: ~w~" + oss.str() + " mg/L";
    std::string status = "Dentro do limite";
    if (result >= 0.34f)
    {
        msg = "~r~Bafometro: ~w~" + oss.str() + " mg/L ~r~(alto)";
        status = "~r~Acima do limite (alto)";
    }
    else if (result >= 0.05f)
    {
        msg = "~y~Bafometro: ~w~" + oss.str() + " mg/L";
        status = "~y~Atencao";
    }

    if (FriskPanel::UsePanel())
    {
        std::vector<std::string> lines;
        lines.push_back("Resultado: " + oss.str() + " mg/L");
        lines.push_back(status);
        FriskPanel::Show("BAFOMETRO", "BAF", "Teste de alcoolemia", lines);
    }

    if (FriskPanel::UseClassic() || !FriskPanel::UsePanel())
        BottomMessage::SetMessage(msg, 5000);
}

void Bafometro::PerformTest(Ped* ped)
{
    if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
    {
        BottomMessage::SetMessage("~r~Individuo invalido", 2500);
        return;
    }

    const int pedRef = ped->ref;

    // Intervalo de 3s com mensagem branca "medindo..."
    BottomMessage::SetMessage("~w~medindo...", 3000);

    WAIT(3000, [pedRef]() {
        auto p = Peds::GetPed(pedRef);
        if (!p || !Peds::IsValid(p) || !ACTOR_DEFINED(pedRef))
        {
            BottomMessage::SetMessage("~r~Individuo invalido", 2500);
            return;
        }

        // Mesmo individuo = mesma medida (carro ou a pe)
        float result = GetOrCreateResult(pedRef);
        ShowResultMessage(result);
    });
}
