#include <mod/amlmod.h>
#include <mod/config.h>

MYMODCFG(com.daniloszk.policemod, PoliceMod, 1.0.1, DaniloSZK)

#include "pch.h"

#include "PoliceMod.h"
#include "ModPolicia.h"
#include "IMultiRemap.h"
#include <mod/interface.h>

cleo_ifs_t* cleo = NULL;
ISAUtils* sautils = NULL;
IMenuSZK* menuSZK = NULL;
IMultiRemap* multiRemap = NULL;

ModData* modData = new ModData("policeModSZK");
Logger* localLogger = new Logger("policeModSZK");

extern "C" void OnModPreLoad()
{
    fileLog->Clear();
    fileLog->Log("Log initialized");
    fileLog->Log("OnModPreLoad");

    // Interface para o GiroflexVSL sincronizar luzes nas viaturas DualPatrol
    // (chamado so no clique do botao de luz — nao por frame)
    RegisterInterface("ModPolicia", modPolicia);
    fileLog->Log("Registered interface ModPolicia (DualPatrol giroflex sync)");

    modData->LoadSettings();
    
    policeMod->OnModPreLoad();
}

extern "C" void OnModLoad()
{
    fileLog->Log("OnModLoad");

    loadInterface(&cleo, "CLEO", true);
    if(!cleo) return;

    loadInterface(&menuSZK, "MenuSZK");
    if(!menuSZK) return;

    loadInterface(&sautils, "SAUtils");
    if(!sautils) return;

    // MultiRemap opcional — se nao estiver instalado, remap e ignorado
    loadInterface(&multiRemap, "MultiRemap");
    if (multiRemap)
        fileLog->Log("MultiRemap interface loaded");
    else
        fileLog->Log("MultiRemap not found (optional)");

    fileLog->Log("Finding addresses...");

    DoHooks();

    fileLog->Log("Initializing policeMod...");

    policeMod->OnModLoad();

    fileLog->Log("Mod loaded!");
}