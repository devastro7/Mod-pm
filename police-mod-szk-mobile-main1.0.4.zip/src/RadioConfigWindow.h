#pragma once

#include "pch.h"

class RadioConfigWindow {
public:
    static void OpenWindow();
};
