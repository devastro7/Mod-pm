#include "FriskWindow.h"
#include "ItemDefinition.h"
#include "Peds.h"
#include "FriskPanel.h"

static void CollectPedItems(Ped* ped, std::vector<std::string>& out)
{
    out.clear();
    if (!ped) return;
    for (const auto& item : ped->inventory.GetItems())
    {
        auto def = item.GetDefinition();
        std::string text = FormatAmount(*def, item.GetAmount());
        if (def && def->isIllegal) text = "~r~" + text;
        out.push_back(text);
    }
}

static void CollectVehicleItems(Vehicle* vehicle, std::vector<std::string>& out)
{
    out.clear();
    if (!vehicle) return;
    for (const auto& item : vehicle->inventory.GetItems())
    {
        auto def = item.GetDefinition();
        std::string text = FormatAmount(*def, item.GetAmount());
        if (def && def->isIllegal) text = "~r~" + text;
        out.push_back(text);
    }
}

void FriskWindow::OpenForPed(Ped* ped)
{
    if (!ped) return;

    int style = FRISK_UI_STYLE;
    if (style < 0) style = 0;
    if (style > 2) style = 2;

    std::vector<std::string> items;
    CollectPedItems(ped, items);

    int pedRef = ped->ref;
    ped->flags.isBeingFrisked = true;
    g_blockInteractions = true;

    // Painel novo (1 ou 2)
    if (style == 1 || style == 2)
    {
        FriskPanel::SetOnClosed([pedRef, style]() {
            // Se so painel, libera tudo ao fechar o painel
            if (style == 1)
            {
                g_blockInteractions = false;
                auto p = Peds::GetPed(pedRef);
                if (p && Peds::IsValid(p))
                    p->flags.isBeingFrisked = false;
            }
        });
        FriskPanel::Show(items, "Individuo - itens encontrados");
    }

    // Menu classico (0 ou 2)
    if (style == 0 || style == 2)
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_frisk"));

        if (items.empty())
            window->AddText("~r~Nada aqui...");

        for (const auto& text : items)
        {
            auto button = window->AddButton(text);
            button->onClick->Add([](){});
        }

        auto button = window->AddButton("~y~" + GetTranslatedText("close"));
        button->onClick->Add([window, pedRef, style]() {
            window->Close();
            // Se tem painel junto, so libera interacao/flags quando painel tambem sumir
            if (style == 0 || !FriskPanel::IsVisible())
            {
                g_blockInteractions = false;
                auto p = Peds::GetPed(pedRef);
                if (p && Peds::IsValid(p))
                    p->flags.isBeingFrisked = false;
            }
        });
    }
}

void FriskWindow::OpenForVehicle(Vehicle* vehicle)
{
    if (!vehicle) return;

    int style = FRISK_UI_STYLE;
    if (style < 0) style = 0;
    if (style > 2) style = 2;

    vehicle->TryInitializeCarInventory();
    std::vector<std::string> items;
    CollectVehicleItems(vehicle, items);

    g_blockInteractions = true;

    if (style == 1 || style == 2)
    {
        FriskPanel::SetOnClosed([style]() {
            if (style == 1)
                g_blockInteractions = false;
        });
        FriskPanel::Show(items, "Veiculo - itens encontrados");
    }

    if (style == 0 || style == 2)
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Revista do veiculo");

        if (items.empty())
            window->AddText("~r~Nada no veiculo...");

        for (const auto& text : items)
        {
            auto button = window->AddButton(text);
            button->onClick->Add([](){});
        }

        auto button = window->AddButton("~y~Fechar");
        button->onClick->Add([window, style]() {
            window->Close();
            if (style == 0 || !FriskPanel::IsVisible())
                g_blockInteractions = false;
        });
    }
}
