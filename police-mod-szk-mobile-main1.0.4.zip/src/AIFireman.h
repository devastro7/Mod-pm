#pragma once

#include "pch.h"
#include "AIPed.h"
#include "Ped.h"
#include "Vehicle.h"

// Bombeiro: fica no caminhão, identifica sucata/fogo, "joga água" 2s e apaga.
class AIFireman : public AIPed {
public:
    CVector targetPosition = CVector();

    bool hasArrived = false;
    bool leaveScheduled = false;
    bool isLeaving = false;
    bool isSpraying = false;

    ~AIFireman() override;

    void Start() override;
    void Update() override;

    Vehicle* FindWreckOrBurningNearby(float radius);
    void SprayAndExtinguish(Vehicle* wreck, Vehicle* truck);
    void ExtinguishAt(CVector pos, float radius);
    void LeaveScene(Vehicle* vehicle);
};
