#pragma once
#include "pch.h"
class RadioExtrasWindow {
public:
    static void OpenWindow();
};
