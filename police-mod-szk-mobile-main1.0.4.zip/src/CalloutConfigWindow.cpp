#include "CalloutConfigWindow.h"

#include "BottomMessage.h"
#include "Callouts.h"
#include "ModData.h"

void CalloutConfigWindow::OpenWindow()
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Ocorrencias");

    // Filtro de nivel: 0 = Todas | 1..5 = so aquele nivel
    // Cores: Todas ciano, 1 verde, 2 e 3 amarelo, 4 vermelho, 5 preto
    {
        auto options = window->AddOptions("Selecionar ocorrencias");
        options->AddOption("~b~Todas", 0);
        options->AddOption("~g~Nivel 1", 1);
        options->AddOption("~y~Nivel 2", 2);
        options->AddOption("~y~Nivel 3", 3); // amarelo (nao roxo)
        options->AddOption("~r~Nivel 4", 4);
        options->AddOption("~l~Nivel 5", 5);

        int idx = CALLOUT_LEVEL_FILTER;
        if (idx < 0) idx = 0;
        if (idx > 5) idx = 5;
        options->SetOptionIndex(idx);

        // So aplica em memoria; grava ao Fechar
        options->onOptionChange->Add([options]() {
            int v = options->GetCurrentOptionValue();
            if (v < 0) v = 0;
            if (v > 5) v = 5;
            CALLOUT_LEVEL_FILTER = v;
        });
    }

    // Intervalo entre ocorrencias (seconds_between_callouts), de 5 em 5
    {
        auto options = window->AddOptions("Tempo entre ocorrencias (s)");
        int selectedIdx = 0;
        int i = 0;
        // 5 .. 300 de 5 em 5
        for (int v = 5; v <= 300; v += 5)
        {
            options->AddOption(std::to_string(v), v);
            if (v == g_secondsBetweenCallouts) selectedIdx = i;
            i++;
        }
        // Se valor atual nao for multiplo de 5, aproxima e seleciona o mais proximo
        if (g_secondsBetweenCallouts < 5)
        {
            g_secondsBetweenCallouts = 5;
            selectedIdx = 0;
        }
        else if (g_secondsBetweenCallouts > 300)
        {
            g_secondsBetweenCallouts = 300;
            selectedIdx = (300 - 5) / 5;
        }
        else if ((g_secondsBetweenCallouts % 5) != 0)
        {
            int rounded = ((g_secondsBetweenCallouts + 2) / 5) * 5;
            if (rounded < 5) rounded = 5;
            if (rounded > 300) rounded = 300;
            g_secondsBetweenCallouts = rounded;
            selectedIdx = (rounded - 5) / 5;
        }
        options->SetOptionIndex(selectedIdx);

        options->onOptionChange->Add([options]() {
            int v = options->GetCurrentOptionValue();
            if (v < 5) v = 5;
            if (v > 300) v = 300;
            g_secondsBetweenCallouts = v;
        });
    }

    {
        auto button = window->AddButton("~y~Fechar");
        button->onClick->Add([window]() {
            // Salva filtro + intervalo so ao fechar
            modData->SaveSettings();

            const char* label = "Todas";
            switch (CALLOUT_LEVEL_FILTER)
            {
                case 1: label = "Nivel 1"; break;
                case 2: label = "Nivel 2"; break;
                case 3: label = "Nivel 3"; break;
                case 4: label = "Nivel 4"; break;
                case 5: label = "Nivel 5"; break;
                default: label = "Todas"; break;
            }
            BottomMessage::SetMessage(
                std::string("~w~Ocorrencias: ~y~") + label +
                " ~w~| Intervalo: ~y~" + std::to_string(g_secondsBetweenCallouts) + "s",
                3000);
            window->Close();
        });
    }
}
