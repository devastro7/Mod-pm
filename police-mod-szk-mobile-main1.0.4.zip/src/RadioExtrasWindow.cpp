#include "RadioExtrasWindow.h"
#include "TrafficControl.h"
#include "BottomMessage.h"
#include "Callouts.h"
#include "callouts/ArmoredCarRobberyCallout.h"
#include "Criminals.h"
#include "Chase.h"
#include "BackupUnits.h"
#include "Vehicles.h"
#include "Peds.h"
#include "DualPatrol.h"
#include "Partners.h"
#include "AIController.h"
#include "CleoFunctions.h"

#include <unordered_set>

extern bool g_onACallout;
extern bool g_calloutReached;
extern bool g_spawnedCriminals;
extern bool g_kidnapRegionActive;

static void OpenAbortConfirmWindow()
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Abort everyone");

    {
        auto button = window->AddButton("~r~Abort");
        button->onClick->Add([window]() {
            // Fecha menu antes de limpar (evita SIGILL)
            WAIT(0, [window]() {
                if (window) window->Close();
            });

            WAIT(50, []() {
                // --- Estado de ocorrencia ---
                g_onACallout = false;
                g_calloutReached = false;
                g_spawnedCriminals = false;
                g_kidnapRegionActive = false;
                g_customCalloutEndMessage.clear();
                g_bankRobberyHeliActive = false;
                g_bankRobberyHeliCarRef = -1;
                g_armoredSecCarRef = -1;
                g_armoredCrimCarRef = -1;

                // Remove blip/marker amarelo da ocorrencia no mapa
                ClearActiveCalloutMarker();

                // --- Criminosos ---
                auto criminals = *Criminals::GetCriminals();
                for (auto criminal : criminals)
                {
                    if (!criminal) continue;
                    Criminals::RemoveCriminal(criminal);
                    AIController::RemoveAIsFromPed(criminal);
                    criminal->HideBlip();
                    criminal->QueueDestroy();
                }

                // --- Chase ---
                Chase::AbortChase();

                // Protegidos: comboio DualPatrol + parceiros
                std::unordered_set<Vehicle*> protectedVehicles;
                for (auto v : DualPatrol::escortVehicles)
                {
                    if (v) protectedVehicles.insert(v);
                }

                std::unordered_set<Ped*> protectedPeds;
                for (auto p : Partners::GetPartners())
                {
                    if (p) protectedPeds.insert(p);
                }

                // --- Reforco / backup ---
                {
                    auto backups = BackupUnits::backupVehicles;
                    for (auto vehicle : backups)
                    {
                        if (!vehicle) continue;
                        if (protectedVehicles.count(vehicle)) continue;

                        AIController::RemoveAIsFromVehicle(vehicle);
                        for (auto owner : vehicle->GetOwners())
                        {
                            auto ped = Peds::GetPed(owner);
                            if (!ped) continue;
                            if (protectedPeds.count(ped)) continue;
                            AIController::RemoveAIsFromPed(ped);
                            ped->QueueDestroy();
                        }
                        vehicle->HideBlip();
                        vehicle->QueueDestroy(false);
                    }
                    BackupUnits::backupVehicles.clear();
                }

                // --- Veiculos de ocorrencia / chase / criminosos (nao comboio) ---
                {
                    auto map = Vehicles::GetVehiclesMap();
                    int playerCar = -1;
                    if (IS_CHAR_IN_ANY_CAR(GetPlayerActor()))
                        playerCar = GetVehiclePedIsUsing(GetPlayerActor());

                    for (auto& kv : map)
                    {
                        Vehicle* vehicle = kv.second;
                        if (!vehicle) continue;
                        if (protectedVehicles.count(vehicle)) continue;
                        if (playerCar > 0 && vehicle->ref == playerCar) continue;

                        // So limpa se tem blip de criminal/ocorrencia, widget, ou sem dono de parceiro
                        bool isCalloutRelated =
                            vehicle->flags.showWidget ||
                            vehicle->flags.showBlip ||
                            Chase::IsVehicleRunningFromCops(vehicle);

                        // Ocupantes criminosos / mortos
                        bool hasCriminalOrDead = false;
                        for (auto pedRef : vehicle->GetCurrentOccupants())
                        {
                            auto ped = Peds::GetPed(pedRef);
                            if (!ped) continue;
                            if (protectedPeds.count(ped)) { hasCriminalOrDead = false; break; }
                            // se for criminal marcado ou morto
                            hasCriminalOrDead = true;
                        }

                        if (!isCalloutRelated && !hasCriminalOrDead)
                            continue;

                        AIController::RemoveAIsFromVehicle(vehicle);
                        for (auto owner : vehicle->GetOwners())
                        {
                            auto ped = Peds::GetPed(owner);
                            if (!ped) continue;
                            if (protectedPeds.count(ped)) continue;
                            AIController::RemoveAIsFromPed(ped);
                            ped->QueueDestroy();
                        }
                        vehicle->HideBlip();
                        vehicle->QueueDestroy(false);
                    }
                }

                // --- Peds mortos / criminosos no chao (exceto parceiros) ---
                {
                    // ja removemos da lista de criminosos; varre peds registrados se houver API
                    // (Peds map)
                }

                Chase::vehiclesInChase.clear();

                // Remove blips restantes de peds/veiculos da ocorrencia (exceto parceiros/comboio)
                {
                    for (auto& kv : Vehicles::GetVehiclesMap())
                    {
                        auto vehicle = kv.second;
                        if (!vehicle) continue;
                        if (protectedVehicles.count(vehicle)) continue;
                        vehicle->HideBlip();
                        vehicle->flags.showWidget = false;
                    }
                    for (auto& kv : Peds::GetPedsMap())
                    {
                        auto ped = kv.second;
                        if (!ped) continue;
                        if (protectedPeds.count(ped)) continue;
                        ped->HideBlip();
                        ped->flags.showWidget = false;
                    }
                }

                // Garante marker limpo de novo (caso algum task tenha recriado)
                ClearActiveCalloutMarker();

                BottomMessage::SetMessage("~y~Abort: ocorrencias e reforcos limpos", 4000);
            });
        });
    }

    {
        auto button = window->AddButton("~w~Voltar");
        button->onClick->Add([window]() {
            WAIT(0, [window]() {
                if (window) window->Close();
                RadioExtrasWindow::OpenWindow();
            });
        });
    }
}

void RadioExtrasWindow::OpenWindow()
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Opcoes Extras");

    {
        auto options = window->AddOptions("Parar trafego");
        options->AddOption("Off", 0);
        options->AddOption("On", 1);
        options->SetOptionIndex(TrafficControl::IsEnabled() ? 1 : 0);
        options->onOptionChange->Add([options]() {
            bool on = (options->GetCurrentOptionValue() == 1);
            TrafficControl::SetEnabled(on);
            if (on)
                BottomMessage::SetMessage("~y~Trafego parado", 2500);
            else
                BottomMessage::SetMessage("~g~Trafego normal", 2500);
        });
    }

    {
        auto button = window->AddButton("~r~Abort everyone");
        button->onClick->Add([window]() {
            WAIT(0, [window]() {
                if (window) window->Close();
                OpenAbortConfirmWindow();
            });
        });
    }

    {
        auto button = window->AddButton("~y~Fechar");
        button->onClick->Add([window]() {
            WAIT(0, [window]() {
                if (window) window->Close();
            });
        });
    }
}
