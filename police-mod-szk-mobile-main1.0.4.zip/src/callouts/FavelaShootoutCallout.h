#pragma once
#include "../pch.h"
#include "CalloutBase.h"

class FavelaShootoutCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    void OnAccept() override;
    int GetWeight() const override { return CALLOUT_WEIGHT_FAVELA_SHOOTOUT; }
    int GetLevel() const override { return CALLOUT_LEVEL_FAVELA_SHOOTOUT; }
};
