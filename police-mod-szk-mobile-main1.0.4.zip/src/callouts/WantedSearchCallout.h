#pragma once

#include "../pch.h"
#include "CalloutBase.h"

// Busca e apreensao: individuo procurado na area (blip grande no radar, sem blip 3D)
class WantedSearchCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    void OnAccept() override;
    int GetWeight() const override;
    int GetLevel() const override;
};
