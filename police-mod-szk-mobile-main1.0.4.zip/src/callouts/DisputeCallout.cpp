#include "DisputeCallout.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../CleoFunctions.h"
#include "../ScriptTask.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"

#include <vector>
#include <cmath>

extern bool g_calloutReached;

// No de pedestre entre 200m e 1500m do player
static CVector GetPedPathInRange(float minDist, float maxDist)
{
    auto player = GetPlayerPosition();
    std::vector<CVector> ok;

    for (int i = 0; i < 24; i++)
    {
        float ang = (float)getRandomNumber(0, 359) * 0.017453292f;
        float dist = (float)getRandomNumber((int)minDist, (int)maxDist);
        float tx = player.x + cosf(ang) * dist;
        float ty = player.y + sinf(ang) * dist;
        auto node = STORE_PED_PATH_COORDS_CLOSEST_TO(tx, ty, player.z);
        if (node.z < -50.0f || node.z > 800.0f) continue;
        float d = distanceBetweenPoints(player, node);
        if (d >= minDist && d <= maxDist)
            ok.push_back(node);
    }

    if (!ok.empty())
        return ok[getRandomNumber(0, (int)ok.size() - 1)];

    // fallback
    return STORE_PED_PATH_COORDS_CLOSEST_TO(player.x + 400.0f, player.y + 400.0f, player.z);
}

std::string DisputeCallout::GetBroadcastMessage()
{
    return "Desentendimento em via publica";
}

AudioVariationGroup* DisputeCallout::GetBroadcastAudio()
{
    return nullptr;
}

int DisputeCallout::GetWeight() const
{
    return 30;
}

void DisputeCallout::OnAccept()
{
    BottomMessage::SetMessage("~w~Procure a ~y~area ~w~marcada no radar", 4000);

    CVector position = GetPedPathInRange(200.0f, 1500.0f);

    // So blip grande no radar (sem marker 3D)
    g_kidnapRegionPos = position;
    g_kidnapRegionActive = true;

    ScriptTask* taskApproach = new ScriptTask("dispute_approach");
    taskApproach->onBegin = []() {};
    taskApproach->onExecute = [position]() {
        // Spawna quando player chega perto da area (~250m)
        if (distanceBetweenPoints(GetPlayerPosition(), position) > 250.0f)
            return SCRIPT_KEEP_GOING;
        return SCRIPT_SUCCESS;
    };
    taskApproach->onComplete = [position]() {
        g_calloutReached = true;
        BottomMessage::SetMessage("~r~Desentendimento no local — intervenha", 4000);

        int skinAtk = GetSafeRandomPedSkin();
        int skinVic = GetSafeRandomPedSkin();
        if (skinAtk <= 0) skinAtk = 7;
        if (skinVic <= 0) skinVic = 19;
        if (skinVic == skinAtk) skinVic = (skinAtk == 7) ? 19 : 7;

        ModelLoader::AddModelToLoad(skinAtk);
        ModelLoader::AddModelToLoad(skinVic);
        ModelLoader::LoadAll([skinAtk, skinVic, position]() {
            if (!HAS_MODEL_LOADED(skinAtk) || !HAS_MODEL_LOADED(skinVic)) return;

            auto ground = STORE_PED_PATH_COORDS_CLOSEST_TO(position.x, position.y, position.z);

            int atkRef = CREATE_ACTOR_PEDTYPE(PedType::CivMale, skinAtk, ground.x, ground.y, ground.z);
            if (!ACTOR_DEFINED(atkRef)) return;
            auto atk = Peds::RegisterPed(atkRef);
            REMOVE_REFERENCES_TO_ACTOR(atkRef);
            if (!atk) return;

            Criminals::AddCriminal(atk);
            // SEM blip 3D
            atk->flags.willSurrender = false;
            atk->flags.willKillCops = false;
            atk->flags.showWidget = true;
            SET_ACTOR_HEALTH(atkRef, 350.0f);
            if (ACTOR_DEFINED(atkRef))
            {
                GIVE_ACTOR_WEAPON(atkRef, 4, 1);
                SET_CURRENT_ACTOR_WEAPON(atkRef, 4);
            }

            auto near = STORE_PED_PATH_COORDS_CLOSEST_TO(ground.x + 2.0f, ground.y + 2.0f, ground.z);
            int vicRef = CREATE_ACTOR_PEDTYPE(PedType::CivMale, skinVic, near.x, near.y, near.z);
            if (!ACTOR_DEFINED(vicRef)) return;
            auto vic = Peds::RegisterPed(vicRef);
            REMOVE_REFERENCES_TO_ACTOR(vicRef);
            if (!vic) return;

            // Vitima corre; agressor persegue a pe
            if (ACTOR_DEFINED(vicRef) && ACTOR_DEFINED(atkRef))
            {
                FLEE_FROM_ACTOR(vicRef, atkRef, 120.0f, -1);
                KILL_ACTOR(atkRef, vicRef);
            }

            // Blip grande: a cada 10s atualiza para a posicao atual do agressor e fica 10s
            int* pBlipTimer = new int(0);
            int* pChaseTimer = new int(0);
            g_kidnapRegionPos = GetPedPosition(atkRef);
            g_kidnapRegionActive = true;

            ScriptTask* monitor = new ScriptTask("dispute_region_blip");
            monitor->onBegin = []() {};
            monitor->onExecute = [atkRef, vicRef, pBlipTimer, pChaseTimer]() {
                if (!Callouts::IsInCallout())
                {
                    g_kidnapRegionActive = false;
                    delete pBlipTimer;
                    delete pChaseTimer;
                    return SCRIPT_CANCEL;
                }

                int dt = menuSZK ? menuSZK->deltaTime : 50;

                // Reemite perseguicao a cada 3s
                *pChaseTimer += dt;
                if (*pChaseTimer >= 3000)
                {
                    *pChaseTimer = 0;
                    if (ACTOR_DEFINED(atkRef) && !ACTOR_DEAD(atkRef) &&
                        ACTOR_DEFINED(vicRef) && !ACTOR_DEAD(vicRef))
                    {
                        auto ap = Peds::GetPed(atkRef);
                        if (ap && !ap->flags.hasSurrended && !ap->flags.isHandcuffed)
                        {
                            CLEAR_ACTOR_TASK(atkRef);
                            KILL_ACTOR(atkRef, vicRef);
                        }
                        FLEE_FROM_ACTOR(vicRef, atkRef, 120.0f, -1);
                    }
                }

                // A cada 10s: "apaga e gera" blip na posicao atual do individuo
                *pBlipTimer += dt;
                if (*pBlipTimer >= 10000)
                {
                    *pBlipTimer = 0;
                    if (ACTOR_DEFINED(atkRef) && !ACTOR_DEAD(atkRef))
                    {
                        g_kidnapRegionPos = GetPedPosition(atkRef);
                        g_kidnapRegionActive = true;
                    }
                    else if (ACTOR_DEFINED(vicRef) && !ACTOR_DEAD(vicRef))
                    {
                        g_kidnapRegionPos = GetPedPosition(vicRef);
                        g_kidnapRegionActive = true;
                    }
                    else
                    {
                        g_kidnapRegionActive = false;
                        delete pBlipTimer;
                        delete pChaseTimer;
                        return SCRIPT_CANCEL;
                    }
                }

                return SCRIPT_KEEP_GOING;
            };
            monitor->onComplete = []() {};
            monitor->Start();
        });
    };
    taskApproach->Start();
}
