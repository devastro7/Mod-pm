#include "FavelaShootoutCallout.h"
#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../CleoFunctions.h"
#include "../ScriptTask.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"
#include "../DualPatrol.h"

extern bool g_calloutReached;
extern int g_calloutEndGraceMs;

// Cada favela = 1 ocorrencia com 3 pontos de spawn (4 criminosos por ponto = 12 total)
struct FavelaSite {
    CVector points[3];
};

static const FavelaSite FAVELAS[] = {
    // Favela 1
    {{
        CVector(1199.88f, -2036.74f, 69.01f),
        CVector(1257.66f, -2006.27f, 59.69f),
        CVector(1202.34f, -2069.95f, 69.01f),
    }},
    // Favela 2
    {{
        CVector(2779.41f, -2341.32f, 13.63f),
        CVector(2717.69f, -2341.35f, 13.63f),
        CVector(2774.23f, -2263.09f, 13.80f),
    }},
    // Favela 3
    {{
        CVector(2573.87f, -991.94f, 79.94f),
        CVector(2549.19f, -939.82f, 83.24f),
        CVector(2512.94f, -974.63f, 82.04f),
    }},
    // Favela 4
    {{
        CVector(2012.13f, -1211.09f, 20.10f),
        CVector(1993.90f, -1179.16f, 20.02f),
        CVector(1949.93f, -1180.79f, 20.02f),
    }},
};
static const int FAVELA_COUNT = 4;
static const int POINTS_PER_FAVELA = 3;
static const int CRIMS_PER_POINT = 4;

// Evita repetir a mesma favela em sequencia
static int s_lastFavelaIdx = -1;

// Armas: mistura AK-47 (30), pistola (22), Uzi (28)
static int PickFavelaWeapon(int indexInGroup)
{
    // Por grupo de 4: 2x AK, 1x Uzi, 1x pistola (varia um pouco)
    switch (indexInGroup % 4)
    {
        case 0: return 30; // AK-47
        case 1: return 30; // AK-47
        case 2: return 28; // Uzi
        default: return 22; // pistola
    }
}

std::string FavelaShootoutCallout::GetBroadcastMessage()
{
    return "Tiroteio na favela em andamento";
}

AudioVariationGroup* FavelaShootoutCallout::GetBroadcastAudio()
{
    return audioCalloutFavelaShootout;
}

void FavelaShootoutCallout::OnAccept()
{
    BottomMessage::SetMessage("~w~Desloque-se ate o ~y~local ~w~no mapa", 3000);

    // Sorteio aleatorio real; se cair a mesma da ultima vez, tenta de novo
    int favelaIdx = getRandomNumber(0, FAVELA_COUNT - 1);
    if (FAVELA_COUNT > 1)
    {
        for (int attempt = 0; attempt < 8; ++attempt)
        {
            if (favelaIdx != s_lastFavelaIdx) break;
            favelaIdx = getRandomNumber(0, FAVELA_COUNT - 1);
        }
        // Se ainda repetiu, forca o proximo indice
        if (favelaIdx == s_lastFavelaIdx)
            favelaIdx = (s_lastFavelaIdx + 1 + getRandomNumber(0, FAVELA_COUNT - 2)) % FAVELA_COUNT;
    }
    s_lastFavelaIdx = favelaIdx;
    const FavelaSite& site = FAVELAS[favelaIdx];

    // Marker no ponto central (media dos 3) / primeiro ponto
    CVector markerPos = site.points[0];
    int marker = CreateMarker(markerPos.x, markerPos.y, markerPos.z, 0, 3, 3);

    ScriptTask* task = new ScriptTask("favela_approach");
    task->onBegin = []() {};
    task->onExecute = [markerPos]() {
        if (distanceBetweenPoints(GetPlayerPosition(), markerPos) > 120.0f)
            return SCRIPT_KEEP_GOING;
        return SCRIPT_SUCCESS;
    };
    task->onComplete = [marker, site, markerPos]() {
        DISABLE_MARKER(marker);
        g_calloutReached = true;

        if (AGUIA_FAVELA_ENABLED == 1)
            BottomMessage::SetMessage("~r~Tiroteio na favela — Aguia em orbita!", 4000);
        else
            BottomMessage::SetMessage("~r~Tiroteio na favela — cuidado!", 4000);

        // Carrega skins + armas (modelos) + heli se aguia
        std::vector<int> skins;
        const int totalCrims = POINTS_PER_FAVELA * CRIMS_PER_POINT;
        skins.reserve(totalCrims);
        for (int i = 0; i < totalCrims; i++)
        {
            int s = GetSafeRandomPedSkin();
            if (s <= 0) s = 7;
            skins.push_back(s);
            ModelLoader::AddModelToLoad(s);
        }

        // Modelos de arma (pistola/uzi/ak)
        ModelLoader::AddModelToLoad(346); // colt
        ModelLoader::AddModelToLoad(352); // uzi
        ModelLoader::AddModelToLoad(355); // ak

        if (AGUIA_FAVELA_ENABLED == 1)
        {
            ModelLoader::AddModelToLoad(AGUIA_FAVELA_MODEL_ID); // heli config
            ModelLoader::AddModelToLoad(280); // piloto
        }

        ModelLoader::LoadAll([skins, site, markerPos, totalCrims]() {
            std::vector<int> spawnedRefs;
            spawnedRefs.reserve(totalCrims);

            int skinIdx = 0;
            for (int p = 0; p < POINTS_PER_FAVELA; p++)
            {
                CVector base = site.points[p];
                for (int c = 0; c < CRIMS_PER_POINT; c++)
                {
                    int skin = skins[skinIdx++];
                    if (!HAS_MODEL_LOADED(skin)) continue;

                    float ox = (float)getRandomNumber(-3, 3);
                    float oy = (float)getRandomNumber(-3, 3);
                    auto pos = STORE_PED_PATH_COORDS_CLOSEST_TO(base.x + ox, base.y + oy, base.z);
                    int ref = CREATE_ACTOR_PEDTYPE(PedType::CivMale, skin, pos.x, pos.y, pos.z);
                    if (!ACTOR_DEFINED(ref)) continue;

                    auto ped = Peds::RegisterPed(ref);
                    if (!ped) continue;

                    Criminals::AddCriminal(ped);
                    ped->ShowBlip(COLOR_CRIMINAL);
                    ped->flags.willSurrender = false;
                    ped->flags.willKillCops = true;
                    ped->flags.showWidget = true;
                    SET_ACTOR_HEALTH(ref, 550.0f);

                    int weap = PickFavelaWeapon(c);
                    int ammo = (weap == 30) ? 300 : 200;
                    GIVE_ACTOR_WEAPON(ref, weap, ammo);
                    SET_CURRENT_ACTOR_WEAPON(ref, weap);

                    spawnedRefs.push_back(ref);
                }
            }

            // Aguia automatico so na favela — config em [aguia_favela] do settings.ini
            if (AGUIA_FAVELA_ENABLED == 1)
            {
                bool clockwise = (AGUIA_FAVELA_DIRECTION == 0);
                DualPatrol::SpawnOrbitLockHeliAt(
                    markerPos,
                    AGUIA_FAVELA_MODEL_ID,
                    AGUIA_FAVELA_HEIGHT,
                    AGUIA_FAVELA_RADIUS,
                    AGUIA_FAVELA_SPEED,
                    AGUIA_FAVELA_ANGLE,
                    clockwise
                );
            }

            // Atrasa ataque para anim/arma estabilizar
            WAIT(500, [spawnedRefs]() {
                for (int ref : spawnedRefs)
                {
                    if (!ACTOR_DEFINED(ref) || ACTOR_DEAD(ref)) continue;
                    KILL_ACTOR(ref, GetPlayerActor());
                }
            });

            g_calloutEndGraceMs = 25000;
        });
    };
    task->Start();
}
