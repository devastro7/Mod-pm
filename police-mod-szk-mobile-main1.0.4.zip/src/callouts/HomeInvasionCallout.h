#pragma once

#include "../pch.h"

#include "CalloutBase.h"

class HomeInvasionCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;

    void OnAccept() override;

    int GetWeight() const override { return CALLOUT_WEIGHT_HOME_INVASION; }
    int GetLevel() const override { return CALLOUT_LEVEL_HOME_INVASION; }
};
