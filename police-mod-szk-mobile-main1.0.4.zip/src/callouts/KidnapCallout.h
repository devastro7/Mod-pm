#pragma once

#include "../pch.h"
#include "CalloutBase.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../ScriptTask.h"
#include "../CleoFunctions.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"
#include "../Vehicles.h"
#include "../Chase.h"

extern bool g_calloutReached;

class KidnapCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override
    {
        return "Ocorrencia de sequestro em andamento. Veiculo com multiplos ocupantes.";
    }

    AudioVariationGroup* GetBroadcastAudio() override
    {
        return audioCalloutKidnap; // pode ser nullptr se arquivos nao existirem — Callouts trata
    }

    int GetWeight() const override { return CALLOUT_WEIGHT_KIDNAP; }
    int GetLevel() const override { return CALLOUT_LEVEL_KIDNAP; }

    void OnAccept() override
    {
        BottomMessage::SetMessage("~w~Desloque-se ate o ~y~local do sequestro ~w~no mapa", 3000);

        const float CALLOUT_DISTANCE = 800.0f;

        auto playerActor = GET_PLAYER_ACTOR(0);
        auto distX = getRandomNumber(-CALLOUT_DISTANCE, CALLOUT_DISTANCE);
        auto distY = getRandomNumber(-CALLOUT_DISTANCE, CALLOUT_DISTANCE);

        float x = 0, y = 0, z = 0;
        STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, (float)distX, (float)distY, 0, &x, &y, &z);

        auto carNodePosition = GET_CLOSEST_CAR_NODE(x, y, z);

        int approachMarker = CreateMarker(carNodePosition.x, carNodePosition.y, carNodePosition.z, 5, 3, 3);

        ScriptTask* taskApproach = new ScriptTask("kidnap_approach");
        taskApproach->onBegin = []() {};
        taskApproach->onExecute = [carNodePosition]() {
            auto playerPosition = GetPlayerPosition();
            auto distance = distanceBetweenPoints(playerPosition, carNodePosition);
            if (distance > 150.0f) return SCRIPT_KEEP_GOING;
            return SCRIPT_SUCCESS;
        };
        taskApproach->onComplete = [approachMarker, carNodePosition]() {
            g_calloutReached = true;
            DISABLE_MARKER(approachMarker);

            // Blip grande estilo QTH, vermelho, FIXO — some apos 20 segundos
            g_kidnapRegionPos = carNodePosition;
            g_kidnapRegionActive = true;
            WAIT(20000, []() {
                g_kidnapRegionActive = false;
            });

            BottomMessage::SetMessage("~r~Procure o veiculo na area marcada ~w~(regiao vermelha, 20s)", 5000);

            // Veiculos permitidos (sorteio)
            static const int kVehicles[] = { 507, 529, 551, 445, 585 };
            const int vehicleModel = kVehicles[getRandomNumber(0, 4)];

            int skinDriver = GetRandomCriminalSkin();
            int skin1 = GetRandomCriminalSkin();
            int skin2 = GetRandomCriminalSkin();
            int skin3 = GetRandomCriminalSkin();

            ModelLoader::AddModelToLoad(vehicleModel);
            ModelLoader::AddModelToLoad(skinDriver);
            ModelLoader::AddModelToLoad(skin1);
            ModelLoader::AddModelToLoad(skin2);
            ModelLoader::AddModelToLoad(skin3);
            ModelLoader::AddModelToLoad(346);

            ModelLoader::LoadAll([vehicleModel, skinDriver, skin1, skin2, skin3, carNodePosition]() {
                int carRef = CREATE_CAR_AT(vehicleModel, carNodePosition.x, carNodePosition.y, carNodePosition.z);
                auto car = Vehicles::RegisterVehicle(carRef);
                car->flags.showWidget = false; // sem blip no veiculo

                int driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::CivMale, skinDriver);
                auto driver = Peds::RegisterPed(driverRef);

                int passSkins[3] = { skin1, skin2, skin3 };
                Ped* passengers[3] = { nullptr, nullptr, nullptr };

                for (int seat = 0; seat < 3; seat++)
                {
                    int pref = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::CivMale, passSkins[seat], seat);
                    passengers[seat] = Peds::RegisterPed(pref);
                }

                int victimSeat = getRandomNumber(0, 2);
                Ped* victim = passengers[victimSeat];

                auto setupKidnapper = [](Ped* ped) {
                    if (!ped) return;
                    // Sequestrador armado — IA de fuga/reacao (igual fuga de carro)
                    ped->flags.willSurrender = false;
                    ped->flags.willKillCops = true;
                    ped->flags.isKidnapVictim = false;
                    Criminals::AddCriminal(ped);
                    GIVE_ACTOR_WEAPON(ped->ref, 22, 150);
                    SET_CURRENT_ACTOR_WEAPON(ped->ref, 22);
                };

                // 3 armados (motorista + 2 passageiros); 1 vitima limpa sem arma
                setupKidnapper(driver);
                for (int i = 0; i < 3; i++)
                {
                    if (i == victimSeat)
                    {
                        if (victim)
                        {
                            victim->flags.willSurrender = false;
                            victim->flags.willKillCops = false;
                            victim->flags.isKidnapVictim = true;
                            // sem arma
                        }
                    }
                    else
                    {
                        setupKidnapper(passengers[i]);
                    }
                }

                REMOVE_REFERENCES_TO_CAR(carRef);
                SET_CAR_ENGINE_OPERATION(carRef, true);
                // IA semelhante a fuga: dirige agressivo desde o spawn
                SET_CAR_TRAFFIC_BEHAVIOUR(carRef, DrivingMode::AvoidCars);
                SET_CAR_TO_PSYCHO_DRIVER(carRef);
                SET_CAR_MAX_SPEED(carRef, CHASE_VEHICLE_MAX_SPEED);
            });
        };
                taskApproach->Start();
    }
};
