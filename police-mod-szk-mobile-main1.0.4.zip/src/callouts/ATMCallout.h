#pragma once

#include "../pch.h"

#include "CalloutBase.h"

class ATMCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    
    void OnAccept() override;

    int GetWeight() const override { return CALLOUT_WEIGHT_ATM; }
    int GetLevel() const override { return CALLOUT_LEVEL_ATM; }
};