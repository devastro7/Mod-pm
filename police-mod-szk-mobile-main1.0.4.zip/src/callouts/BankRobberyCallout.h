#pragma once

#include "../pch.h"
#include "CalloutBase.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../ScriptTask.h"
#include "../CleoFunctions.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"
#include "../DualPatrol.h"

extern bool g_calloutReached;

// Implementacao inline no header (mesmo padrao do KidnapCallout)
// evita "vtable symbol may be undefined / missing key function" no linker NDK

class BankRobberyCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override
    {
        return "Assalto a banco em andamento";
    }

    AudioVariationGroup* GetBroadcastAudio() override
    {
        return audioCalloutBankRobbery;
    }

    int GetWeight() const override
    {
        return CALLOUT_WEIGHT_BANK_ROBBERY;
    }

    int GetLevel() const override
    {
        return CALLOUT_LEVEL_BANK_ROBBERY;
    }

    void OnAccept() override
    {
        BottomMessage::SetMessage("~w~Desloque-se ate o ~y~banco ~w~no mapa", 3000);

        // Coordenada fixa do assalto a banco
        CVector position(1382.565f, -1369.005f, 14.734f);

        int marker = CreateMarker(position.x, position.y, position.z, 0, 3, 3);

        ScriptTask* taskApproach = new ScriptTask("aproach_bank_robbery");
        taskApproach->onBegin = []() {};
        taskApproach->onExecute = [position]() {
            auto playerPosition = GetPlayerPosition();
            auto distance = distanceBetweenPoints(playerPosition, position);
            if (distance > 150.0f) return SCRIPT_KEEP_GOING;
            return SCRIPT_SUCCESS;
        };
        taskApproach->onComplete = [marker, position]() {
            g_calloutReached = true;
            DISABLE_MARKER(marker);

            BottomMessage::SetMessage("~r~Detenha os suspeitos — Aguia em orbita", 4000);

            // Explosao (sem caixa eletronico)
            ScriptTask* taskExp = new ScriptTask("bank_explosion");
            taskExp->onBegin = []() {};
            taskExp->onExecute = [position]() {
                auto playerPosition = GetPlayerPosition();
                auto distance = distanceBetweenPoints(playerPosition, position);
                if (!Callouts::IsInCallout()) return SCRIPT_CANCEL;
                if (distance > 50.0f) return SCRIPT_KEEP_GOING;
                return SCRIPT_SUCCESS;
            };
            taskExp->onComplete = [position]() {
                ADD_EXPLOSION(position.x, position.y, position.z, 0);
            };
            taskExp->Start();

            // 4 criminosos (igual ATM) + modelos do aguia no MESMO LoadAll
            // (ModelLoader so tem 1 callback — chamar LoadAll 2x cancelava o spawn do heli)
            std::vector<int> criminalSkins;
            for (int i = 0; i < 4; i++)
            {
                auto skin = GetRandomCriminalSkin();
                criminalSkins.push_back(skin);
                ModelLoader::AddModelToLoad(skin);
            }

            int coltId = 22;
            int coltModel = 346;
            ModelLoader::AddModelToLoad(coltModel);
            ModelLoader::AddModelToLoad(497); // polmav
            ModelLoader::AddModelToLoad(280); // piloto

            ModelLoader::LoadAll([position, criminalSkins, coltId]() {
                for (int i = 0; i < 4; i++)
                {
                    auto skinModel = criminalSkins[i];
                    auto pedRef = SpawnPedRandomlyAtPosition_PedNode(position, PedType::CivMale, skinModel, 10.0f);
                    auto criminal = Peds::RegisterPed(pedRef);

                    Criminals::AddCriminal(criminal);
                    criminal->ShowBlip(COLOR_CRIMINAL);

                    GIVE_ACTOR_WEAPON(pedRef, coltId, 1000);
                    SET_ACTOR_HEALTH(criminal->ref, 500);

                    criminal->flags.willSurrender = false;
                    if (i >= 1)
                        criminal->flags.willKillCops = true;
                    else
                        criminal->flags.willKillCops = false;
                }

                // Aguia so se aguia_no_banco = 1 no settings.ini
                if (g_aguiaNoBanco == 1)
                {
                    DualPatrol::SpawnOrbitLockHeliAt(
                        position,
                        497,
                        80,
                        60,
                        1003, // velocidade variavel 3
                        50,
                        true
                    );
                }
            });
        };
        taskApproach->Start();
    }
};
