#include "HomeInvasionCallout.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../CleoFunctions.h"
#include "../ScriptTask.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"

#include <vector>

extern bool g_calloutReached;

// Cidades (mesmo criterio do mod antigo)
enum eHomeCity {
    CITY_LOS_SANTOS = 0,
    CITY_SAN_FIERRO = 1,
    CITY_LAS_VENTURAS = 2
};

struct HomeHouse {
    CVector position;
    eHomeCity city;
};

// DPs usadas para descobrir a cidade (mesmo metodo do mod antigo)
static const CVector POLICE_DEPARTMENTS[] = {
    CVector(1536.1325f, -1671.2093f, 13.3828f),   // DP LS
    CVector(635.1006f,  -571.8163f,  16.3359f),   // DP Dillimore (LS)
    CVector(-1606.5406f, 721.6789f,  12.1554f),   // DP SF
    CVector(-211.8363f,  978.0092f,  19.3001f),   // Fort Carson (conta como LV no antigo)
    CVector(2289.8784f, 2425.8894f,  10.8203f),   // DP LV
};
static const eHomeCity POLICE_DEPARTMENT_CITY[] = {
    CITY_LOS_SANTOS,
    CITY_LOS_SANTOS,
    CITY_SAN_FIERRO,
    CITY_LAS_VENTURAS,
    CITY_LAS_VENTURAS,
};
static const int POLICE_DEPARTMENT_COUNT =
    (int)(sizeof(POLICE_DEPARTMENTS) / sizeof(POLICE_DEPARTMENTS[0]));

// Casas: as do mod NOVO (todas LS) + as do mod ANTIGO (LS/SF/LV)
static const HomeHouse HOME_HOUSES[] = {
    // --- Mod novo (Los Santos) ---
    { CVector(2309.031f, -1718.029f, 14.328f), CITY_LOS_SANTOS },
    { CVector(2498.744f, -1225.452f, 37.821f), CITY_LOS_SANTOS },
    { CVector(943.078f,  -844.904f,  93.762f), CITY_LOS_SANTOS },
    { CVector(496.977f,  -1094.530f, 82.359f), CITY_LOS_SANTOS },
    { CVector(2015.412f, -1646.661f, 13.547f), CITY_LOS_SANTOS },
    { CVector(2694.838f, -2018.482f, 13.526f), CITY_LOS_SANTOS },

    // --- Mod antigo: Los Santos ---
    { CVector(2132.2500f, -1280.7600f, 25.8906f), CITY_LOS_SANTOS },
    { CVector(2017.8800f, -1629.9399f, 13.7121f), CITY_LOS_SANTOS },
    { CVector(893.6480f,  -1635.9600f, 14.9297f), CITY_LOS_SANTOS },

    // --- Mod antigo: Las Venturas ---
    { CVector(1596.4000f, 2093.6599f, 11.3125f), CITY_LAS_VENTURAS },
    { CVector(2177.5071f,  736.0220f, 11.4609f), CITY_LAS_VENTURAS },
    { CVector(986.1868f,  2000.5649f, 11.4609f), CITY_LAS_VENTURAS },

    // --- Mod antigo: San Fierro ---
    { CVector(-2881.3601f, 790.4580f, 35.1238f), CITY_SAN_FIERRO },
    { CVector(-2792.1499f, -35.7933f,  7.8594f), CITY_SAN_FIERRO },
    { CVector(-2065.9700f, 1159.8300f, 46.6484f), CITY_SAN_FIERRO },
};
static const int HOME_HOUSE_COUNT =
    (int)(sizeof(HOME_HOUSES) / sizeof(HOME_HOUSES[0]));

// Cidade atual = cidade da DP mais proxima (igual mod antigo)
static eHomeCity GetClosestCity()
{
    auto playerPos = GetPlayerPosition();
    eHomeCity closestCity = CITY_LOS_SANTOS;
    float closestDist = 1e12f;

    for (int i = 0; i < POLICE_DEPARTMENT_COUNT; i++)
    {
        float d = distanceBetweenPoints(playerPos, POLICE_DEPARTMENTS[i]);
        if (d < closestDist)
        {
            closestDist = d;
            closestCity = POLICE_DEPARTMENT_CITY[i];
        }
    }
    return closestCity;
}

// Qualquer casa aleatoria da cidade atual (pode ser longe)
static CVector GetRandomHouseInCurrentCity()
{
    eHomeCity city = GetClosestCity();

    std::vector<int> indices;
    indices.reserve(HOME_HOUSE_COUNT);
    for (int i = 0; i < HOME_HOUSE_COUNT; i++)
    {
        if (HOME_HOUSES[i].city == city)
            indices.push_back(i);
    }

    // Fallback: se nao achar nada da cidade, usa todas
    if (indices.empty())
    {
        int idx = getRandomNumber(0, HOME_HOUSE_COUNT - 1);
        return HOME_HOUSES[idx].position;
    }

    int pick = indices[getRandomNumber(0, (int)indices.size() - 1)];
    return HOME_HOUSES[pick].position;
}

std::string HomeInvasionCallout::GetBroadcastMessage()
{
    return "Invasao domiciliar em andamento";
}

AudioVariationGroup* HomeInvasionCallout::GetBroadcastAudio()
{
    // nullptr se pasta/arquivos nao existirem — Callouts nao crasha
    return audioCalloutHomeInvasion;
}

void HomeInvasionCallout::OnAccept()
{
    BottomMessage::SetMessage("~w~Desloque-se ate o ~y~local ~w~no mapa", 3000);

    CVector position = GetRandomHouseInCurrentCity();

    int marker = CreateMarker(position.x, position.y, position.z, 0, 3, 3);

    ScriptTask* taskApproach = new ScriptTask("aproach_home_invasion");
    taskApproach->onBegin = []() {};
    taskApproach->onExecute = [position]() {
        auto playerPosition = GetPlayerPosition();
        auto distance = distanceBetweenPoints(playerPosition, position);
        if (distance > 80.0f)
            return SCRIPT_KEEP_GOING;
        return SCRIPT_SUCCESS;
    };
    taskApproach->onComplete = [marker, position]() {
        g_calloutReached = true;
        DISABLE_MARKER(marker);

        BottomMessage::SetMessage("~r~Suspeito no local — aproxime-se com cautela", 4000);

        auto skin = GetRandomCriminalSkin();
        ModelLoader::AddModelToLoad(skin);
        ModelLoader::LoadAll([skin, position]() {
            auto pedRef = CREATE_ACTOR_PEDTYPE(
                PedType::CivMale,
                skin,
                position.x,
                position.y,
                position.z
            );

            auto criminal = Peds::RegisterPed(pedRef);
            REMOVE_REFERENCES_TO_ACTOR(pedRef);

            Criminals::AddCriminal(criminal);
            criminal->ShowBlip(COLOR_CRIMINAL);
            // Chance de NAO parar / correr na ordem = chance de pedestre correr * 3
            float runChance = CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED * 3.0f;
            if (runChance > 1.0f) runChance = 1.0f;
            criminal->flags.willSurrender = !calculateProbability(runChance);
            criminal->flags.willKillCops = false;
            criminal->flags.canFleeAfterSurrender = true; // fuga apos render se nao algemado (*3 no Pullover)
            criminal->flags.showWidget = true;
            SET_ACTOR_HEALTH(criminal->ref, 400.0f);

            CLEAR_ACTOR_TASK(pedRef);

            ScriptTask* taskFlee = new ScriptTask("home_invasion_flee");
            taskFlee->onBegin = []() {};
            taskFlee->onExecute = [pedRef, position]() {
                if (!ACTOR_DEFINED(pedRef))
                    return SCRIPT_CANCEL;

                auto playerPosition = GetPlayerPosition();
                auto distance = distanceBetweenPoints(playerPosition, GetPedPosition(pedRef));

                if (distance > 18.0f)
                    return SCRIPT_KEEP_GOING;

                return SCRIPT_SUCCESS;
            };
            taskFlee->onComplete = [pedRef]() {
                if (!ACTOR_DEFINED(pedRef))
                    return;

                auto p = Peds::GetPed(pedRef);
                if (p && Peds::IsValid(p))
                {
                    // Se ja foi rendido, nao foge
                    if (p->flags.hasSurrended || p->flags.isHandcuffed)
                        return;

                    p->flags.isFleeing = true;
                    p->flags.hasSurrended = false;
                    p->flags.showWidget = true;
                    p->flags.healthWhenStartedFleeing = (float)ACTOR_HEALTH(pedRef);
                }

                CLEAR_ACTOR_TASK(pedRef);
                FLEE_FROM_ACTOR(pedRef, GetPlayerActor(), 100.0f, 60000);
                BottomMessage::SetMessage("~r~Suspeito em fuga!", 3500);
            };
            taskFlee->Start();
        });
    };
    taskApproach->Start();
}
