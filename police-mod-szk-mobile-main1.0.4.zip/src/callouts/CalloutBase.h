#pragma once

#include "../AudioVariationGroup.h"

class CalloutBase {
public:
    virtual ~CalloutBase() = default;

    virtual std::string GetBroadcastMessage() = 0;
    virtual AudioVariationGroup* GetBroadcastAudio() = 0;
    virtual void OnAccept() = 0;

    // Peso para sorteio (lido do settings.ini). Default 100.
    virtual int GetWeight() const { return 100; }

    // Nivel 1..5 (lido do settings.ini). Default 1.
    virtual int GetLevel() const { return 1; }
};
