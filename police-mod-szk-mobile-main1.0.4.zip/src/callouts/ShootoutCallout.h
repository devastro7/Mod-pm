#pragma once
#include "../pch.h"
#include "CalloutBase.h"

class ShootoutCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    void OnAccept() override;
    int GetWeight() const override { return CALLOUT_WEIGHT_SHOOTOUT; }
    int GetLevel() const override { return CALLOUT_LEVEL_SHOOTOUT; }
};
