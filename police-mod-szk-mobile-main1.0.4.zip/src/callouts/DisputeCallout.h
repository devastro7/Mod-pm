#pragma once

#include "../pch.h"
#include "CalloutBase.h"

// Desentendimento: pedestre com faca perseguindo outro (estilo mod antigo ASSAULT)
class DisputeCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    void OnAccept() override;
    int GetWeight() const override;
};
