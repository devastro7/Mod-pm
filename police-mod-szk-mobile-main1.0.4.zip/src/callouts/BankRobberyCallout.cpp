// Implementacao esta no BankRobberyCallout.h (inline) para evitar erro de vtable no linker.
#include "BankRobberyCallout.h"
