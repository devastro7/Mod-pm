// Implementacao esta no KidnapCallout.h (inline) para evitar erro de vtable no linker.
#include "KidnapCallout.h"
