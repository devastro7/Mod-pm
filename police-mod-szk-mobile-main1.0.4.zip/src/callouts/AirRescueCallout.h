#pragma once

#include "CalloutBase.h"

class AirRescueCallout : public CalloutBase
{
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;

    void OnAccept() override;

    int GetWeight() const override;
    int GetLevel() const override;
};