#include "WantedSearchCallout.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../CleoFunctions.h"
#include "../ScriptTask.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"

#include <vector>
#include <cmath>

extern bool g_calloutReached;
extern int g_calloutEndGraceMs;

enum eCalloutCity { CITY_LS = 0, CITY_SF = 1, CITY_LV = 2 };

static const CVector kPDs[] = {
    CVector(1536.13f, -1671.21f, 13.38f),
    CVector(635.10f,  -571.82f,  16.34f),
    CVector(-1606.54f, 721.68f,  12.16f),
    CVector(-211.84f,  978.01f,  19.30f),
    CVector(2289.88f, 2425.89f,  10.82f),
};
static const eCalloutCity kPDCity[] = { CITY_LS, CITY_LS, CITY_SF, CITY_LV, CITY_LV };

struct HouseLoc { CVector pos; eCalloutCity city; };
static const HouseLoc kHouses[] = {
    { CVector(2309.031f, -1718.029f, 14.328f), CITY_LS },
    { CVector(2498.744f, -1225.452f, 37.821f), CITY_LS },
    { CVector(943.078f,  -844.904f,  93.762f), CITY_LS },
    { CVector(496.977f,  -1094.530f, 82.359f), CITY_LS },
    { CVector(2015.412f, -1646.661f, 13.547f), CITY_LS },
    { CVector(2694.838f, -2018.482f, 13.526f), CITY_LS },
    { CVector(2132.2500f, -1280.7600f, 25.8906f), CITY_LS },
    { CVector(2017.8800f, -1629.9399f, 13.7121f), CITY_LS },
    { CVector(893.6480f,  -1635.9600f, 14.9297f), CITY_LS },
    { CVector(1596.4000f, 2093.6599f, 11.3125f), CITY_LV },
    { CVector(2177.5071f,  736.0220f, 11.4609f), CITY_LV },
    { CVector(986.1868f,  2000.5649f, 11.4609f), CITY_LV },
    { CVector(-2881.3601f, 790.4580f, 35.1238f), CITY_SF },
    { CVector(-2792.1499f, -35.7933f,  7.8594f), CITY_SF },
    { CVector(-2065.9700f, 1159.8300f, 46.6484f), CITY_SF },
};
static const int kHouseCount = (int)(sizeof(kHouses) / sizeof(kHouses[0]));

static eCalloutCity GetClosestCity()
{
    auto p = GetPlayerPosition();
    eCalloutCity best = CITY_LS;
    float bestD = 1e12f;
    for (int i = 0; i < 5; i++)
    {
        float d = distanceBetweenPoints(p, kPDs[i]);
        if (d < bestD) { bestD = d; best = kPDCity[i]; }
    }
    return best;
}

static CVector GetPedPathInRange(float minDist, float maxDist)
{
    auto player = GetPlayerPosition();
    std::vector<CVector> ok;

    for (int i = 0; i < 30; i++)
    {
        float ang = (float)getRandomNumber(0, 359) * 0.017453292f;
        float dist = (float)getRandomNumber((int)minDist, (int)maxDist);
        float tx = player.x + cosf(ang) * dist;
        float ty = player.y + sinf(ang) * dist;
        auto node = STORE_PED_PATH_COORDS_CLOSEST_TO(tx, ty, player.z);
        if (node.z < -20.0f || node.z > 600.0f) continue;
        float d = distanceBetweenPoints(player, node);
        if (d >= minDist && d <= maxDist)
            ok.push_back(node);
    }

    if (!ok.empty())
        return ok[getRandomNumber(0, (int)ok.size() - 1)];

    float ox = (float)getRandomNumber(-600, 600);
    float oy = (float)getRandomNumber(-600, 600);
    if (fabsf(ox) < 200.0f) ox = (ox < 0 ? -250.0f : 250.0f);
    if (fabsf(oy) < 200.0f) oy = (oy < 0 ? -250.0f : 250.0f);
    return STORE_PED_PATH_COORDS_CLOSEST_TO(player.x + ox, player.y + oy, player.z);
}

static CVector GetRandomHouseInCity()
{
    eCalloutCity city = GetClosestCity();
    auto player = GetPlayerPosition();
    std::vector<CVector> inRange;
    std::vector<CVector> any;

    for (int i = 0; i < kHouseCount; i++)
    {
        if (kHouses[i].city != city) continue;
        any.push_back(kHouses[i].pos);
        float d = distanceBetweenPoints(player, kHouses[i].pos);
        if (d >= 200.0f && d <= 1500.0f)
            inRange.push_back(kHouses[i].pos);
    }

    if (!inRange.empty())
        return inRange[getRandomNumber(0, (int)inRange.size() - 1)];
    if (!any.empty())
        return any[getRandomNumber(0, (int)any.size() - 1)];
    {
        float maxD = g_acceptCalloutsOtherCities ? 4500.0f : 1500.0f;
        return GetPedPathInRange(200.0f, maxD);
    }
}

static CVector PickLocation()
{
    if (calculateProbability(CHANCE_WANTED_SEARCH_USE_HOUSE))
        return GetRandomHouseInCity();
    {
        float maxD = g_acceptCalloutsOtherCities ? 4500.0f : 1500.0f;
        return GetPedPathInRange(200.0f, maxD);
    }
}

std::string WantedSearchCallout::GetBroadcastMessage()
{
    return "Busca e apreensao — individuo procurado na regiao";
}

AudioVariationGroup* WantedSearchCallout::GetBroadcastAudio()
{
    return audioCalloutWantedSearch;
}

int WantedSearchCallout::GetWeight() const
{
    return CALLOUT_WEIGHT_WANTED_SEARCH;
}

int WantedSearchCallout::GetLevel() const
{
    return CALLOUT_LEVEL_WANTED_SEARCH;
}

void WantedSearchCallout::OnAccept()
{
    g_kidnapRegionActive = false;

    BottomMessage::SetMessage("~w~Desloque-se ate o ~y~local ~w~no mapa", 3000);

    CVector position = PickLocation();
    int marker = CreateMarker(position.x, position.y, position.z, 0, 3, 3);

    ScriptTask* taskApproach = new ScriptTask("wanted_search_approach");
    taskApproach->onBegin = []() {};
    taskApproach->onExecute = [position]() {
        if (distanceBetweenPoints(GetPlayerPosition(), position) > 100.0f)
            return SCRIPT_KEEP_GOING;
        return SCRIPT_SUCCESS;
    };
    taskApproach->onComplete = [marker, position]() {
        DISABLE_MARKER(marker);

        int skin = GetSafeRandomPedSkin();
        if (skin <= 0) skin = 7;

        ModelLoader::AddModelToLoad(skin);
        ModelLoader::LoadAll([skin, position]() {
            if (!HAS_MODEL_LOADED(skin))
            {
                BottomMessage::SetMessage("~r~Suspeito nao localizado", 3000);
                return;
            }

            auto ground = STORE_PED_PATH_COORDS_CLOSEST_TO(position.x, position.y, position.z);
            int pedRef = CREATE_ACTOR_PEDTYPE(PedType::CivMale, skin, ground.x, ground.y, ground.z);
            if (!ACTOR_DEFINED(pedRef))
            {
                BottomMessage::SetMessage("~r~Suspeito nao localizado", 3000);
                return;
            }

            auto ped = Peds::RegisterPed(pedRef);
            if (!ped)
            {
                BottomMessage::SetMessage("~r~Suspeito nao localizado", 3000);
                return;
            }

            // NAO usar REMOVE_REFERENCES_TO_ACTOR — senão o jogo some com o ped (streaming)
            // e a lista de criminosos fica vazia → "ocorrencia encerrada" em segundos

            SET_ACTOR_HEALTH(pedRef, 500.0f);

            Criminals::AddCriminal(ped);

            // 20s de graca: mesmo se o ped sumir/morrer no spawn, nao encerra na hora
            g_calloutEndGraceMs = 20000;
            g_calloutReached = true;

            ped->flags.showWidget = true;
            ped->flags.wantedByJustice = true;
            ped->flags.willSurrender = calculateProbability(0.55f);
            ped->flags.willKillCops = false; // default; sobrescrito se cair nos 50% com arma
            ped->flags.isFleeing = false;

            // 50% arma e atira no jogador
            if (calculateProbability(0.50f))
            {
                ped->flags.willKillCops = true;
                ped->flags.willSurrender = false;
                GIVE_ACTOR_WEAPON(pedRef, 22, 120);
                SET_CURRENT_ACTOR_WEAPON(pedRef, 22);
            }

            auto walkTo = STORE_PED_PATH_COORDS_CLOSEST_TO(ground.x + 15.0f, ground.y + 12.0f, ground.z);
            TASK_GO_STRAIGHT_TO_COORD(pedRef, walkTo.x, walkTo.y, walkTo.z, 4, 120000);

            g_kidnapRegionPos = GetPedPosition(pedRef);
            g_kidnapRegionActive = true;

            BottomMessage::SetMessage("~y~Individuo na area — procure e aborde", 4000);

            bool* pStartedRun = new bool(false);
            int* pBlipTimer = new int(0);

            ScriptTask* monitor = new ScriptTask("wanted_search_monitor");
            monitor->onBegin = []() {};
            monitor->onExecute = [pedRef, pStartedRun, pBlipTimer]() {
                if (!Callouts::IsInCallout())
                {
                    g_kidnapRegionActive = false;
                    delete pStartedRun;
                    delete pBlipTimer;
                    return SCRIPT_CANCEL;
                }

                if (!ACTOR_DEFINED(pedRef))
                    return SCRIPT_KEEP_GOING;

                auto p = Peds::GetPed(pedRef);
                if (!p)
                    return SCRIPT_KEEP_GOING;

                int dt = menuSZK ? menuSZK->deltaTime : 50;

                if (!ACTOR_DEAD(pedRef) &&
                    !p->flags.hasSurrended &&
                    !p->flags.isHandcuffed &&
                    !p->flags.isInconcious)
                {
                    float dist = distanceBetweenPoints(GetPlayerPosition(), GetPedPosition(pedRef));
                    if (!*pStartedRun && dist < 30.0f)
                    {
                        *pStartedRun = true;
                        p->flags.isFleeing = true;
                        p->flags.healthWhenStartedFleeing = (float)ACTOR_HEALTH(pedRef);
                        CLEAR_ACTOR_TASK(pedRef);
                        FLEE_FROM_ACTOR(pedRef, GetPlayerActor(), 120.0f, 120000);
                        BottomMessage::SetMessage("~r~Suspeito em fuga!", 3000);
                    }
                }

                if (ACTOR_DEFINED(pedRef) && !ACTOR_DEAD(pedRef))
                {
                    *pBlipTimer += dt;
                    if (*pBlipTimer >= 10000)
                    {
                        *pBlipTimer = 0;
                        g_kidnapRegionPos = GetPedPosition(pedRef);
                        g_kidnapRegionActive = true;
                    }
                }

                return SCRIPT_KEEP_GOING;
            };
            monitor->onComplete = []() {};
            monitor->Start();
        });
    };
    taskApproach->Start();
}
