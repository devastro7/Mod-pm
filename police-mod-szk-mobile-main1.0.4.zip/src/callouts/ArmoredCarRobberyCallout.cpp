// Implementacao no .h (inline) para evitar erro de vtable no linker NDK.
#include "ArmoredCarRobberyCallout.h"
