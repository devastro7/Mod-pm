#pragma once

#include "../pch.h"

#include "CalloutBase.h"

class CalloutRegistry {
public:
    static inline std::vector<CalloutBase*> m_callouts;

    static void Register(CalloutBase* callout) {
        m_callouts.emplace_back(callout);
    }

    static CalloutBase* GetRandom() {
        if (m_callouts.empty()) return nullptr;

        // 0 = todas; 1..5 = so ocorrencias daquele nivel
        const int filter = CALLOUT_LEVEL_FILTER;
        auto matches = [filter](CalloutBase* c) -> bool {
            if (!c) return false;
            if (filter <= 0) return true;
            int lvl = c->GetLevel();
            if (lvl < 1) lvl = 1;
            if (lvl > 5) lvl = 5;
            return lvl == filter;
        };

        int total = 0;
        for (auto* c : m_callouts)
        {
            if (!matches(c)) continue;
            int w = c->GetWeight();
            if (w < 0) w = 0;
            total += w;
        }

        // Se nenhum peso valido no filtro, tenta uniforme entre os que batem o nivel
        if (total <= 0)
        {
            std::vector<CalloutBase*> pool;
            for (auto* c : m_callouts)
                if (matches(c)) pool.push_back(c);
            if (pool.empty())
                return nullptr;
            int idx = rand() % (int)pool.size();
            return pool[idx];
        }

        int r = rand() % total;
        int acc = 0;
        for (auto* c : m_callouts)
        {
            if (!matches(c)) continue;
            int w = c->GetWeight();
            if (w < 0) w = 0;
            acc += w;
            if (r < acc)
                return c;
        }
        // fallback: ultimo que bate o filtro
        for (int i = (int)m_callouts.size() - 1; i >= 0; --i)
            if (matches(m_callouts[i])) return m_callouts[i];
        return nullptr;
    }

    static const std::vector<CalloutBase*>& GetAll() {
        return m_callouts;
    }
};
