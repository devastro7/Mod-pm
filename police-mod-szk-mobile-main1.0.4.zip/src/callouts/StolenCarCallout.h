#pragma once

#include "../pch.h"

#include "CalloutBase.h"

class StolenCarCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    
    void OnAccept() override;

    int GetWeight() const override { return CALLOUT_WEIGHT_STOLEN_CAR; }
    int GetLevel() const override { return CALLOUT_LEVEL_STOLEN_CAR; }
};