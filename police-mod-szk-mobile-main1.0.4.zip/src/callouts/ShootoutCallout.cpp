#include "ShootoutCallout.h"
#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../CleoFunctions.h"
#include "../ScriptTask.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"
#include <cmath>
#include <vector>

extern bool g_calloutReached;
extern int g_calloutEndGraceMs;

static CVector GetShootoutNode()
{
    auto player = GetPlayerPosition();
    float minD = 500.0f;
    float maxD = g_acceptCalloutsOtherCities ? 4500.0f : 2000.0f;

    std::vector<CVector> ok;
    for (int i = 0; i < 28; i++)
    {
        float ang = (float)getRandomNumber(0, 359) * 0.017453292f;
        float dist = (float)getRandomNumber((int)minD, (int)maxD);
        float tx = player.x + cosf(ang) * dist;
        float ty = player.y + sinf(ang) * dist;
        auto node = STORE_PED_PATH_COORDS_CLOSEST_TO(tx, ty, player.z);
        if (node.z < -20.0f || node.z > 600.0f) continue;
        float d = distanceBetweenPoints(player, node);
        if (d >= minD && d <= maxD)
            ok.push_back(node);
    }
    if (!ok.empty())
        return ok[getRandomNumber(0, (int)ok.size() - 1)];
    return STORE_PED_PATH_COORDS_CLOSEST_TO(player.x + 800.0f, player.y + 800.0f, player.z);
}

std::string ShootoutCallout::GetBroadcastMessage()
{
    return "Troca de tiros em andamento";
}

AudioVariationGroup* ShootoutCallout::GetBroadcastAudio()
{
    return audioCalloutShootout;
}

void ShootoutCallout::OnAccept()
{
    BottomMessage::SetMessage("~w~Desloque-se ate o ~y~local ~w~no mapa", 3000);

    CVector position = GetShootoutNode();
    int marker = CreateMarker(position.x, position.y, position.z, 0, 3, 3); // padrao (nao blip gigante)

    ScriptTask* task = new ScriptTask("shootout_approach");
    task->onBegin = []() {};
    task->onExecute = [position]() {
        if (distanceBetweenPoints(GetPlayerPosition(), position) > 100.0f)
            return SCRIPT_KEEP_GOING;
        return SCRIPT_SUCCESS;
    };
    task->onComplete = [marker, position]() {
        DISABLE_MARKER(marker);
        g_calloutReached = true;
        BottomMessage::SetMessage("~r~Troca de tiros — neutralize os suspeitos", 4000);

        int count = getRandomNumber(3, 5);
        std::vector<int> skins;
        for (int i = 0; i < count; i++)
        {
            int s = GetSafeRandomPedSkin();
            if (s <= 0) s = 7;
            skins.push_back(s);
            ModelLoader::AddModelToLoad(s);
        }

        ModelLoader::LoadAll([skins, position, count]() {
            for (int i = 0; i < count; i++)
            {
                int skin = skins[i];
                if (!HAS_MODEL_LOADED(skin)) continue;

                float ox = (float)getRandomNumber(-4, 4);
                float oy = (float)getRandomNumber(-4, 4);
                auto pos = STORE_PED_PATH_COORDS_CLOSEST_TO(position.x + ox, position.y + oy, position.z);
                int ref = CREATE_ACTOR_PEDTYPE(PedType::CivMale, skin, pos.x, pos.y, pos.z);
                if (!ACTOR_DEFINED(ref)) continue;

                auto ped = Peds::RegisterPed(ref);
                if (!ped) continue;
                // mantem mission actor

                Criminals::AddCriminal(ped);
                ped->ShowBlip(COLOR_CRIMINAL);
                ped->flags.willSurrender = false;
                ped->flags.willKillCops = true;
                ped->flags.showWidget = true;
                SET_ACTOR_HEALTH(ref, 450.0f);

                int weap = (i % 2 == 0) ? 22 : 28; // pistola / uzi
                GIVE_ACTOR_WEAPON(ref, weap, 200);
                SET_CURRENT_ACTOR_WEAPON(ref, weap);
                KILL_ACTOR(ref, GetPlayerActor());
            }
            g_calloutEndGraceMs = 15000;
        });
    };
    task->Start();
}
