#pragma once

#include "../pch.h"
#include "CalloutBase.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../ScriptTask.h"
#include "../CleoFunctions.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"
#include "../Vehicles.h"
#include "../Chase.h"
#include "../DualPatrol.h"
#include <algorithm>

extern bool g_calloutReached;
extern bool g_onACallout;
extern bool g_spawnedCriminals;
extern std::string g_customCalloutEndMessage;

// Refs do carro-forte para limpar no fim da ocorrencia
inline int g_armoredSecCarRef = -1;
inline int g_armoredCrimCarRef = -1;

class ArmoredCarRobberyCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override
    {
        return "Roubo a carro-forte em andamento";
    }

    AudioVariationGroup* GetBroadcastAudio() override
    {
        return audioCalloutArmoredCar;
    }

    int GetWeight() const override
    {
        return CALLOUT_WEIGHT_ARMORED_CAR;
    }

    int GetLevel() const override
    {
        return CALLOUT_LEVEL_ARMORED_CAR;
    }

    void OnAccept() override
    {
        BottomMessage::SetMessage("~w~Desloque-se ate o ~y~local ~w~no mapa", 3000);

        const float CALLOUT_DISTANCE = 800.0f;
        auto playerActor = GET_PLAYER_ACTOR(0);
        auto distX = getRandomNumber(-(int)CALLOUT_DISTANCE, (int)CALLOUT_DISTANCE);
        auto distY = getRandomNumber(-(int)CALLOUT_DISTANCE, (int)CALLOUT_DISTANCE);

        float x = 0, y = 0, z = 0;
        STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, (float)distX, (float)distY, 0, &x, &y, &z);
        auto carNodePosition = GET_CLOSEST_CAR_NODE(x, y, z);

        int marker = CreateMarker(carNodePosition.x, carNodePosition.y, carNodePosition.z, 0, 3, 3);

        ScriptTask* taskApproach = new ScriptTask("aproach_armored_car");
        taskApproach->onBegin = []() {};
        taskApproach->onExecute = [carNodePosition]() {
            auto playerPosition = GetPlayerPosition();
            auto distance = distanceBetweenPoints(playerPosition, carNodePosition);
            if (distance > 150.0f) return SCRIPT_KEEP_GOING;
            return SCRIPT_SUCCESS;
        };
        taskApproach->onComplete = [marker, carNodePosition]() {
            g_calloutReached = true;
            DISABLE_MARKER(marker);

            BottomMessage::SetMessage("~y~Proteja o carro-forte ~w~/ ~r~detenha os assaltantes", 4500);

            static const int kCriminalVehicles[] = { 400, 507, 529, 551, 445, 585 };
            const int criminalVehicleModel = kCriminalVehicles[getRandomNumber(0, 5)];
            const int skinCrim1 = GetRandomCriminalSkin();
            const int skinCrim2 = GetRandomCriminalSkin();

            ModelLoader::AddModelToLoad(428);
            ModelLoader::AddModelToLoad(criminalVehicleModel);
            ModelLoader::AddModelToLoad(71);
            ModelLoader::AddModelToLoad(skinCrim1);
            ModelLoader::AddModelToLoad(skinCrim2);
            ModelLoader::AddModelToLoad(346);

            ModelLoader::LoadAll([carNodePosition, criminalVehicleModel, skinCrim1, skinCrim2]() {
                // No de rua do carro-forte
                auto secNode = GET_CLOSEST_CAR_NODE(carNodePosition.x, carNodePosition.y, carNodePosition.z);

                int secCarRef = CREATE_CAR_AT(428, secNode.x, secNode.y, secNode.z);
                if (!CAR_DEFINED(secCarRef))
                {
                    BottomMessage::SetMessage("~r~Falha ao criar carro-forte", 3000);
                    return;
                }
                auto secCar = Vehicles::RegisterVehicle(secCarRef);
                secCar->ShowBlip(COLOR_GREEN);
                secCar->flags.showWidget = false;
                g_armoredSecCarRef = secCarRef;

                int secDriverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(secCarRef, PedType::CivMale, 71);
                int secPassRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(secCarRef, PedType::CivMale, 71, 0);
                auto secDriver = Peds::RegisterPed(secDriverRef);
                auto secPass = Peds::RegisterPed(secPassRef);
                if (secDriver)
                {
                    secDriver->flags.willSurrender = true;
                    secDriver->flags.willKillCops = false;
                    SET_ACTOR_HEALTH(secDriverRef, 700);
                }
                if (secPass)
                {
                    secPass->flags.willSurrender = true;
                    secPass->flags.willKillCops = false;
                    SET_ACTOR_HEALTH(secPassRef, 700);
                    GIVE_ACTOR_WEAPON(secPassRef, 22, 80);
                }

                REMOVE_REFERENCES_TO_CAR(secCarRef);
                SET_CAR_ENGINE_OPERATION(secCarRef, true);
                SET_CAR_TRAFFIC_BEHAVIOUR(secCarRef, DrivingMode::AvoidCars);
                SET_CAR_TO_PSYCHO_DRIVER(secCarRef);
                SET_CAR_MAX_SPEED(secCarRef, 30.0f);

                // Criminosos: outro no de rua (deslocado) — evita spawn dentro de predio
                float offX = (float)getRandomNumber(18, 35) * (getRandomNumber(0, 1) ? 1.0f : -1.0f);
                float offY = (float)getRandomNumber(18, 35) * (getRandomNumber(0, 1) ? 1.0f : -1.0f);
                auto crimNode = GET_CLOSEST_CAR_NODE(secNode.x + offX, secNode.y + offY, secNode.z);

                int crimCarRef = CREATE_CAR_AT(criminalVehicleModel, crimNode.x, crimNode.y, crimNode.z);
                if (!CAR_DEFINED(crimCarRef))
                {
                    BottomMessage::SetMessage("~r~Falha ao criar veiculo dos criminosos", 3000);
                    return;
                }
                auto crimCar = Vehicles::RegisterVehicle(crimCarRef);
                crimCar->ShowBlip(COLOR_CRIMINAL);
                crimCar->flags.showWidget = true;
                g_armoredCrimCarRef = crimCarRef;

                int crimDriverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(crimCarRef, PedType::CivMale, skinCrim1);
                int crimPassRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(crimCarRef, PedType::CivMale, skinCrim2, 0);
                auto crimDriver = Peds::RegisterPed(crimDriverRef);
                auto crimPass = Peds::RegisterPed(crimPassRef);

                auto setupCriminal = [](Ped* ped) {
                    if (!ped) return;
                    ped->flags.willSurrender = false;
                    ped->flags.willKillCops = true;
                    ped->flags.forceStayInVehicle = true; // nao desce durante a perseguicao
                    Criminals::AddCriminal(ped);
                    GIVE_ACTOR_WEAPON(ped->ref, 22, 500);
                    SET_CURRENT_ACTOR_WEAPON(ped->ref, 22);
                    SET_ACTOR_HEALTH(ped->ref, 600);
                    SET_CHAR_STAY_IN_CAR_WHEN_JACKED(ped->ref, true);
                };
                setupCriminal(crimDriver);
                setupCriminal(crimPass);

                REMOVE_REFERENCES_TO_CAR(crimCarRef);
                SET_CAR_ENGINE_OPERATION(crimCarRef, true);
                SET_CAR_TRAFFIC_BEHAVIOUR(crimCarRef, DrivingMode::PloughThrough);
                SET_CAR_MAX_SPEED(crimCarRef, 500.0f); // sem limite pratico — corre atras do carro-forte
                CAR_FOLLOW_CAR(crimCarRef, secCarRef, 4.0f);

                g_customCalloutEndMessage = "~g~Roubo a carro forte frustado";

                if (DualPatrol::autoHeliEnabled)
                    DualPatrol::SpawnAutoHeliAfterCallout();

                int secCarW = secCarRef;
                int crimCarW = crimCarRef;
                int secD = secDriverRef;
                int secP = secPassRef;
                int crimD = crimDriverRef;
                int crimP = crimPassRef;
                bool* pFleeStarted = new bool(false);
                bool* pOnFoot = new bool(false);
                bool* pEnded = new bool(false);
                int* pChaseTimer = new int(0);
                int* pSecStoppedMs = new int(0);

                // Encerra ocorrencia SEM apagar corpos/carro dos criminosos
                auto endArmoredCallout = [secCarW, crimCarW, crimD, crimP, pFleeStarted, pOnFoot, pEnded, pChaseTimer, pSecStoppedMs](bool showFrustratedMsg) {
                    if (*pEnded) return;
                    *pEnded = true;

                    // Para o carro dos criminosos (nao some)
                    if (CAR_DEFINED(crimCarW))
                    {
                        SET_CAR_MAX_SPEED(crimCarW, 0.0f);
                        SET_CAR_ENGINE_OPERATION(crimCarW, false);
                        FREEZE_CAR_POSITION(crimCarW, false);
                        auto cv = Vehicles::GetVehicle(crimCarW);
                        if (cv)
                        {
                            cv->ShowBlip(COLOR_CRIMINAL);
                            cv->flags.showWidget = true;
                        }
                    }

                    // Criminosos: so solta flag; corpos ficam no chao (sistema de ferido do mod)
                    auto releasePed = [](int ref) {
                        if (!ACTOR_DEFINED(ref)) return;
                        auto ped = Peds::GetPed(ref);
                        if (ped)
                        {
                            ped->flags.forceStayInVehicle = false;
                            // Mantem como criminal se ainda estiver na lista (corpo ferido)
                            if (ACTOR_DEAD(ref) || (ped->flags.isInconcious))
                                ped->flags.showWidget = true;
                        }
                    };
                    releasePed(crimD);
                    releasePed(crimP);

                    // Carro-forte pode sumir no fim (cenario da ocorrencia)
                    if (CAR_DEFINED(secCarW))
                    {
                        auto sv = Vehicles::GetVehicle(secCarW);
                        if (sv)
                        {
                            for (auto o : sv->GetOwners())
                            {
                                auto ped = Peds::GetPed(o);
                                if (ped) ped->QueueDestroy();
                            }
                            sv->HideBlip();
                            sv->QueueDestroy(false);
                        }
                    }

                    g_armoredSecCarRef = -1;
                    // Mantem ref do carro dos criminosos se ainda existir (para nao sumir)
                    if (!CAR_DEFINED(crimCarW))
                        g_armoredCrimCarRef = -1;

                    g_onACallout = false;
                    g_calloutReached = false;
                    g_spawnedCriminals = false;
                    ClearActiveCalloutMarker();

                    if (showFrustratedMsg)
                    {
                        BottomMessage::AddMessage("~g~Roubo a carro forte frustado", 4000);
                        g_customCalloutEndMessage.clear();
                    }
                    else if (!g_customCalloutEndMessage.empty())
                    {
                        BottomMessage::AddMessage(g_customCalloutEndMessage, 4000);
                        g_customCalloutEndMessage.clear();
                    }

                    delete pFleeStarted;
                    delete pOnFoot;
                    delete pEnded;
                    delete pChaseTimer;
                    delete pSecStoppedMs;
                };

                ScriptTask* monitor = new ScriptTask("armored_car_monitor");
                monitor->onBegin = []() {};
                monitor->onExecute = [secCarW, crimCarW, secD, secP, crimD, crimP, pFleeStarted, pOnFoot, pEnded, pChaseTimer, pSecStoppedMs, endArmoredCallout]() {
                    if (*pEnded)
                        return SCRIPT_CANCEL;

                    if (!Callouts::IsInCallout())
                    {
                        endArmoredCallout(false);
                        return SCRIPT_CANCEL;
                    }

                    int dt = menuSZK ? menuSZK->deltaTime : 50;

                    bool crimDDead = !ACTOR_DEFINED(crimD) || ACTOR_DEAD(crimD);
                    bool crimPDead = !ACTOR_DEFINED(crimP) || ACTOR_DEAD(crimP);
                    auto isDown = [](int ref) {
                        if (!ACTOR_DEFINED(ref) || ACTOR_DEAD(ref)) return true;
                        auto ped = Peds::GetPed(ref);
                        if (ped && ped->flags.isInconcious) return true;
                        return false;
                    };
                    bool bothDown = isDown(crimD) && isDown(crimP);

                    // Ambos fora de combate: para o carro deles e encerra (corpos ficam)
                    if (bothDown)
                    {
                        if (CAR_DEFINED(crimCarW))
                        {
                            SET_CAR_MAX_SPEED(crimCarW, 0.0f);
                            SET_CAR_ENGINE_OPERATION(crimCarW, false);
                        }
                        endArmoredCallout(true);
                        return SCRIPT_CANCEL;
                    }

                    if (!CAR_DEFINED(crimCarW))
                    {
                        // Carro sumiu mas corpos podem existir — so encerra
                        endArmoredCallout(true);
                        return SCRIPT_CANCEL;
                    }

                    // Motorista morto e passageiro vivo: PARA o carro (nao anda sozinho)
                    if (crimDDead && !crimPDead && CAR_DEFINED(crimCarW))
                    {
                        SET_CAR_MAX_SPEED(crimCarW, 0.0f);
                        SET_CAR_ENGINE_OPERATION(crimCarW, false);
                        // Passageiro desce para continuar o combate a pe
                        if (!*pOnFoot)
                        {
                            *pOnFoot = true;
                            auto pass = Peds::GetPed(crimP);
                            if (pass)
                            {
                                pass->flags.forceStayInVehicle = false;
                                SET_CHAR_STAY_IN_CAR_WHEN_JACKED(crimP, false);
                                pass->LeaveCar();
                            }
                        }
                    }

                    // Carro-forte parado > 8s: criminosos descem e enfrentam
                    if (CAR_DEFINED(secCarW) && !*pOnFoot && !bothDown)
                    {
                        float secSpd = CAR_SPEED(secCarW);
                        if (secSpd < 1.5f)
                            *pSecStoppedMs += dt;
                        else
                            *pSecStoppedMs = 0;

                        if (*pSecStoppedMs >= 8000)
                        {
                            *pOnFoot = true;
                            auto exitPed = [](int actor) {
                                if (!ACTOR_DEFINED(actor) || ACTOR_DEAD(actor)) return;
                                auto ped = Peds::GetPed(actor);
                                if (!ped || ped->flags.isInconcious) return;
                                ped->flags.forceStayInVehicle = false;
                                SET_CHAR_STAY_IN_CAR_WHEN_JACKED(actor, false);
                                ped->LeaveCar();
                            };
                            if (!crimDDead) exitPed(crimD);
                            if (!crimPDead) exitPed(crimP);
                            if (CAR_DEFINED(crimCarW))
                            {
                                SET_CAR_MAX_SPEED(crimCarW, 0.0f);
                                SET_CAR_ENGINE_OPERATION(crimCarW, false);
                            }
                            BottomMessage::SetMessage("~r~Carro-forte parado — assaltantes descendo!", 3500);
                        }
                    }

                    bool guardsDead =
                        (!ACTOR_DEFINED(secD) || ACTOR_DEAD(secD)) &&
                        (!ACTOR_DEFINED(secP) || ACTOR_DEAD(secP));

                    // Perseguicao so se motorista vivo e ainda no carro
                    // FOLLOW a cada 2s (estilo DualPatrol) — evita ficar para tras
                    *pChaseTimer += dt;
                    if (*pChaseTimer >= 2000)
                    {
                        *pChaseTimer = 0;
                        if (!*pOnFoot && !crimDDead && CAR_DEFINED(crimCarW) && CAR_DEFINED(secCarW) && !guardsDead)
                        {
                            SET_CAR_ENGINE_OPERATION(crimCarW, true);
                            SET_CAR_MAX_SPEED(crimCarW, 500.0f);
                            SET_CAR_TRAFFIC_BEHAVIOUR(crimCarW, DrivingMode::PloughThrough);
                            CAR_FOLLOW_CAR(crimCarW, secCarW, 3.0f);
                            auto secPos = GetCarPosition(secCarW);
                            CAR_DRIVE_TO(crimCarW, secPos.x, secPos.y, secPos.z);
                        }
                    }

                    if (guardsDead && !*pFleeStarted)
                    {
                        *pFleeStarted = true;
                        auto clearStay = [](int actor) {
                            if (!ACTOR_DEFINED(actor) || ACTOR_DEAD(actor)) return;
                            auto ped = Peds::GetPed(actor);
                            if (ped) ped->flags.forceStayInVehicle = false;
                        };
                        clearStay(crimD);
                        clearStay(crimP);

                        auto v = Vehicles::GetVehicle(crimCarW);
                        if (v)
                        {
                            v->ShowBlip(COLOR_CRIMINAL);
                            v->flags.showWidget = true;
                            if (std::find(Chase::vehiclesInChase.begin(), Chase::vehiclesInChase.end(), v) == Chase::vehiclesInChase.end())
                                Chase::vehiclesInChase.push_back(v);
                        }
                        BottomMessage::SetMessage("~r~Carro-forte comprometido — criminosos em fuga!", 4000);
                    }

                    if (CAR_DEFINED(secCarW))
                    {
                        auto sv = Vehicles::GetVehicle(secCarW);
                        if (sv) sv->ShowBlip(COLOR_GREEN);
                    }
                    if (CAR_DEFINED(crimCarW))
                    {
                        auto cv = Vehicles::GetVehicle(crimCarW);
                        if (cv) cv->ShowBlip(COLOR_CRIMINAL);
                    }

                    return SCRIPT_KEEP_GOING;
                };
                monitor->onComplete = []() {};
                monitor->Start();
            });
        };
        taskApproach->Start();
    }
};
