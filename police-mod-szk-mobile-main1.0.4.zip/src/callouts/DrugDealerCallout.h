#pragma once

#include "../pch.h"

#include "CalloutBase.h"

class DrugDealerCallout : public CalloutBase {
public:
    std::string GetBroadcastMessage() override;
    AudioVariationGroup* GetBroadcastAudio() override;
    
    void OnAccept() override;

    int GetWeight() const override { return CALLOUT_WEIGHT_DRUG_DEALER; }
    int GetLevel() const override { return CALLOUT_LEVEL_DRUG_DEALER; }
};