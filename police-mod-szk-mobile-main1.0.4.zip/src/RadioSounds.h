#pragma once

#include "pch.h"

#include "menuSZK/IAudio.h"

class RadioSounds {
public:
    static void Initialize();
    static void Update();

    static void PlayNext();
    static void PlaySelectedIndex();
    static void AttachAudio();
    static void AttachAudioForCallout();
    static void PlayAudioNow(IAudio* audio);
    static void PlayAudioNowDontAttach(IAudio* audio);
    static bool IsCalloutAudioPlaying();
    static void StopCurrent();
    static void MuteRadio();      // deixa radio mudo sem parar a faixa
    static void UnmuteRadio();    // restaura volume do radio
    static void ApplyCurrentVolume();

    static int GetAudioCount();
};
