#pragma once

#include <string>
#include <mutex>

// Controles de log (carregados/salvos automaticamente em settings.ini)
// enable_log = 0 e enable_deeplog = 0 => nenhum log é gerado (melhor FPS)
inline bool g_enableLog = true;      // 1 = grava logs normais (INFO/WARN/ERROR/DEBUG)
inline bool g_enableDeepLog = false; // 1 = grava DeepLog (logs detalhados)

class Logger {
public:
    bool debugEnabled = true;

    // Construtor: nome do mod será o nome do arquivo de log
    Logger(const std::string& modName);

    // Métodos de log
    void Log(const std::string& message);   // INFO
    void Warn(const std::string& message);  // WARN
    void Error(const std::string& message); // ERROR
    void Debug(const std::string& message);

    void Clear();

private:
    std::string logFolder;   // pasta de logs
    std::string logFile;     // arquivo de log
    std::mutex mtx;          // para threads

    // Função auxiliar que escreve no arquivo
    void Write(const std::string& level, const std::string& message);
};

extern Logger* localLogger;

#define fileLog localLogger

inline void DeepLog(std::string text)
{
    if (g_enableDeepLog && g_enableLog && fileLog)
    {
        fileLog->Log(text);
    }
}