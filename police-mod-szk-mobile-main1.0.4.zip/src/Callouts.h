#pragma once

#include "pch.h"
#include "callouts/CalloutRegistry.h"

#define NO_CALLOUT -1
#define CALLOUT_ATM 0

inline int g_secondsBetweenCallouts = 70;

// Servico ativo (sessao apenas - nao salva no ini).
// Liga ao clicar no colete; pode desligar em Opcoes de testes.
inline bool g_onService = false;

class Callouts {
public:
    static void Initialize();
    static void Update();

    static void TryBroadcastCallout();
    static void BroadcastRandomCallout();
    static void BroadcastCallout(CalloutBase* callout);

    static void AcceptCallout();
    static void CancelPendingOrActive();

    static bool HasCalloutToAccept();
    static bool IsBroacastingCallout();
    static bool IsInCallout();
};
