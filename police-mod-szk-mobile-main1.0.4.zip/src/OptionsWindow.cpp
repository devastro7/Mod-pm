#include "OptionsWindow.h"

#include "DualPatrol.h"
#include "Partners.h"
#include "BottomMessage.h"

void OptionsWindow::OpenWindow()
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Apoios");

    {
        auto button = window->AddButton("Comboio");
        button->onClick->Add([window]() {
            window->Close();
            DualPatrol::CreateMenu();
        });
    }

    {
        auto button = window->AddButton("Apoio Helicoptero");
        button->onClick->Add([window]() {
            window->Close();
            DualPatrol::CreateHeliMenu();
        });
    }

    {
        auto button = window->AddButton("Parceiro");
        button->onClick->Add([window]() {
            window->Close();
            Partners::CreateSpawnPartnerMenu();
        });
    }

    {
        auto button = window->AddButton("~y~Fechar");
        button->onClick->Add([window]() {
            window->Close();
        });
    }
}
