#pragma once

#include "pch.h"

struct PoliceVehicleData
{
    std::string folderPath = "";
    std::string name = "";
    int vehicleModelId;
    int skinModelId;
    int occupants = 1; // 1..4 (padrao 1 se ini nao tiver)
    float chance = 1.0f;

    // Nomes de remap do MultiRemap — sorteia um se houver varios (sem lag)
    std::vector<std::string> remaps;

    bool trunkDisabled = false;
    CVector trunkOffset = CVector(0, -4.00f, 0);
    CVector trunkSeatPosition = CVector(0.50f, -1.80f, 0.90f);
};