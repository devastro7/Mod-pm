#include "FriskPanel.h"
#include "NotifStack.h"
#include "DispatchPanel.h"

// Ate 5 paineis simultaneos empilhados (limite real: FRISK_UI_MAX_POPUPS 1..5)

static const int MAX_PANELS = 5;
static const int MAX_ITEMS = 8;
static const float BASE_PANEL_W = 400.0f;
static const float BASE_PANEL_H = 280.0f;
static const float BASE_TEXT_W = 370.0f;
static const float SLIDE_DIST = 280.0f;
static const unsigned char BASE_BG_A = 210;
static const int REVEAL_INTERVAL_MS = 350;

struct PanelInst {
    IContainer* root = nullptr;
    IContainer* badge = nullptr;
    IContainer* title = nullptr;
    IContainer* subtitle = nullptr;
    IContainer* sep = nullptr;
    IContainer* itemLines[MAX_ITEMS] = {};
    IContainer* footer = nullptr;

    int itemCount = 0;
    std::string itemTexts[MAX_ITEMS];
    bool itemIllegal[MAX_ITEMS] = {};

    int timer = 0;
    int duration = 0;
    bool visible = false;

    int animPhase = 0; // 0 idle 1 in 2 out
    float animT = 0.0f;

    int revealTimer = 0;
    int revealedCount = 0;

    std::function<void()> onClosed;
    int stackSlot = -1; // NotifStack slot (1..3)
};

static PanelInst s_panels[MAX_PANELS];
static bool s_inited = false;
static std::function<void()> s_pendingOnClosed; // aplicado no proximo Show

static IContainer* MakeLabel(IContainer* parent, const std::string& tag, float fontSize, CRGBA color, CVector2D size)
{
    auto label = menuSZK->CreateContainer(tag);
    label->drawBackground = false;
    label->size = size;
    label->text = "";
    label->textHorizontalAlign = HorizontalAlign::Left;
    label->textVerticalAlign = VerticalAlign::Middle;
    label->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;

    auto font = &label->textFont;
    font->fontSize = fontSize;
    font->color = color;
    font->align = eFontAlignment::ALIGN_LEFT;

    parent->AddChild(label);
    return label;
}

static float Scale()
{
    int sz = CALLOUT_UI_SIZE;
    if (sz < 0) sz = 0;
    if (sz > 100) sz = 100;
    float s = sz / 100.0f;
    if (s < 0.30f) s = 0.30f;
    return s;
}

static float EaseOut(float t)
{
    float u = 1.0f - t;
    return 1.0f - u * u * u;
}

static float EaseIn(float t)
{
    return t * t * t;
}

static float AnimAlpha(const PanelInst& p)
{
    if (CALLOUT_UI_ANIM == 0) return 1.0f;
    if (p.animPhase == 1) return EaseOut(p.animT);
    if (p.animPhase == 2) return 1.0f - EaseIn(p.animT);
    return 1.0f;
}

static CVector2D AnimOffset(const PanelInst& p)
{
    float amount = 0.0f;
    if (CALLOUT_UI_ANIM == 0 || CALLOUT_UI_ANIM == 5)
        return CVector2D(0, 0);

    if (p.animPhase == 1)
        amount = (1.0f - EaseOut(p.animT)) * SLIDE_DIST;
    else if (p.animPhase == 2)
        amount = EaseIn(p.animT) * SLIDE_DIST;
    else
        return CVector2D(0, 0);

    switch (CALLOUT_UI_ANIM)
    {
    case 1: return CVector2D(0, -amount); // de cima
    case 2: return CVector2D(0, amount);  // de baixo
    case 3: return CVector2D(-amount, 0); // esquerda
    case 4: return CVector2D(amount, 0);  // direita
    default: return CVector2D(0, 0);
    }
}

static void SetPanelAlpha(PanelInst& p, float a)
{
    if (!p.root) return;
    unsigned char alpha = (unsigned char)(BASE_BG_A * a);
    if (alpha > 255) alpha = 255;
    p.root->backgroundColor = CRGBA(15, 18, 25, alpha);

    auto applyText = [a](IContainer* c, CRGBA base) {
        if (!c) return;
        unsigned char ta = (unsigned char)(base.a * a);
        c->textFont.color = CRGBA(base.r, base.g, base.b, ta);
    };

    if (p.badge)
    {
        unsigned char ba = (unsigned char)(255 * a);
        p.badge->backgroundColor = CRGBA(30, 90, 180, ba);
        p.badge->textFont.color = CRGBA(255, 255, 255, ba);
    }
    applyText(p.title, CRGBA(255, 255, 255, 255));
    applyText(p.subtitle, CRGBA(200, 200, 200, 255));
    applyText(p.footer, CRGBA(160, 160, 160, 255));

    for (int i = 0; i < MAX_ITEMS; ++i)
    {
        if (!p.itemLines[i]) continue;
        float itemA = (i < p.revealedCount) ? a : 0.0f;
        CRGBA base = p.itemIllegal[i] ? CRGBA(255, 80, 80, 255) : CRGBA(230, 230, 230, 255);
        unsigned char ta = (unsigned char)(base.a * itemA);
        p.itemLines[i]->textFont.color = CRGBA(base.r, base.g, base.b, ta);
        p.itemLines[i]->isVisible = (i < p.itemCount);
    }

    if (p.sep)
    {
        unsigned char sa = (unsigned char)(80 * a);
        p.sep->backgroundColor = CRGBA(255, 255, 255, sa);
    }
}

static void ApplyLayoutOne(PanelInst& p)
{
    if (!p.root || !p.visible) return;
    float s = Scale();
    float pw = BASE_PANEL_W * s;
    // altura pelo conteudo real (header ~68 + linhas + footer ~28)
    int lines = p.itemCount > 0 ? p.itemCount : 1;
    float baseH = 68.0f + (float)lines * 22.0f + 28.0f;
    float ph = baseH * s;
    float tw = BASE_TEXT_W * s;

    CVector2D animOff = AnimOffset(p);
    p.root->size = CVector2D(pw, ph);

    if (p.stackSlot >= 0)
        NotifStack::SetActive(p.stackSlot, true, ph);

    float stackY = (p.stackSlot >= 0) ? NotifStack::GetOffsetY(p.stackSlot) : 0.0f;
    p.root->localOffset = CVector2D((float)CALLOUT_UI_POS_X + animOff.x, (float)CALLOUT_UI_POS_Y + animOff.y + stackY);

    if (p.badge)
    {
        p.badge->size = CVector2D(44 * s, 26 * s);
        p.badge->localOffset = CVector2D(10 * s, 10 * s);
        p.badge->textFont.fontSize = 1.2f * s;
    }
    if (p.title)
    {
        p.title->size = CVector2D(tw - 50 * s, 22 * s);
        p.title->localOffset = CVector2D(60 * s, 8 * s);
        p.title->textFont.fontSize = 1.4f * s;
    }
    if (p.subtitle)
    {
        p.subtitle->size = CVector2D(tw, 18 * s);
        p.subtitle->localOffset = CVector2D(12 * s, 38 * s);
        p.subtitle->textFont.fontSize = 1.15f * s;
    }
    if (p.sep)
    {
        p.sep->size = CVector2D(tw, 2 * s);
        p.sep->localOffset = CVector2D(12 * s, 60 * s);
    }

    for (int i = 0; i < MAX_ITEMS; ++i)
    {
        if (!p.itemLines[i]) continue;
        p.itemLines[i]->size = CVector2D(tw, 20 * s);
        p.itemLines[i]->localOffset = CVector2D(12 * s, (68 + i * 22) * s);
        p.itemLines[i]->textFont.fontSize = 1.2f * s;
    }

    if (p.footer)
    {
        p.footer->size = CVector2D(tw, 18 * s);
        p.footer->localOffset = CVector2D(12 * s, ph - 24 * s);
        p.footer->textFont.fontSize = 1.05f * s;
    }

    SetPanelAlpha(p, AnimAlpha(p));
}

static void CreateOnePanel(PanelInst& p, int index)
{
    auto root = menuSZK->CreateContainer("friskPanel" + std::to_string(index));
    root->horizontalAlign = HorizontalAlign::Left;
    root->verticalAlign = VerticalAlign::Top;
    root->localOffset = CVector2D((float)CALLOUT_UI_POS_X, (float)CALLOUT_UI_POS_Y);
    root->size = CVector2D(BASE_PANEL_W, BASE_PANEL_H);
    root->drawBackground = true;
    root->backgroundColor = CRGBA(15, 18, 25, BASE_BG_A);
    root->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    root->isVisible = false;
    root->hideWhenPauseGame = true;

    menuSZK->GetRootContainer()->AddChild(root);
    p.root = root;

    auto badge = menuSZK->CreateContainer("friskBadge" + std::to_string(index));
    badge->size = CVector2D(44, 26);
    badge->localOffset = CVector2D(10, 10);
    badge->drawBackground = true;
    badge->backgroundColor = CRGBA(30, 90, 180, 255);
    badge->text = "REV";
    badge->textHorizontalAlign = HorizontalAlign::Middle;
    badge->textVerticalAlign = VerticalAlign::Middle;
    badge->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    badge->textFont.fontSize = 1.2f;
    badge->textFont.color = CRGBA(255, 255, 255);
    badge->textFont.align = eFontAlignment::ALIGN_CENTER;
    root->AddChild(badge);
    p.badge = badge;

    p.title = MakeLabel(root, "friskTitle" + std::to_string(index), 1.4f, CRGBA(255, 255, 255), CVector2D(BASE_TEXT_W, 22));
    p.title->localOffset = CVector2D(60, 8);
    p.title->text = "REVISTA";

    p.subtitle = MakeLabel(root, "friskSub" + std::to_string(index), 1.15f, CRGBA(200, 200, 200), CVector2D(BASE_TEXT_W, 18));
    p.subtitle->localOffset = CVector2D(12, 38);
    p.subtitle->text = "Itens encontrados";

    auto sep = menuSZK->CreateContainer("friskSep" + std::to_string(index));
    sep->size = CVector2D(BASE_TEXT_W, 2);
    sep->localOffset = CVector2D(12, 60);
    sep->drawBackground = true;
    sep->backgroundColor = CRGBA(255, 255, 255, 80);
    sep->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    root->AddChild(sep);
    p.sep = sep;

    for (int i = 0; i < MAX_ITEMS; ++i)
    {
        p.itemLines[i] = MakeLabel(root, "friskItem" + std::to_string(index) + "_" + std::to_string(i), 1.2f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
        p.itemLines[i]->localOffset = CVector2D(12, 68 + i * 22);
        p.itemLines[i]->text = "";
        p.itemLines[i]->isVisible = false;
    }

    p.footer = MakeLabel(root, "friskFooter" + std::to_string(index), 1.05f, CRGBA(160, 160, 160), CVector2D(BASE_TEXT_W, 18));
    p.footer->text = "Fecha automaticamente";
}

static int MaxAllowedPopups()
{
    int m = FRISK_UI_MAX_POPUPS;
    if (m < 1) m = 1;
    if (m > MAX_PANELS) m = MAX_PANELS;
    return m;
}

// Escolhe slot livre respeitando FRISK_UI_MAX_POPUPS; se cheio, reusa o mais antigo
static int PickFreePanel()
{
    int maxAllowed = MaxAllowedPopups();
    int visibleCount = 0;
    for (int i = 0; i < MAX_PANELS; ++i)
    {
        if (s_panels[i].visible)
            visibleCount++;
    }

    // prefere indice livre dentro do limite
    for (int i = 0; i < maxAllowed; ++i)
    {
        if (!s_panels[i].visible)
            return i;
    }

    // cheio: reusa o mais antigo (maior timer) entre os ativos
    int best = 0;
    int bestTimer = -1;
    for (int i = 0; i < maxAllowed; ++i)
    {
        if (s_panels[i].visible && s_panels[i].timer > bestTimer)
        {
            bestTimer = s_panels[i].timer;
            best = i;
        }
    }
    return best;
}

static void FreeStackSlot(PanelInst& p)
{
    if (p.stackSlot >= 0)
    {
        NotifStack::SetActive(p.stackSlot, false, 0.0f);
        p.stackSlot = -1;
    }
}

// Reatribui slots: painel mais novo (menor timer) fica no slot mais baixo (base),
// paineis antigos sobem (slots maiores = offset Y mais negativo).
static void ReassignStackSlots(int newestIdx)
{
    // Lista de paineis visiveis ordenados por "idade" (timer desc = mais antigo primeiro)
    struct Entry { int idx; int timer; };
    Entry list[MAX_PANELS];
    int n = 0;
    for (int i = 0; i < MAX_PANELS; ++i)
    {
        if (!s_panels[i].visible) continue;
        list[n].idx = i;
        // newestIdx forca timer 0 para ficar no final (mais novo)
        list[n].timer = (i == newestIdx) ? -1 : s_panels[i].timer;
        n++;
    }
    // sort: maior timer primeiro (mais antigo), newest por ultimo
    for (int a = 0; a < n; ++a)
        for (int b = a + 1; b < n; ++b)
            if (list[b].timer > list[a].timer)
            {
                Entry tmp = list[a];
                list[a] = list[b];
                list[b] = tmp;
            }

    // limpa slots
    for (int i = 0; i < MAX_PANELS; ++i)
    {
        if (s_panels[i].stackSlot >= 0)
            NotifStack::SetActive(s_panels[i].stackSlot, false, 0.0f);
        s_panels[i].stackSlot = -1;
    }

    // atribui de EXTRA_BASE pra cima: o ultimo da lista (mais novo) pega EXTRA_BASE (base visual)
    // os antigos pegam slots maiores (sobem)
    // invertendo: primeiro da lista (mais antigo) = slot mais alto
    int slot = NotifStack::SLOT_EXTRA_BASE + (n - 1);
    for (int i = 0; i < n; ++i)
    {
        int idx = list[i].idx;
        int s = NotifStack::SLOT_EXTRA_BASE + (n - 1 - i); // mais novo = EXTRA_BASE
        if (s >= NotifStack::SLOT_COUNT) s = NotifStack::SLOT_COUNT - 1;
        if (s < NotifStack::SLOT_EXTRA_BASE) s = NotifStack::SLOT_EXTRA_BASE;
        s_panels[idx].stackSlot = s;
        (void)slot;
    }
}

void FriskPanel::Initialize()
{
    if (s_inited) return;
    for (int i = 0; i < MAX_PANELS; ++i)
        CreateOnePanel(s_panels[i], i);
    s_inited = true;
}

void FriskPanel::ApplyLayout()
{
    for (int i = 0; i < MAX_PANELS; ++i)
    {
        if (s_panels[i].visible)
            ApplyLayoutOne(s_panels[i]);
    }
}

void FriskPanel::Update()
{
    int dt = (int)menuSZK->deltaTime;
    if (dt < 0) dt = 0;
    if (dt > 100) dt = 100;

    int animMs = CALLOUT_UI_ANIM_MS;
    if (animMs < 100) animMs = 100;

    bool anyVisible = false;

    for (int pi = 0; pi < MAX_PANELS; ++pi)
    {
        PanelInst& p = s_panels[pi];
        if (!p.visible || !p.root) continue;
        anyVisible = true;

        p.timer += dt;

        // Revelacao sequencial
        if (p.revealedCount < p.itemCount && p.animPhase != 2)
        {
            p.revealTimer += dt;
            while (p.revealTimer >= REVEAL_INTERVAL_MS && p.revealedCount < p.itemCount)
            {
                p.revealTimer -= REVEAL_INTERVAL_MS;
                p.revealedCount++;
                if (p.revealedCount <= p.itemCount && p.itemLines[p.revealedCount - 1])
                {
                    p.itemLines[p.revealedCount - 1]->text = p.itemTexts[p.revealedCount - 1];
                    p.itemLines[p.revealedCount - 1]->isVisible = true;
                }
            }
        }

        if (CALLOUT_UI_ANIM != 0 && (p.animPhase == 1 || p.animPhase == 2))
        {
            p.animT += (float)dt / (float)animMs;
            if (p.animT >= 1.0f)
            {
                p.animT = 1.0f;
                if (p.animPhase == 1)
                    p.animPhase = 0;
                else if (p.animPhase == 2)
                {
                    p.visible = false;
                    p.root->isVisible = false;
                    p.animPhase = 0;
                    FreeStackSlot(p);
                    // reempilha os que sobraram (descem)
                    ReassignStackSlots(-1);
                    if (p.onClosed)
                    {
                        auto cb = p.onClosed;
                        p.onClosed = nullptr;
                        cb();
                    }
                }
            }
        }

        // Saida automatica
        if (p.animPhase == 0 && CALLOUT_UI_ANIM != 0)
        {
            int outStart = p.duration - animMs;
            if (outStart < 0) outStart = 0;
            if (p.timer >= outStart)
            {
                p.animPhase = 2;
                p.animT = 0.0f;
            }
        }
        else if (p.animPhase == 0 && CALLOUT_UI_ANIM == 0)
        {
            if (p.timer >= p.duration)
            {
                p.visible = false;
                p.root->isVisible = false;
                FreeStackSlot(p);
                ReassignStackSlots(-1);
                if (p.onClosed)
                {
                    auto cb = p.onClosed;
                    p.onClosed = nullptr;
                    cb();
                }
            }
        }

        if (p.visible)
            ApplyLayoutOne(p);
    }

    if (anyVisible)
        DispatchPanel::ApplyLayout();
}

void FriskPanel::Show(const std::vector<std::string>& items, const std::string& subtitle, int durationMs)
{
    Show("REVISTA", "REV", subtitle, items, durationMs);
}

void FriskPanel::Show(const std::string& title, const std::string& badge, const std::string& subtitle,
                      const std::vector<std::string>& items, int durationMs)
{
    if (!s_inited) return;

    int idx = PickFreePanel();
    PanelInst& p = s_panels[idx];

    // se reusando painel ativo, limpa slot antigo
    if (p.visible)
        FreeStackSlot(p);

    if (p.title) p.title->text = title.empty() ? "INFO" : title;
    if (p.badge) p.badge->text = badge.empty() ? "I" : badge;

    p.itemCount = 0;
    for (size_t i = 0; i < items.size() && p.itemCount < MAX_ITEMS; ++i)
    {
        std::string t = items[i];
        bool illegal = false;
        if (t.size() >= 3 && t[0] == '~' && (t[1] == 'r' || t[1] == 'R') && t[2] == '~')
        {
            illegal = true;
            t = t.substr(3);
        }
        if (t.size() >= 3 && t[0] == '~' && t[2] == '~')
            t = t.substr(3);

        if ((int)t.size() > 36)
            t = t.substr(0, 33) + "...";

        p.itemTexts[p.itemCount] = std::string("- ") + t;
        p.itemIllegal[p.itemCount] = illegal;
        p.itemCount++;
    }

    if (p.itemCount == 0)
    {
        p.itemTexts[0] = "- Nada encontrado";
        p.itemIllegal[0] = false;
        p.itemCount = 1;
    }

    for (int i = 0; i < MAX_ITEMS; ++i)
    {
        if (!p.itemLines[i]) continue;
        p.itemLines[i]->text = "";
        p.itemLines[i]->isVisible = false;
    }

    p.revealedCount = 0;
    p.revealTimer = 0;

    if (p.subtitle)
        p.subtitle->text = subtitle.empty() ? "Itens encontrados" : subtitle;

    // durationMs explicito tem prioridade; senao usa FRISK_UI_DURATION_MS do menu
    int base = durationMs > 0 ? durationMs : FRISK_UI_DURATION_MS;
    if (base < 3000) base = 3000;
    if (base > 60000) base = 60000;
    // tempo extra leve pra revelacao dos itens (nao estoura o limite do usuario)
    int perItem = REVEAL_INTERVAL_MS;
    p.duration = base + p.itemCount * perItem;
    if (p.duration < 3000) p.duration = 3000;
    if (p.duration > 65000) p.duration = 65000;

    p.timer = 0;
    p.visible = true;
    p.root->isVisible = true;

    // empilha: novo na base, antigos sobem
    ReassignStackSlots(idx);

    if (s_pendingOnClosed)
    {
        p.onClosed = s_pendingOnClosed;
        s_pendingOnClosed = nullptr;
    }

    if (CALLOUT_UI_ANIM == 0)
    {
        p.animPhase = 0;
        p.animT = 1.0f;
        p.revealedCount = p.itemCount;
        for (int i = 0; i < p.itemCount; ++i)
        {
            p.itemLines[i]->text = p.itemTexts[i];
            p.itemLines[i]->isVisible = true;
        }
        SetPanelAlpha(p, 1.0f);
    }
    else
    {
        p.animPhase = 1;
        p.animT = 0.0f;
    }

    // re-layout todos para reposicionar stack (antigos sobem)
    for (int i = 0; i < MAX_PANELS; ++i)
    {
        if (s_panels[i].visible)
            ApplyLayoutOne(s_panels[i]);
    }
    DispatchPanel::ApplyLayout();
}

void FriskPanel::Hide()
{
    // esconde todos
    for (int i = 0; i < MAX_PANELS; ++i)
    {
        PanelInst& p = s_panels[i];
        if (!p.visible) continue;

        if (CALLOUT_UI_ANIM != 0 && p.animPhase != 2)
        {
            p.animPhase = 2;
            p.animT = 0.0f;
            continue;
        }

        p.visible = false;
        p.timer = 0;
        p.animPhase = 0;
        p.animT = 0.0f;
        if (p.root)
            p.root->isVisible = false;
        SetPanelAlpha(p, 1.0f);
        FreeStackSlot(p);

        if (p.onClosed)
        {
            auto cb = p.onClosed;
            p.onClosed = nullptr;
            cb();
        }
    }
    DispatchPanel::ApplyLayout();
}

bool FriskPanel::IsVisible()
{
    for (int i = 0; i < MAX_PANELS; ++i)
        if (s_panels[i].visible) return true;
    return false;
}

void FriskPanel::SetOnClosed(std::function<void()> cb)
{
    // aplica no proximo Show (comportamento antigo)
    s_pendingOnClosed = cb;
}

bool FriskPanel::UsePanel()
{
    int s = FRISK_UI_STYLE;
    if (s < 0) s = 0;
    if (s > 2) s = 2;
    return s == 1 || s == 2;
}

bool FriskPanel::UseClassic()
{
    int s = FRISK_UI_STYLE;
    if (s < 0) s = 0;
    if (s > 2) s = 2;
    return s == 0 || s == 2;
}

void FriskPanel_RelayoutIfVisible()
{
    if (FriskPanel::IsVisible())
        FriskPanel::ApplyLayout();
}
