#include "RadioSounds.h"

#include "CleoFunctions.h"
#include "Vehicles.h"
#include "BottomMessage.h"
#include "Callouts.h"
#include "Skins.h"

std::vector<IAudio*> g_radioAudios;
std::vector<int> g_playedIndices;

// Faixa do radio (pasta "radio") - continua tocando mesmo durante callout (so fica muda)
IAudio* g_radioAudio = nullptr;
int g_currentIndex = -1;

// Audio da ocorrencia (voz COPOM) - separado do radio
IAudio* g_calloutAudio = nullptr;
bool g_playingCalloutAudio = false;
bool g_radioMutedForCallout = false;

int g_nextPlayDelay = 0;
const int RADIO_DELAY_MIN = 3000;
const int RADIO_DELAY_MAX = 7000;

static float ScaleDistance(int setting)
{
    // setting 100 = comportamento antigo (~200 unidades)
    if (setting < 30) setting = 30;
    if (setting > 500) setting = 500;
    return (setting / 100.0f) * 200.0f;
}

static float ScaleVolume(int setting)
{
    if (setting < 30) setting = 30;
    if (setting > 500) setting = 500;
    return setting / 100.0f;
}

void RadioSounds::Initialize()
{
    std::string folder = modData->GetFileFromAssets("audios/radio/");
    g_radioAudios.clear();
    g_playedIndices.clear();
    g_radioAudio = nullptr;
    g_calloutAudio = nullptr;
    g_currentIndex = -1;
    g_playingCalloutAudio = false;
    g_radioMutedForCallout = false;

    for (int i = 1; ; i++)
    {
        std::string path = folder + std::to_string(i) + ".wav";
        if (!file_exists(path))
            break;

        auto audio = menuSZK->Load3DAudio(path);
        if (audio)
        {
            g_radioAudios.push_back(audio);
            fileLog->Log("[RadioSounds] Loaded: " + path);
        }
        else
        {
            fileLog->Error("[RadioSounds] Failed to load: " + path);
        }
    }

    if (RADIO_SOUND_INDEX < 0)
        RADIO_SOUND_INDEX = 0;
    if (!g_radioAudios.empty() && RADIO_SOUND_INDEX >= (int)g_radioAudios.size())
        RADIO_SOUND_INDEX = (int)g_radioAudios.size() - 1;

    fileLog->Log("[RadioSounds] Total radio tracks: " + std::to_string(g_radioAudios.size()));
}

void RadioSounds::MuteRadio()
{
    g_radioMutedForCallout = true;
    if (g_radioAudio)
        g_radioAudio->SetVolume(0.0f);
}

void RadioSounds::UnmuteRadio()
{
    g_radioMutedForCallout = false;
    // Restaura volume/attach normal se a faixa ainda estiver tocando
    if (g_radioAudio && !g_radioAudio->Finished())
        AttachAudio();
}

void RadioSounds::Update()
{
    // --- Audio da ocorrencia (voz) ---
    if (g_calloutAudio != nullptr)
    {
        if (g_calloutAudio->Finished())
        {
            g_calloutAudio = nullptr;
            g_playingCalloutAudio = false;
            // Terminou a fala: radio volta a ter volume (faixa continua de onde estava)
            UnmuteRadio();
        }
        else
        {
            AttachAudioForCallout();
            // Garante radio mudo enquanto fala
            if (g_radioAudio)
                g_radioAudio->SetVolume(0.0f);
        }
    }

    // --- Radio da pasta: continua a faixa mesmo com callout (so volume 0) ---
    auto playerActor = GetPlayerActor();
    auto skinModel = GET_ACTOR_MODEL(playerActor);

    if (!IsPoliceSkin(skinModel))
    {
        return;
    }

    // Radio de viaturas OFF: para por completo os wav da pasta audios/radio
    if (!RADIO_VEHICLE_RADIO_ENABLED)
    {
        if (g_radioAudio != nullptr)
        {
            g_radioAudio->Stop();
            g_radioAudio = nullptr;
        }
        g_nextPlayDelay = 0;
        return;
    }

    // Se radio ainda tocando, so atualiza attach (ou mantem mudo se callout)
    if (g_radioAudio != nullptr)
    {
        if (g_radioAudio->Finished())
        {
            if (!g_radioAudios.empty())
            {
                int next = g_currentIndex + 1;
                if (next >= (int)g_radioAudios.size())
                    next = 0;
                RADIO_SOUND_INDEX = next;
            }

            g_radioAudio = nullptr;
            g_nextPlayDelay = getRandomNumber(RADIO_DELAY_MIN, RADIO_DELAY_MAX);
        }
        else
        {
            if (g_radioMutedForCallout || g_playingCalloutAudio)
                g_radioAudio->SetVolume(0.0f);
            else
                AttachAudio();
            return;
        }
    }

    // Delay entre faixas do radio
    if (g_nextPlayDelay > 0)
    {
        g_nextPlayDelay -= menuSZK->deltaTime;
        return;
    }

    // Nao inicia nova faixa se radio desligado
    if (!RADIO_VEHICLE_RADIO_ENABLED)
        return;

    // Pode iniciar proxima faixa mesmo durante callout (ela fica muda)
    if (!g_radioAudio)
    {
        PlayNext();
        // Se estiver em callout, ja deixa mudo
        if (g_radioAudio && (g_radioMutedForCallout || g_playingCalloutAudio))
            g_radioAudio->SetVolume(0.0f);
    }
}

void RadioSounds::PlayNext()
{
    if (!RADIO_VEHICLE_RADIO_ENABLED)
        return;

    if (g_radioAudios.empty())
        return;

    int idx = RADIO_SOUND_INDEX;
    if (idx < 0 || idx >= (int)g_radioAudios.size())
        idx = 0;

    g_currentIndex = idx;
    g_radioAudio = g_radioAudios[g_currentIndex];

    if (!g_radioAudio)
        return;

    AttachAudio();
    g_radioAudio->Play();

    // Se callout esta falando, deixa mudo imediatamente
    if (g_radioMutedForCallout || g_playingCalloutAudio)
        g_radioAudio->SetVolume(0.0f);
}

void RadioSounds::PlaySelectedIndex()
{
    if (!RADIO_VEHICLE_RADIO_ENABLED)
        return;

    if (g_radioAudios.empty())
        return;

    int idx = RADIO_SOUND_INDEX;
    if (idx < 0 || idx >= (int)g_radioAudios.size())
        idx = 0;

    if (g_radioAudio)
        g_radioAudio->Stop();

    g_currentIndex = idx;
    g_radioAudio = g_radioAudios[g_currentIndex];
    g_nextPlayDelay = 0;

    if (!g_radioAudio)
        return;

    AttachAudio();
    g_radioAudio->Play();

    if (g_radioMutedForCallout || g_playingCalloutAudio)
        g_radioAudio->SetVolume(0.0f);
}

void RadioSounds::AttachAudio()
{
    if (!g_radioAudio)
        return;

    // Nao sobrescreve volume se estiver mutado por callout
    if (g_radioMutedForCallout || g_playingCalloutAudio)
    {
        g_radioAudio->SetVolume(0.0f);
        return;
    }

    CPed* player = (CPed*)menuSZK->GetCPedFromRef(GetPlayerActor());
    if (!player)
    {
        g_radioAudio->SetVolume(0.0f);
        return;
    }

    CVehicle* vehicle = nullptr;
    const float maxDist = ScaleDistance(RADIO_SOUND_DISTANCE);

    if (g_lastPlayerVehicle > 0 && CAR_DEFINED(g_lastPlayerVehicle))
    {
        vehicle = (CVehicle*)menuSZK->GetCVehicleFromRef(g_lastPlayerVehicle);

        if (vehicle)
        {
            float distanceToPed = distanceBetweenPoints(*vehicle->GetPosSA(), *player->GetPosSA());
            if (distanceToPed > maxDist)
                vehicle = nullptr;
        }
    }

    if (vehicle)
    {
        g_radioAudio->SetVolume(ScaleVolume(RADIO_SOUND_VOLUME));
        g_radioAudio->AttachToCPlaceable(vehicle);
    }
    else
    {
        g_radioAudio->SetVolume(0.0f);
    }
}

void RadioSounds::AttachAudioForCallout()
{
    if (!g_calloutAudio)
        return;

    CPed* player = (CPed*)menuSZK->GetCPedFromRef(GetPlayerActor());
    if (!player)
    {
        g_calloutAudio->SetVolume(0.0f);
        return;
    }

    CVehicle* vehicle = nullptr;
    const float maxDist = ScaleDistance(RADIO_CALLOUT_DISTANCE);

    if (g_lastPlayerVehicle > 0 && CAR_DEFINED(g_lastPlayerVehicle))
    {
        vehicle = (CVehicle*)menuSZK->GetCVehicleFromRef(g_lastPlayerVehicle);

        if (vehicle)
        {
            float distanceToPed = distanceBetweenPoints(*vehicle->GetPosSA(), *player->GetPosSA());
            if (distanceToPed > maxDist)
                vehicle = nullptr;
        }
    }

    if (vehicle)
    {
        g_calloutAudio->SetVolume(ScaleVolume(RADIO_CALLOUT_VOLUME));
        g_calloutAudio->AttachToCPlaceable(vehicle);
    }
    else
    {
        g_calloutAudio->SetVolume(0.0f);
    }
}

bool RadioSounds::IsCalloutAudioPlaying()
{
    return g_playingCalloutAudio && g_calloutAudio != nullptr;
}

void RadioSounds::PlayAudioNow(IAudio* audio)
{
    if (!audio)
        return;

    // Se ja tem outro audio de ocorrencia, para o anterior e toca o novo
    // (antes descartava o novo — fazia o de tiros nao tocar apos carro roubado)
    if (g_playingCalloutAudio && g_calloutAudio && g_calloutAudio != audio)
    {
        g_calloutAudio->Stop();
        g_calloutAudio = nullptr;
        g_playingCalloutAudio = false;
    }

    // NAO para o radio: so deixa mudo. A faixa continua tocando em silencio.
    MuteRadio();

    g_calloutAudio = audio;
    g_playingCalloutAudio = true;

    AttachAudioForCallout();
    g_calloutAudio->Play();
}

void RadioSounds::PlayAudioNowDontAttach(IAudio* audio)
{
    if (!audio)
        return;

    // Se ja tem outro audio de ocorrencia, para o anterior e toca o novo
    if (g_playingCalloutAudio && g_calloutAudio && g_calloutAudio != audio)
    {
        g_calloutAudio->Stop();
        g_calloutAudio = nullptr;
        g_playingCalloutAudio = false;
    }

    MuteRadio();

    g_calloutAudio = audio;
    g_playingCalloutAudio = true;

    g_calloutAudio->SetVolume(ScaleVolume(RADIO_CALLOUT_VOLUME));
    g_calloutAudio->Play();
}

void RadioSounds::StopCurrent()
{
    // Para por completo a faixa da pasta audios/radio (1.wav, 2.wav, ...)
    if (g_radioAudio != nullptr)
    {
        g_radioAudio->Stop();
        g_radioAudio = nullptr;
    }
    g_nextPlayDelay = 0;
}

void RadioSounds::ApplyCurrentVolume()
{
    if (g_calloutAudio && g_playingCalloutAudio)
        g_calloutAudio->SetVolume(ScaleVolume(RADIO_CALLOUT_VOLUME));

    if (g_radioAudio)
    {
        if (!RADIO_VEHICLE_RADIO_ENABLED)
        {
            g_radioAudio->Stop();
            g_radioAudio = nullptr;
            return;
        }
        if (g_radioMutedForCallout || g_playingCalloutAudio)
            g_radioAudio->SetVolume(0.0f);
        else
            AttachAudio();
    }
}

int RadioSounds::GetAudioCount()
{
    return (int)g_radioAudios.size();
}
