#pragma once

#include "pch.h"

class DispatchPanel {
public:
    static void Initialize();
    static void Update();

    // Aplica posicao (X/Y) e tamanho (0-100) salvos nas settings
    static void ApplyLayout();

    // Mostra o painel de ocorrencia (canto esquerdo)
    static void Show(const std::string& callType, const std::string& location, const std::string& instruction, int durationMs = 12000);

    // Reexibe a ultima ocorrencia gravada (consulta no radio)
    static void ShowLast();
    static bool HasLast();

    static void Hide();
    static bool IsVisible();
};
