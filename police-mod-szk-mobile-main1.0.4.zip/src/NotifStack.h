#pragma once

// Empilha paineis laterais (ocorrencia / consultas / revista / bafometro)
// Ordem visual (de baixo pra cima, VerticalAlign::Top):
//   1) pop-ups novos na BASE
//   2) pop-ups antigos sobem
//   3) ocorrencia sempre no topo
// Gap borda-a-borda = FRISK_UI_POPUP_GAP

class NotifStack {
public:
    // 0 = dispatch (ocorrencia), 1..MAX_EXTRA = paineis de consulta/revista
    static const int SLOT_DISPATCH = 0;
    static const int SLOT_EXTRA_BASE = 1;
    static const int MAX_EXTRA = 5; // ate 5 paineis extras simultaneos
    static const int SLOT_COUNT = 1 + MAX_EXTRA; // 6

    static void SetActive(int slot, bool active, float height);
    static float GetOffsetY(int slot); // offset adicional no eixo Y (negativo = sobe)
    static float GetGap(); // usa FRISK_UI_POPUP_GAP (0..50)

    // Atalhos legados
    enum Slot { SLOT_FRISK = 1 };
};
