#pragma once

#include "pch.h"
#include "Ped.h"
#include <vector>
#include <string>

struct ConversationLine
{
    std::string text;
    int durationSec = 3;
};

struct Conversation
{
    std::string name;
    std::string filePath;
    std::vector<ConversationLine> questions; // P
    std::vector<ConversationLine> responses; // R
};

class Conversas
{
public:
    static void Initialize();
    static void LoadConversations();
    static void OpenConversarMenu(Ped* ped);
    static void StartConversation(const Conversation& conv, Ped* ped);

    // exposed for lambda capture safety
    static std::vector<Conversation> s_conversations;

private:
    static bool s_loaded;

    static std::string GetConversasFolder();
    static void EnsureFolderAndDefaults();
    static bool ParseConversationFile(const std::string& path, Conversation& out);
};
