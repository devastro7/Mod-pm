#include "BackupUnits.h"

#include "BottomMessage.h"
#include "CleoFunctions.h"
#include "ModelLoader.h"
#include "Vehicles.h"
#include "Peds.h"
#include "AIController.h"
#include "Criminals.h"
#include "AICop.h"
#include "AIMedic.h"
#include "AIFireman.h"
#include "AIHelicopterCop.h"
#include "AudioCollection.h"
#include "RadioSounds.h"
#include "IniReaderWriter.hpp"
#include "DualPatrol.h"
#include "IMultiRemap.h"
extern IMultiRemap* multiRemap;

const float MAX_DISTANCE_TO_QTH = 300.0f;

bool g_hasInformedRadio = false;

CVector g_lastQTHPosition = CVector(0, 0, 0);
int g_spawnUnitTimer = 0;

std::vector<RoadName> g_roads;

std::vector<Vehicle*> BackupUnits::backupVehicles;

void BackupUnits::Initialize()
{
    InitializeRoads();
}

void BackupUnits::InitializeRoads()
{
    std::string roadDataPath = modData->GetFileFromAssets("roads/roads.dat");

    std::ifstream file(roadDataPath);
    if (!file.is_open())
    {
        return;
    }

    std::string line;
    while (std::getline(file, line))
    {
        // Ignora linhas vazias ou comentários
        if (line.empty() || line[0] == '#')
            continue;

        std::istringstream ss(line);
        std::string audioFile;
        float x, y;

        // Faz o parsing: audioFile, posX, posY
        if (!(std::getline(ss, audioFile, ',') >> x))
        {
            // Se não conseguir ler corretamente, tenta com parsing mais robusto
            char comma;
            ss.clear();
            ss.str(line);
            if (!(std::getline(ss, audioFile, ',') && ss >> x >> comma >> y))
            {
                continue;
            }
        }
        else
        {
            // quando o primeiro getline dá certo, precisa ler os outros 2 valores
            char comma;
            ss >> comma >> y;
        }

        // Remove espaços em branco do nome do arquivo
        audioFile.erase(0, audioFile.find_first_not_of(" \t"));
        audioFile.erase(audioFile.find_last_not_of(" \t") + 1);

        // Cria o grupo de áudio
        auto group = AudioCollection::CreateGroup(audioFile);

        std::string fullAudioPath = modData->GetFileFromAssets("roads/audios/" + audioFile);
        group->LoadNewAudio(fullAudioPath);

        // Cria o objeto da rua
        RoadName road;
        road.audioGroup = group;
        road.position = CVector(x, y, 0.0f);

        g_roads.push_back(road);

        menuDebug->AddLine("Road loaded: " + audioFile);
    }

    file.close();
}

void BackupUnits::Update()
{
    CheckIfVehiclesAreValid();

    auto criminalsCount = Criminals::GetCriminals()->size();
    
    if(criminalsCount == 0)
    {
        g_lastQTHPosition = CVector(0, 0, 0);
        g_hasInformedRadio = false;
    }

    auto distanceFromQTH = distanceBetweenPoints(GetPlayerPosition(), g_lastQTHPosition);

    if(distanceFromQTH < MAX_DISTANCE_TO_QTH)
    {
        if(criminalsCount > 0 && backupVehicles.size() < 5)
        {
            g_spawnUnitTimer += menuSZK->deltaTime;

            if(g_spawnUnitTimer >= 8000)
            {
                g_spawnUnitTimer = 0;

                SpawnRandomBackupUnit();
            }
        }
    }
}

void BackupUnits::OnPostDrawRadar()
{
    if (textureBigCircle == nullptr) return;

    auto playerPosition = GetPlayerPosition();
    auto distance = distanceBetweenPoints(g_lastQTHPosition, playerPosition);

    const float fadeStart = MAX_DISTANCE_TO_QTH - 80.0f;
    const float fadeEnd = MAX_DISTANCE_TO_QTH;

    unsigned char alpha = 0;

    if (distance <= fadeStart)
    {
        alpha = 100; // totalmente visível até 200m
    }
    else if (distance >= fadeEnd)
    {
        alpha = 0; // invisível a partir de 300m
    }
    else
    {
        // interpolar suavemente entre 200 e 300
        float t = (distance - fadeStart) / (fadeEnd - fadeStart);
        alpha = static_cast<unsigned char>(100 * (1.0f - t));
    }

    auto color = COLOR_POLICE;
    color.a = alpha;

    menuSZK->DrawTextureOnRadar(textureBigCircle, playerPosition, color, 150.0f);
}

void BackupUnits::CheckIfVehiclesAreValid()
{
    backupVehicles.erase(
        std::remove_if(
            backupVehicles.begin(),
            backupVehicles.end(),
            [](Vehicle* vehicle) {
                // Remove se não for válido
                return !Vehicles::IsValid(vehicle);
            }
        ),
        backupVehicles.end()
    );
}

void BackupUnits::SendQTH()
{
    fileLog->Log("BackupUnits: SendQTH");
    
    if(Criminals::GetCriminals()->size() == 0)
    {
        BottomMessage::SetMessage(GetTranslatedText("error_no_suspects_found"), 3000);
        return;
    }

    g_lastQTHPosition = GetPlayerPosition();

    BottomMessage::SetMessage(GetTranslatedText("qth_updated"), 3000);
    
    if(g_hasInformedRadio == false)
    {
        auto audio = audioRequestBackup->GetRandomAudio();

        RadioSounds::PlayAudioNow(audio);

        // WaitForAudioFinish(audio, []() {
        //     PlayRoadName();
        // });
    } else {
        PlayRoadName();
    }

    g_hasInformedRadio = true;

    //SpawnBackupUnit();
}

void BackupUnits::PlayRoadName()
{
    if (g_roads.empty())
        return;

    CVector myPosition = GetPlayerPosition();

    RoadName* nearestRoad = nullptr;
    float nearestDistance = FLT_MAX;

    for (auto& road : g_roads)
    {
        float dx = road.position.x - myPosition.x;
        float dy = road.position.y - myPosition.y;
        float dz = road.position.z - myPosition.z;

        float distance = std::sqrt(dx * dx + dy * dy + dz * dz);

        if (distance < nearestDistance)
        {
            nearestDistance = distance;
            nearestRoad = &road;
        }
    }

    if (nearestRoad && nearestRoad->audioGroup)
    {
        auto audio = nearestRoad->audioGroup->GetRandomAudio();

        RadioSounds::PlayAudioNow(audio);
    }
}

void BackupUnits::SpawnBackupUnit(PoliceVehicleData* unit)
{
    fileLog->Log("BackupUnits: SpawnBackupUnit");

    if(Criminals::GetCriminals()->size() == 0)
    {
        BottomMessage::SetMessage(GetTranslatedText("error_no_suspects_found"), 3000);
        return;
    }
    
    bool isHelicopter = IsModelAPoliceHelicopter(unit->vehicleModelId);

    auto closePosition = GetPedPositionWithOffset(GetPlayerActor(), CVector(0, 120, 0));

    auto spawnPosition = GET_CLOSEST_CAR_NODE(closePosition.x, closePosition.y, closePosition.z);

    if(isHelicopter)
    {
        spawnPosition.z += 100.0f;
    }

    ModelLoader::AddModelToLoad(unit->vehicleModelId);
    ModelLoader::AddModelToLoad(unit->skinModelId, true); // reforco: permite especiais (288 etc)
    ModelLoader::LoadAll([unit, spawnPosition, isHelicopter]() {
        int vehicleModelId = unit->vehicleModelId;
        if (!HAS_MODEL_LOADED(vehicleModelId))
        {
            REQUEST_MODEL(vehicleModelId);
            LOAD_REQUESTED_MODELS();
        }
        if (!HAS_MODEL_LOADED(vehicleModelId))
        {
            fileLog->Error("BackupUnits: modelo " + std::to_string(vehicleModelId) + " nao carregou (CColModel crash evitado)");
            BottomMessage::SetMessage("~r~Modelo de apoio nao carregou", 3000);
            return;
        }

        auto carRef = CREATE_CAR_AT(vehicleModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        if (!CAR_DEFINED(carRef))
        {
            fileLog->Error("BackupUnits: CREATE_CAR_AT falhou model=" + std::to_string(vehicleModelId));
            BottomMessage::SetMessage("~r~Falha ao criar viatura de apoio", 2500);
            return;
        }
        auto car = Vehicles::RegisterVehicle(carRef);
        car->flags.isBackup = true;

        // Remap MultiRemap: sorteia um da lista do backup.ini (sem lag — so 1 chamada)
        if (multiRemap && unit->remaps.size() > 0)
        {
            int idx = 0;
            if (unit->remaps.size() > 1)
                idx = rand() % (int)unit->remaps.size();
            std::string remapName = unit->remaps[idx];
            if (!remapName.empty())
                multiRemap->SetVehicleRemap(carRef, remapName);
        }

        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, unit->skinModelId);
        Peds::RegisterPed(driverRef);

        int occupants = unit->occupants;
        if (occupants < 1) occupants = 1;
        if (occupants > 4) occupants = 4;
        auto numOfPassengers = occupants - 1;

        if(numOfPassengers > 0)
        {
            for (auto i = 0; i < numOfPassengers; i++)
            {
                auto passengerRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::Special, unit->skinModelId, i);
                Peds::RegisterPed(passengerRef);
            }
        }

        if(isHelicopter)
        {
            SET_HELICOPTER_INSTANT_ROTOR_START(carRef);
            SET_CAR_ENGINE_OPERATION(carRef, true);
        }

        AddVehicleAsBackup(car, false);
    });
}

void BackupUnits::SpawnRandomBackupUnit()
{
    fileLog->Log("BackupUnits: SpawnRandomBackupUnit");
    
    auto unit = GetRandomUnitByChance(PoliceVehicles::vehicles);

    SpawnBackupUnit(unit);
}

void BackupUnits::SpawnHelicopterBackup()
{
    fileLog->Log("BackupUnits: SpawnHelicopterBackup");
    
    auto unit = GetRandomUnitByChance(PoliceVehicles::helicopters);

    SpawnBackupUnit(unit);
}

void BackupUnits::AddVehicleAsBackup(Vehicle* vehicle, bool recreatePeds)
{
    fileLog->Log("BackupUnits: AddVehicleAsBackup");

    //REMOVE_REFERENCES_TO_CAR(vehicle->ref);

    if(recreatePeds)
    {
        auto oldDriverRef = vehicle->GetCurrentDriver();

        if(oldDriverRef > 0)
        {
            auto oldDriver = Peds::GetPed(oldDriverRef);

            auto driverModelId = GET_ACTOR_MODEL(oldDriver->ref);
            
            oldDriver->DestroyImmediate();

            auto newDriverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(vehicle->ref, PedType::Special, driverModelId);
            Peds::RegisterPed(newDriverRef);
        }
    }

    fileLog->Log("Setup occupants");

    bool isHelicopter = IsModelAPoliceHelicopter(vehicle->GetModelId());

    auto occupants = vehicle->GetCurrentOccupants();
    for(auto pedRef : occupants)
    {
        auto cop = Peds::GetPed(pedRef);

        ModelLoader::AddModelToLoad(346);
        ModelLoader::LoadAll([pedRef]() {
            GIVE_ACTOR_WEAPON(pedRef, 22, 100);
        });

        //cop->ShowBlip(COLOR_POLICE);

        if(isHelicopter)
        {
            auto ai = new AIHelicopterCop();
            AIController::AddAIToPed(cop, ai);
            ai->Start();
        } else {
            auto ai = new AICop();
            AIController::AddAIToPed(cop, ai);
            ai->Start();
        }
    }

    vehicle->SetOwners();
    vehicle->ShowBlip(COLOR_POLICE);

    backupVehicles.push_back(vehicle);
}

PoliceVehicleData* BackupUnits::GetRandomUnitByChance(std::vector<PoliceVehicleData>& units)
{
    if (units.empty())
        return nullptr;

    // Calcula o total de chances (somatório)
    float totalChance = 0.0f;
    for (auto& unit : units)
        totalChance += unit.chance; // supondo que BackupUnit tenha 'float chance'

    if (totalChance <= 0.0f)
        return nullptr;

    // Gera um número aleatório entre 0 e totalChance
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dist(0.0f, totalChance);

    float randomValue = dist(gen);

    // Escolhe a unit com base nas chances acumuladas
    float cumulative = 0.0f;
    for (auto& unit : units)
    {
        cumulative += unit.chance;
        if (randomValue <= cumulative)
            return &unit;
    }

    // fallback (em teoria nunca chega aqui)
    return &units.back();
}

void BackupUnits::OpenSpawnBackupMenu()
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_spawn_backup"));
    
    for (auto& unit : PoliceVehicles::vehicles)
    {
        PoliceVehicleData unitCopy = unit;

        auto button = window->AddButton(unit.name);

        button->onClick->Add([window, unitCopy]() mutable {
            window->Close();
            SpawnBackupUnit(&unitCopy);
        });
    }
    
    for (auto& unit : PoliceVehicles::helicopters)
    {
        PoliceVehicleData unitCopy = unit;

        auto button = window->AddButton(unit.name);

        button->onClick->Add([window, unitCopy]() mutable {
            window->Close();
            SpawnBackupUnit(&unitCopy);
        });
    }

    {
        auto button = window->AddButton("~y~" + GetTranslatedText("close"));
        button->onClick->Add([window]() {
            window->Close();
        });
    }
}

void BackupUnits::SpawnMedicUnit(CVector position)
{
    auto vehicleModelId = 416;
    auto pedModelId = 274;

    auto spawnPosition = GET_CLOSEST_CAR_NODE(position.x + 120, position.y, position.z);

    ModelLoader::AddModelToLoad(vehicleModelId);
    ModelLoader::AddModelToLoad(pedModelId, true);
    ModelLoader::LoadAll([vehicleModelId, pedModelId, spawnPosition, position]() {

        auto carRef = CREATE_CAR_AT(vehicleModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        auto car = Vehicles::RegisterVehicle(carRef);

        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, pedModelId);
        Peds::RegisterPed(driverRef);

        auto passengerRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::Special, pedModelId, 0);
        Peds::RegisterPed(passengerRef);

        car->SetOwners();
        car->ShowBlip(COLOR_YELLOW);

        for(auto pedRef : car->GetCurrentOccupants())
        {
            auto medic = Peds::GetPed(pedRef);

            auto ai = new AIMedic();
            AIController::AddAIToPed(medic, ai);
            ai->targetPosition = position;
            ai->Start();
        }
    });
}

void BackupUnits::SpawnIMLUnit(CVector position)
{
    // IML: van 442 + ped 70 (igual mod antigo), sem ressuscitar
    auto vehicleModelId = 442;
    auto pedModelId = 70;

    auto spawnPosition = GET_CLOSEST_CAR_NODE(position.x + 120, position.y, position.z);

    ModelLoader::AddModelToLoad(vehicleModelId);
    ModelLoader::AddModelToLoad(pedModelId, true);
    ModelLoader::AddModelToLoad(367); // modelo da camera (arma 43)
    ModelLoader::LoadAll([vehicleModelId, pedModelId, spawnPosition, position]() {

        auto carRef = CREATE_CAR_AT(vehicleModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        auto car = Vehicles::RegisterVehicle(carRef);

        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, pedModelId);
        Peds::RegisterPed(driverRef);

        auto passengerRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::Special, pedModelId, 0);
        Peds::RegisterPed(passengerRef);

        GIVE_ACTOR_WEAPON(driverRef, 43, 100);
        SET_CURRENT_ACTOR_WEAPON(driverRef, 43);
        GIVE_ACTOR_WEAPON(passengerRef, 43, 100);
        SET_CURRENT_ACTOR_WEAPON(passengerRef, 43);

        car->SetOwners();
        car->ShowBlip(COLOR_YELLOW);

        for(auto pedRef : car->GetCurrentOccupants())
        {
            auto medic = Peds::GetPed(pedRef);

            auto ai = new AIMedic();
            ai->isIML = true;
            AIController::AddAIToPed(medic, ai);
            ai->targetPosition = position;
            ai->Start();
        }
    });
}

void BackupUnits::SpawnFiremenUnit(CVector position)
{
    // Caminhão de bombeiro 407 + skin 277, 2 ocupantes, sirene ligada
    auto vehicleModelId = 407;
    auto pedModelId = 277;

    auto spawnPosition = GET_CLOSEST_CAR_NODE(position.x + 120, position.y, position.z);

    ModelLoader::AddModelToLoad(vehicleModelId);
    ModelLoader::AddModelToLoad(pedModelId, true);
    ModelLoader::LoadAll([vehicleModelId, pedModelId, spawnPosition, position]() {

        auto carRef = CREATE_CAR_AT(vehicleModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        auto car = Vehicles::RegisterVehicle(carRef);

        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, pedModelId);
        Peds::RegisterPed(driverRef);

        auto passengerRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::Special, pedModelId, 0);
        Peds::RegisterPed(passengerRef);

        car->SetOwners();
        car->ShowBlip(COLOR_YELLOW);

        ENABLE_CAR_SIREN(carRef, true);

        for (auto pedRef : car->GetCurrentOccupants())
        {
            auto ped = Peds::GetPed(pedRef);
            auto ai = new AIFireman();
            AIController::AddAIToPed(ped, ai);
            ai->targetPosition = position;
            ai->Start();
        }
    });
}
