#include "DispatchPanel.h"
#include "NotifStack.h"
#include "Callouts.h"

// ---------------------------------------------------------------------------
// Painel de ocorrencia — posicao, tamanho e animacao configuraveis.
// Anim: 0=off 1=cima 2=baixo 3=esquerda 4=direita 5=fade
// ---------------------------------------------------------------------------

static IContainer* s_root = nullptr;
static IContainer* s_badge = nullptr;
static IContainer* s_title1 = nullptr;
static IContainer* s_title2 = nullptr;
static IContainer* s_callLine1 = nullptr;
static IContainer* s_callLine2 = nullptr;
static IContainer* s_callLine3 = nullptr;
static IContainer* s_locationLabel = nullptr;
static IContainer* s_instructionLine1 = nullptr;
static IContainer* s_instructionLine2 = nullptr;
static IContainer* s_sep = nullptr;
static IContainer* s_infoHeader = nullptr;

// Painel secundario: ocorrencia ANTERIOR sobe quando chega outra
static IContainer* s_prevRoot = nullptr;
static IContainer* s_prevCall1 = nullptr;
static IContainer* s_prevCall2 = nullptr;
static IContainer* s_prevLoc = nullptr;
static IContainer* s_prevInst = nullptr;
static int s_prevTimer = 0;
static int s_prevDuration = 0;
static bool s_prevVisible = false;

static int s_timer = 0;
static int s_duration = 0;
static bool s_visible = false;

// 0 = idle | 1 = entrando | 2 = saindo
static int s_animPhase = 0;
static float s_animT = 0.0f; // 0..1

static const float BASE_PANEL_W = 400.0f;
static const float BASE_PANEL_H = 230.0f;
static const float BASE_TEXT_W = 370.0f;
static const int MAX_CHARS_PER_LINE = 34;
static const float SLIDE_DIST = 280.0f;
static const unsigned char BASE_BG_A = 210;

static IContainer* MakeLabel(IContainer* parent, const std::string& tag, float fontSize, CRGBA color, CVector2D size)
{
    auto label = menuSZK->CreateContainer(tag);
    label->drawBackground = false;
    label->size = size;
    label->text = "";
    label->textHorizontalAlign = HorizontalAlign::Left;
    label->textVerticalAlign = VerticalAlign::Middle;
    label->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;

    auto font = &label->textFont;
    font->fontSize = fontSize;
    font->color = color;
    font->align = eFontAlignment::ALIGN_LEFT;

    parent->AddChild(label);
    return label;
}

static void WrapText(const std::string& input, int maxChars, int maxLines, std::vector<std::string>& out)
{
    out.clear();
    if (input.empty())
    {
        out.push_back("");
        return;
    }

    std::string remaining = input;
    while (!remaining.empty() && (int)out.size() < maxLines)
    {
        if ((int)remaining.size() <= maxChars)
        {
            out.push_back(remaining);
            remaining.clear();
            break;
        }

        int breakAt = maxChars;
        int searchLimit = (int)remaining.size() < maxChars ? (int)remaining.size() - 1 : maxChars;
        for (int i = searchLimit; i > maxChars / 3; --i)
        {
            if (remaining[i] == ' ')
            {
                breakAt = i;
                break;
            }
        }

        out.push_back(remaining.substr(0, breakAt));
        remaining = remaining.substr(breakAt);
        while (!remaining.empty() && remaining[0] == ' ')
            remaining.erase(0, 1);
    }

    if (!remaining.empty() && !out.empty())
    {
        std::string& last = out.back();
        if ((int)last.size() > 3)
            last = last.substr(0, last.size() - 3) + "...";
        else
            last += "...";
    }

    while ((int)out.size() < maxLines)
        out.push_back("");
}

static float Scale()
{
    int sz = CALLOUT_UI_SIZE;
    if (sz < 0) sz = 0;
    if (sz > 100) sz = 100;
    float s = sz / 100.0f;
    if (s < 0.30f) s = 0.30f;
    return s;
}

// Ease out cubic
static float EaseOut(float t)
{
    float u = 1.0f - t;
    return 1.0f - u * u * u;
}

// Ease in cubic
static float EaseIn(float t)
{
    return t * t * t;
}

static float AnimAlpha()
{
    if (CALLOUT_UI_ANIM == 0) return 1.0f;
    if (s_animPhase == 1) return EaseOut(s_animT);       // entrando 0->1
    if (s_animPhase == 2) return 1.0f - EaseIn(s_animT); // saindo 1->0
    return 1.0f;
}

static CVector2D AnimOffset()
{
    if (CALLOUT_UI_ANIM == 0 || CALLOUT_UI_ANIM == 5)
        return CVector2D(0, 0);

    float amount = 0.0f;
    if (s_animPhase == 1)
        amount = (1.0f - EaseOut(s_animT)) * SLIDE_DIST; // vem de fora
    else if (s_animPhase == 2)
        amount = EaseIn(s_animT) * SLIDE_DIST;           // vai pra fora
    else
        return CVector2D(0, 0);

    switch (CALLOUT_UI_ANIM)
    {
    case 1: return CVector2D(0, -amount); // de cima
    case 2: return CVector2D(0, amount);  // de baixo
    case 3: return CVector2D(-amount, 0); // da esquerda
    case 4: return CVector2D(amount, 0);  // da direita
    default: return CVector2D(0, 0);
    }
}

static void SetPanelAlpha(float a)
{
    if (!s_root) return;
    if (a < 0.0f) a = 0.0f;
    if (a > 1.0f) a = 1.0f;
    unsigned char ba = (unsigned char)(BASE_BG_A * a);
    s_root->backgroundColor = CRGBA(15, 18, 25, ba);

    auto setFontA = [a](IContainer* c) {
        if (!c) return;
        auto col = c->textFont.color;
        col.a = (unsigned char)(255 * a);
        c->textFont.color = col;
    };
    if (s_badge)
    {
        s_badge->backgroundColor = CRGBA(200, 30, 30, (unsigned char)(255 * a));
        setFontA(s_badge);
    }
    setFontA(s_title1);
    setFontA(s_title2);
    setFontA(s_callLine1);
    setFontA(s_callLine2);
    setFontA(s_callLine3);
    setFontA(s_locationLabel);
    setFontA(s_instructionLine1);
    setFontA(s_instructionLine2);
    setFontA(s_infoHeader);
    if (s_sep)
        s_sep->backgroundColor = CRGBA(80, 90, 110, (unsigned char)(140 * a));
}

void DispatchPanel::ApplyLayout()
{
    if (!s_root) return;

    float s = Scale();
    CVector2D animOff = AnimOffset();

    // altura real do conteudo (infoHeader em y=200 + 22 de margem)
    float contentH = 222.0f * s;
    float panelH = contentH;
    s_root->size = CVector2D(BASE_PANEL_W * s, panelH);
    // Novo embaixo (EXTRA), antigo no topo (DISPATCH) quando empilhado
    if (s_prevVisible)
    {
        NotifStack::SetActive(NotifStack::SLOT_EXTRA_BASE, s_visible, panelH);
        NotifStack::SetActive(NotifStack::SLOT_DISPATCH, true, panelH);
    }
    else
    {
        NotifStack::SetActive(NotifStack::SLOT_DISPATCH, s_visible, panelH);
        NotifStack::SetActive(NotifStack::SLOT_EXTRA_BASE, false, 0.0f);
    }
    int mainSlot = s_prevVisible ? NotifStack::SLOT_EXTRA_BASE : NotifStack::SLOT_DISPATCH;
    float stackY = NotifStack::GetOffsetY(mainSlot);
    s_root->localOffset = CVector2D(
        (float)CALLOUT_UI_POS_X + animOff.x,
        (float)CALLOUT_UI_POS_Y + animOff.y + stackY
    );
    if (s_prevRoot && s_prevVisible)
    {
        float prevY = NotifStack::GetOffsetY(NotifStack::SLOT_DISPATCH);
        s_prevRoot->localOffset = CVector2D((float)CALLOUT_UI_POS_X, (float)CALLOUT_UI_POS_Y + prevY);
        s_prevRoot->size = CVector2D(BASE_PANEL_W * s, panelH);
    }

    float tw = BASE_TEXT_W * s;

    if (s_badge)
    {
        s_badge->size = CVector2D(44 * s, 26 * s);
        s_badge->localOffset = CVector2D(10 * s, 10 * s);
        s_badge->textFont.fontSize = 1.35f * s;
        s_badge->text = GetCalloutBadgeText();
    }
    if (s_title1)
    {
        s_title1->size = CVector2D(tw, 22 * s);
        s_title1->localOffset = CVector2D(60 * s, 6 * s);
        s_title1->textFont.fontSize = 1.45f * s;
    }
    if (s_title2)
    {
        s_title2->size = CVector2D(tw, 20 * s);
        s_title2->localOffset = CVector2D(60 * s, 28 * s);
        s_title2->textFont.fontSize = 1.25f * s;
    }
    if (s_callLine1)
    {
        s_callLine1->size = CVector2D(tw, 20 * s);
        s_callLine1->localOffset = CVector2D(12 * s, 58 * s);
        s_callLine1->textFont.fontSize = 1.15f * s;
    }
    if (s_callLine2)
    {
        s_callLine2->size = CVector2D(tw, 20 * s);
        s_callLine2->localOffset = CVector2D(12 * s, 78 * s);
        s_callLine2->textFont.fontSize = 1.15f * s;
    }
    if (s_callLine3)
    {
        s_callLine3->size = CVector2D(tw, 20 * s);
        s_callLine3->localOffset = CVector2D(12 * s, 98 * s);
        s_callLine3->textFont.fontSize = 1.15f * s;
    }
    if (s_locationLabel)
    {
        s_locationLabel->size = CVector2D(tw, 20 * s);
        s_locationLabel->localOffset = CVector2D(12 * s, 122 * s);
        s_locationLabel->textFont.fontSize = 1.15f * s;
    }
    if (s_instructionLine1)
    {
        s_instructionLine1->size = CVector2D(tw, 18 * s);
        s_instructionLine1->localOffset = CVector2D(12 * s, 146 * s);
        s_instructionLine1->textFont.fontSize = 1.1f * s;
    }
    if (s_instructionLine2)
    {
        s_instructionLine2->size = CVector2D(tw, 18 * s);
        s_instructionLine2->localOffset = CVector2D(12 * s, 164 * s);
        s_instructionLine2->textFont.fontSize = 1.1f * s;
    }
    if (s_sep)
    {
        s_sep->size = CVector2D(tw, 2 * s);
        s_sep->localOffset = CVector2D(12 * s, 192 * s);
    }
    if (s_infoHeader)
    {
        s_infoHeader->size = CVector2D(tw, 20 * s);
        s_infoHeader->localOffset = CVector2D(12 * s, 200 * s);
        s_infoHeader->textFont.fontSize = 1.15f * s;
    }

    SetPanelAlpha(AnimAlpha());
}

void DispatchPanel::Initialize()
{
    auto root = menuSZK->CreateContainer("dispatchPanel");
    root->horizontalAlign = HorizontalAlign::Left;
    root->verticalAlign = VerticalAlign::Top;
    root->localOffset = CVector2D((float)CALLOUT_UI_POS_X, (float)CALLOUT_UI_POS_Y);
    root->size = CVector2D(BASE_PANEL_W, BASE_PANEL_H);
    root->drawBackground = true;
    root->backgroundColor = CRGBA(15, 18, 25, BASE_BG_A);
    root->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    root->isVisible = false;
    root->hideWhenPauseGame = true;

    menuSZK->GetRootContainer()->AddChild(root);
    s_root = root;

    auto badge = menuSZK->CreateContainer("badge911");
    badge->size = CVector2D(44, 26);
    badge->localOffset = CVector2D(10, 10);
    badge->drawBackground = true;
    badge->backgroundColor = CRGBA(200, 30, 30, 255);
    badge->text = GetCalloutBadgeText();
    badge->textHorizontalAlign = HorizontalAlign::Middle;
    badge->textVerticalAlign = VerticalAlign::Middle;
    badge->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    {
        auto font = &badge->textFont;
        font->fontSize = 1.35f;
        font->color = CRGBA(255, 255, 255);
        font->align = eFontAlignment::ALIGN_CENTER;
    }
    root->AddChild(badge);
    s_badge = badge;

    s_title1 = MakeLabel(root, "title1", 1.45f, CRGBA(255, 255, 255), CVector2D(BASE_TEXT_W, 22));
    s_title1->localOffset = CVector2D(60, 6);
    s_title1->text = "OCORRENCIA";

    s_title2 = MakeLabel(root, "title2", 1.25f, CRGBA(220, 220, 220), CVector2D(BASE_TEXT_W, 20));
    s_title2->localOffset = CVector2D(60, 28);
    s_title2->text = "CHAMADA DE EMERGENCIA";

    s_callLine1 = MakeLabel(root, "call1", 1.15f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
    s_callLine1->localOffset = CVector2D(12, 58);

    s_callLine2 = MakeLabel(root, "call2", 1.15f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
    s_callLine2->localOffset = CVector2D(12, 78);

    s_callLine3 = MakeLabel(root, "call3", 1.15f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
    s_callLine3->localOffset = CVector2D(12, 98);

    s_locationLabel = MakeLabel(root, "location", 1.15f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
    s_locationLabel->localOffset = CVector2D(12, 122);

    s_instructionLine1 = MakeLabel(root, "inst1", 1.1f, CRGBA(200, 200, 200), CVector2D(BASE_TEXT_W, 18));
    s_instructionLine1->localOffset = CVector2D(12, 146);

    s_instructionLine2 = MakeLabel(root, "inst2", 1.1f, CRGBA(200, 200, 200), CVector2D(BASE_TEXT_W, 18));
    s_instructionLine2->localOffset = CVector2D(12, 164);

    auto sep = menuSZK->CreateContainer("sep");
    sep->size = CVector2D(BASE_TEXT_W, 2);
    sep->localOffset = CVector2D(12, 192);
    sep->drawBackground = true;
    sep->backgroundColor = CRGBA(80, 90, 110, 140);
    sep->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    root->AddChild(sep);
    s_sep = sep;

    s_infoHeader = MakeLabel(root, "infoHeader", 1.15f, CRGBA(180, 190, 210), CVector2D(BASE_TEXT_W, 20));
    s_infoHeader->localOffset = CVector2D(12, 200);
    s_infoHeader->text = "OCORRENCIA  informacao";

    // Painel secundario (ocorrencia antiga sobe)
    auto prev = menuSZK->CreateContainer("dispatchPanelPrev");
    prev->horizontalAlign = HorizontalAlign::Left;
    prev->verticalAlign = VerticalAlign::Top;
    prev->localOffset = CVector2D((float)CALLOUT_UI_POS_X, (float)CALLOUT_UI_POS_Y);
    prev->size = CVector2D(BASE_PANEL_W, BASE_PANEL_H);
    prev->drawBackground = true;
    prev->backgroundColor = CRGBA(15, 18, 25, BASE_BG_A);
    prev->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    prev->isVisible = false;
    prev->hideWhenPauseGame = true;
    menuSZK->GetRootContainer()->AddChild(prev);
    s_prevRoot = prev;

    s_prevCall1 = MakeLabel(prev, "prevCall1", 1.15f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
    s_prevCall1->localOffset = CVector2D(12, 20);
    s_prevCall2 = MakeLabel(prev, "prevCall2", 1.15f, CRGBA(230, 230, 230), CVector2D(BASE_TEXT_W, 20));
    s_prevCall2->localOffset = CVector2D(12, 42);
    s_prevLoc = MakeLabel(prev, "prevLoc", 1.1f, CRGBA(200, 200, 200), CVector2D(BASE_TEXT_W, 20));
    s_prevLoc->localOffset = CVector2D(12, 70);
    s_prevInst = MakeLabel(prev, "prevInst", 1.1f, CRGBA(200, 200, 200), CVector2D(BASE_TEXT_W, 20));
    s_prevInst->localOffset = CVector2D(12, 94);

    ApplyLayout();
}

void DispatchPanel::Update()
{
    if (!s_root) return;

    // Timer do painel antigo (sobe e some sozinho)
    if (s_prevVisible && s_prevRoot)
    {
        s_prevTimer += (int)menuSZK->deltaTime;
        if (s_prevTimer >= s_prevDuration)
        {
            s_prevVisible = false;
            s_prevRoot->isVisible = false;
            NotifStack::SetActive(NotifStack::SLOT_DISPATCH, s_visible, 0.0f);
            ApplyLayout();
        }
    }

    if (!s_visible)
    {
        s_root->isVisible = false;
        return;
    }

    int animMs = CALLOUT_UI_ANIM_MS;
    if (animMs < 100) animMs = 100;

    // Animacao de entrada / saida
    if (CALLOUT_UI_ANIM != 0 && (s_animPhase == 1 || s_animPhase == 2))
    {
        s_animT += (float)menuSZK->deltaTime / (float)animMs;
        if (s_animT >= 1.0f)
        {
            s_animT = 1.0f;
            if (s_animPhase == 1)
            {
                s_animPhase = 0; // idle visivel
            }
            else if (s_animPhase == 2)
            {
                // terminou saida
                s_visible = false;
                s_animPhase = 0;
                s_root->isVisible = false;
                SetPanelAlpha(1.0f);
                return;
            }
        }
    }

    s_timer += menuSZK->deltaTime;

    // Dispara saida um pouco antes do fim (se anim ligada)
    if (s_animPhase == 0 && CALLOUT_UI_ANIM != 0)
    {
        int outStart = s_duration - animMs;
        if (outStart < 0) outStart = 0;
        if (s_timer >= outStart)
        {
            s_animPhase = 2;
            s_animT = 0.0f;
        }
    }
    else if (s_animPhase == 0 && CALLOUT_UI_ANIM == 0)
    {
        if (s_timer >= s_duration)
        {
            Hide();
            return;
        }
    }

    ApplyLayout();
    s_root->isVisible = true;
}

static std::string s_lastCallType;
static std::string s_lastLocation;
static std::string s_lastInstruction;
static int s_lastDurationMs = 12000;
static bool s_hasLast = false;

void DispatchPanel::Show(const std::string& callType, const std::string& location, const std::string& instruction, int durationMs)
{
    if (!s_root) return;

    // Se ja tem uma ocorrencia na tabela, empurra a antiga pra cima
    if (s_visible && s_prevRoot)
    {
        if (s_prevCall1) s_prevCall1->text = s_callLine1 ? s_callLine1->text : "";
        if (s_prevCall2) s_prevCall2->text = s_callLine2 ? s_callLine2->text : "";
        if (s_prevLoc) s_prevLoc->text = s_locationLabel ? s_locationLabel->text : "";
        if (s_prevInst) s_prevInst->text = s_instructionLine1 ? s_instructionLine1->text : "";
        s_prevDuration = s_duration > 0 ? s_duration : 12000;
        s_prevTimer = 0;
        s_prevVisible = true;
        s_prevRoot->isVisible = true;
    }

    s_lastCallType = callType;
    s_lastLocation = location;
    s_lastInstruction = instruction;
    s_lastDurationMs = durationMs > 0 ? durationMs : 12000;
    s_hasLast = true;

    std::string callFull = std::string("Chamado: ") + callType;
    std::vector<std::string> callLines;
    WrapText(callFull, MAX_CHARS_PER_LINE, 3, callLines);
    s_callLine1->text = callLines[0];
    s_callLine2->text = callLines[1];
    s_callLine3->text = callLines[2];

    // Se ja vier com prefixo "Placa:", nao coloca "Local:" (ex.: veiculo roubado na regiao)
    std::string locFull;
    if (location.size() >= 6 &&
        (location.compare(0, 6, "Placa:") == 0 || location.compare(0, 6, "placa:") == 0))
        locFull = location;
    else
        locFull = std::string("Local: ") + location;
    if ((int)locFull.size() > MAX_CHARS_PER_LINE)
        locFull = locFull.substr(0, MAX_CHARS_PER_LINE - 3) + "...";
    s_locationLabel->text = locFull;

    std::vector<std::string> instLines;
    WrapText(instruction, MAX_CHARS_PER_LINE, 2, instLines);
    s_instructionLine1->text = instLines[0];
    s_instructionLine2->text = instLines[1];

    s_timer = 0;
    s_duration = durationMs > 0 ? durationMs : 12000;
    s_visible = true;
    s_root->isVisible = true;

    if (CALLOUT_UI_ANIM == 0)
    {
        s_animPhase = 0;
        s_animT = 1.0f;
        SetPanelAlpha(1.0f);
    }
    else
    {
        s_animPhase = 1; // entrando
        s_animT = 0.0f;
    }

    ApplyLayout();
    extern void FriskPanel_RelayoutIfVisible();
    FriskPanel_RelayoutIfVisible();
}

bool DispatchPanel::HasLast()
{
    return s_hasLast;
}

void DispatchPanel::ShowLast()
{
    if (!s_hasLast) return;
    Show(s_lastCallType, s_lastLocation, s_lastInstruction, s_lastDurationMs);
}

void DispatchPanel::Hide()
{
    // Se anim ligada e ainda visivel, faz saida suave
    if (s_visible && CALLOUT_UI_ANIM != 0 && s_animPhase != 2)
    {
        s_animPhase = 2;
        s_animT = 0.0f;
        return;
    }

    s_visible = false;
    s_timer = 0;
    s_animPhase = 0;
    s_animT = 0.0f;
    if (s_root)
        s_root->isVisible = false;
    SetPanelAlpha(1.0f);
    // Tambem esconde o painel antigo empilhado
    s_prevVisible = false;
    s_prevTimer = 0;
    if (s_prevRoot)
        s_prevRoot->isVisible = false;
    NotifStack::SetActive(NotifStack::SLOT_DISPATCH, false, 0.0f);
    NotifStack::SetActive(NotifStack::SLOT_EXTRA_BASE, false, 0.0f);
    // reempilha o outro painel se estiver aberto
    extern void FriskPanel_RelayoutIfVisible();
    FriskPanel_RelayoutIfVisible();
}

bool DispatchPanel::IsVisible()
{
    return s_visible;
}
