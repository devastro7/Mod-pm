#include "ModPolicia.h"

#include "DualPatrol.h"
#include "Vehicle.h"
#include "Vehicles.h"
#include "CleoFunctions.h"
#include "RadioWindow.h"

bool ModPolicia::IsRadioOpen()
{
    // MainContainer existe depois do Initialize; so conta como aberto se VISIVEL
    return RadioWindow::MainContainer != nullptr && RadioWindow::MainContainer->isVisible;
}

bool ModPolicia::IsMenuOpen()
{
    // Nao bloquear o painel do Giroflex.
    // So considera "menu aberto" quando o radio do policia esta visivel.
    // (MainContainer != null sozinho quebrava o painel — ele sempre existe apos init)
    return RadioWindow::MainContainer != nullptr && RadioWindow::MainContainer->isVisible;
}

bool ModPolicia::HasDualPatrolUnits()
{
    return DualPatrol::HasAnyUnit();
}

int ModPolicia::GetDualPatrolVehicles(int* outHandles, int* outModels, int maxCount)
{
    if (!outHandles || maxCount <= 0)
        return 0;

    if (!DualPatrol::HasAnyUnit())
        return 0;

    int n = 0;
    for (auto* vehicle : DualPatrol::escortVehicles)
    {
        if (n >= maxCount)
            break;

        if (!vehicle)
            continue;

        int h = vehicle->ref;
        if (h <= 0)
            continue;

        if (!CAR_DEFINED(h))
            continue;

        outHandles[n] = h;
        if (outModels)
            outModels[n] = vehicle->GetModelId();
        n++;
    }
    return n;
}

static ModPolicia modPoliciaLocal;
IModPolicia* modPolicia = &modPoliciaLocal;
