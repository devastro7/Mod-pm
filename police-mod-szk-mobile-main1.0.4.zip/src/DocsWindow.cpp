#include "DocsWindow.h"

#include "BottomMessage.h"
#include "CleoFunctions.h"
#include "Vehicles.h"
#include "Peds.h"
#include "AudioCollection.h"
#include "AudioSequence.h"
#include "RadioSounds.h"
#include "FriskPanel.h"

void DocsWindow::ShowRG(Ped* ped)
{
    if (!ped) return;
    int pedRef = ped->ref;

    std::vector<std::string> lines;
    lines.push_back("Nome: " + ped->name);
    lines.push_back("RG: " + ped->rg);
    lines.push_back("CPF: " + ped->cpf);
    lines.push_back("Nasc: " + ped->birthDate);

    // Painel: mostra dados do RG e ja inicia consulta automatica
    if (FriskPanel::UsePanel())
    {
        FriskPanel::Show("RG", "RG", "Documento do individuo", lines);
        BottomMessage::SetMessage(GetTranslatedText("checking_rg"), 5000);
        WAIT(5000, [pedRef]() {
            auto p = Peds::GetPed(pedRef);
            if (!p || !Peds::IsValid(p)) return;
            ShowRGResults(p);
        });
    }

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_rg"));

        window->AddText("- Nome: " + ped->name);
        window->AddText("- ID: " + std::to_string(ped->ref));
        window->AddText("- RG: " + ped->rg);
        window->AddText("- CPF: " + ped->cpf);
        window->AddText("- Nasc: " + ped->birthDate);

        {
            auto button = window->AddButton(GetTranslatedText("check_rg"));
            button->onClick->Add([window, pedRef]() {
                window->Close();
                BottomMessage::SetMessage(GetTranslatedText("checking_rg"), 5000);
                WAIT(5000, [pedRef]() {
                    auto p = Peds::GetPed(pedRef);
                    if (!p || !Peds::IsValid(p)) return;
                    ShowRGResults(p);
                });
            });
        }

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
}

void DocsWindow::ShowRGResults(Ped* ped)
{
    std::vector<std::string> lines;
    if (ped->flags.wantedByJustice)
        lines.push_back("~r~" + GetTranslatedText("suspect_with_warrant"));
    else
        lines.push_back(GetTranslatedText("suspect_with_no_warrant"));
    lines.push_back("RG: " + ped->rg);
    lines.push_back("CPF: " + ped->cpf);

    if (FriskPanel::UsePanel())
        FriskPanel::Show("CONSULTA RG", "RG", "Resultado da consulta", lines);

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_rg_results"));

        if (ped->flags.wantedByJustice)
            window->AddText(GetTranslatedText("suspect_with_warrant"));
        else
            window->AddText(GetTranslatedText("suspect_with_no_warrant"));

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
}

void DocsWindow::ShowVehicleVisualInfo(Vehicle* vehicle)
{
    if (vehicle == nullptr) return;

    std::vector<std::string> lines;
    lines.push_back("Placa: " + vehicle->currentDoc.plate);
    lines.push_back("Cor: ?");

    // Painel so mostra info; botoes de consulta ficam no menu classico
    if (FriskPanel::UsePanel() && !FriskPanel::UseClassic())
    {
        // estilo so painel: mostra info e oferece consulta automatica por placa
        FriskPanel::Show("VEICULO", "VEI", "Dados visuais", lines);
        BottomMessage::SetMessage(GetTranslatedText("checking_plate"), 5000);
        auto audio = audioPlateCheck->GetRandomAudio();
        RadioSounds::PlayAudioNowDontAttach(audio);
        WaitForAudioFinish(audio, [vehicle]() {
            ShowVehicleResults(vehicle, true);
        });
        return;
    }

    if (FriskPanel::UsePanel())
        FriskPanel::Show("VEICULO", "VEI", "Dados visuais", lines);

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_vehicle"));

        window->AddText("- Placa: " + vehicle->currentDoc.plate);
        window->AddText("- Cor: ?");

        {
            auto button = window->AddButton(GetTranslatedText("check_vehicle_by_plate"));
            button->onClick->Add([window, vehicle]() {
                window->Close();
                BottomMessage::SetMessage(GetTranslatedText("checking_plate"), 5000);
                auto audio = audioPlateCheck->GetRandomAudio();
                RadioSounds::PlayAudioNowDontAttach(audio);
                WaitForAudioFinish(audio, [vehicle]() {
                    ShowVehicleResults(vehicle, true);
                });
            });
        }

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
}

void DocsWindow::ShowVehicleResults(Vehicle* vehicle, bool byPlate)
{
    auto doc = byPlate ? vehicle->currentDoc : vehicle->originalDoc;

    std::vector<std::string> lines;
    lines.push_back("Placa: " + doc.plate);
    lines.push_back("Chassi: " + doc.chassis);

    if (doc.isStolen)
        lines.push_back("~r~" + GetTranslatedText("vehicle_stolen"));
    else
        lines.push_back(GetTranslatedText("vehicle_not_stolen"));

    if (doc.isDocumentExpired)
        lines.push_back("~r~" + GetTranslatedText("vehicle_doc_expired"));
    else
        lines.push_back(GetTranslatedText("vehicle_doc_ok"));

    if (vehicle->flags.swappedPlate)
        lines.push_back("~r~" + GetTranslatedText("vehicle_caracteristics_not_ok"));
    else
        lines.push_back(GetTranslatedText("vehicle_caracteristics_ok"));

    if (FriskPanel::UsePanel())
        FriskPanel::Show("CONSULTA", "VEI", byPlate ? "Consulta por placa" : "Consulta por chassi", lines);

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_vehicle_results"));

        window->AddText("- Placa: " + doc.plate);
        window->AddText("- Chassi: " + doc.chassis);

        if (doc.isStolen)
            window->AddText("- " + GetTranslatedText("vehicle_stolen"));
        else
            window->AddText("- " + GetTranslatedText("vehicle_not_stolen"));

        if (doc.isDocumentExpired)
            window->AddText("- " + GetTranslatedText("vehicle_doc_expired"));
        else
            window->AddText("- " + GetTranslatedText("vehicle_doc_ok"));

        if (vehicle->flags.swappedPlate)
        {
            window->AddText("- ~r~" + GetTranslatedText("vehicle_caracteristics_not_ok"));
            if (byPlate)
            {
                auto button = window->AddButton(GetTranslatedText("check_vehicle_by_chassis"));
                button->onClick->Add([window, vehicle]() {
                    window->Close();
                    BottomMessage::SetMessage(GetTranslatedText("checking_chassis"), 5000);
                    WAIT(5000, [vehicle]() {
                        ShowVehicleResults(vehicle, false);
                    });
                });
            }
        }
        else
        {
            window->AddText("- " + GetTranslatedText("vehicle_caracteristics_ok"));
        }

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
    else if (vehicle->flags.swappedPlate && byPlate)
    {
        // estilo so painel: se placa trocada, consulta chassi automatica depois
        BottomMessage::SetMessage(GetTranslatedText("checking_chassis"), 5000);
        WAIT(5000, [vehicle]() {
            ShowVehicleResults(vehicle, false);
        });
    }
}

void DocsWindow::ShowCRLV(Ped* ped, Vehicle* vehicle)
{
    std::vector<std::string> lines;
    lines.push_back("Placa: " + vehicle->originalDoc.plate);
    lines.push_back("RENAVAM: " + vehicle->originalDoc.renavam);
    lines.push_back("Chassi: " + vehicle->originalDoc.chassis);
    lines.push_back("CPF: " + ped->cpf);

    if (FriskPanel::UsePanel())
        FriskPanel::Show("CRLV", "DOC", "Documento do veiculo", lines);

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_vehicle_results"));

        window->AddText("Placa: " + vehicle->originalDoc.plate);
        window->AddText("RENAVAM: " + vehicle->originalDoc.renavam);
        window->AddText("Chassi: " + vehicle->originalDoc.chassis);
        window->AddText("CPF: " + ped->cpf);

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
}

void DocsWindow::ShowCNH(Ped* ped)
{
    if (!ped) return;

    std::vector<std::string> lines;
    lines.push_back("Nome: " + ped->name);
    lines.push_back("CPF: " + ped->cpf);
    lines.push_back("Nasc: " + ped->birthDate);
    if (ped->catHab.length() > 0)
        lines.push_back(GetTranslatedText("cnh_category") + ped->catHab);
    else
        lines.push_back(GetTranslatedText("with_no_cnh"));
    if (ped->cnhExpireDate.length() > 0)
        lines.push_back("Validade: " + ped->cnhExpireDate);

    // Painel: mostra dados da CNH (ja e a "consulta" completa)
    if (FriskPanel::UsePanel())
        FriskPanel::Show("CNH", "CNH", "Carteira de habilitacao", lines);

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_cnh"));

        window->AddText("- Nome: " + ped->name);
        window->AddText("- CPF: " + ped->cpf);
        window->AddText("- Nasc: " + ped->birthDate);
        if (ped->catHab.length() > 0)
            window->AddText("- " + GetTranslatedText("cnh_category") + ped->catHab);
        else
            window->AddText("- " + GetTranslatedText("with_no_cnh"));
        if (ped->cnhExpireDate.length() > 0)
            window->AddText("- Validade: " + ped->cnhExpireDate);

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
}

void DocsWindow::ShowChassisResult(Vehicle* vehicle)
{
    std::vector<std::string> lines;
    if (vehicle->flags.chassisErased)
        lines.push_back("~r~Chassis: Suprimido");
    else
        lines.push_back("Chassis: " + vehicle->originalDoc.chassis);

    if (FriskPanel::UsePanel())
        FriskPanel::Show("CHASSI", "VEI", "Resultado do chassi", lines);

    if (FriskPanel::UseClassic())
    {
        auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_vehicle_results"));

        if (vehicle->flags.chassisErased)
            window->AddText("- Chassis: ~r~Suprimido");
        else
            window->AddText("- Chassis: " + vehicle->originalDoc.chassis);

        {
            auto button = window->AddButton("~y~" + GetTranslatedText("close"));
            button->onClick->Add([window]() {
                window->Close();
            });
        }
    }
}
