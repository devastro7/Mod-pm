#pragma once

#include "pch.h"
#include "Ped.h"
#include "Vehicle.h"
#include <map>

class Bafometro
{
public:
    static void Initialize();
    static void LoadSettings();
    static void SaveSettings();

    // Abre o teste e mostra o resultado (mesmo individuo = mesma medida)
    static void PerformTest(Ped* ped);

    // Chances configuraveis (somam ~1.0, mas normalizamos)
    static float chanceLow;    // 0.00 ~ 0.04
    static float chanceMid;    // 0.05 ~ 0.33
    static float chanceHigh;   // 0.34+

private:
    static bool s_loaded;
    // Resultado fixo por handle do ped (mesma medida no carro ou a pe)
    static std::map<int, float> s_resultsByPed;

    static std::string GetFolder();
    static float RollResult();
    static float GetOrCreateResult(int pedRef);
    static void ShowResultMessage(float result);
};
