#include <algorithm>
#include "Biqueiras.h"
#include "CleoFunctions.h"
#include "pch.h"

std::vector<Location> g_biqueiras;

// 0 = LS, 1 = SF, 2 = LV (mesmo criterio do mod)
static int CityOfPos(const CVector& p)
{
    if (p.x < -1000.0f) return 1; // SF
    if (p.x > 500.0f && p.y > 400.0f) return 2; // LV
    return 0; // LS
}

static int ClosestCityToPlayer()
{
    static const CVector kPDs[] = {
        CVector(1536.13f, -1671.21f, 13.38f),
        CVector(635.10f,  -571.82f,  16.34f),
        CVector(-1606.54f, 721.68f,  12.16f),
        CVector(-211.84f,  978.01f,  19.30f),
        CVector(2289.88f, 2425.89f,  10.82f),
    };
    static const int kCity[] = { 0, 0, 1, 2, 2 };
    auto player = GetPlayerPosition();
    int best = 0;
    float bestD = 1e12f;
    for (int i = 0; i < 5; i++)
    {
        float d = distanceBetweenPoints(player, kPDs[i]);
        if (d < bestD) { bestD = d; best = kCity[i]; }
    }
    return best;
}

void Biqueiras::Initialize()
{
    g_biqueiras.clear();
    auto add = [](float x, float y, float z, float rz = 0.0f) {
        Location location;
        location.position = CVector(x, y, z);
        location.rotation = CVector(0, 0, rz);
        g_biqueiras.push_back(location);
    };

    // Originais LS
    add(2362.81f, -1771.92f, 13.55f, 270);
    add(2171.47f, -1673.27f, 15.09f);
    add(2182.26f, -1341.58f, 23.98f);
    add(1993.58f, -1094.40f, 24.94f);

    // Novos
    add(2572.23f, -967.77f, 81.93f);
    add(1225.36f, -2014.96f, 66.94f);
    add(2504.67f, 65.18f, 27.08f);
    add(2214.36f, 739.08f, 11.46f);
    add(1062.91f, 1995.05f, 10.82f);
    add(-2366.61f, 2441.92f, 9.18f);
    add(-2617.34f, -174.83f, 4.34f);
}

Location Biqueiras::GetRandomCloseBiqueira(CVector point)
{
    Location empty;
    if (g_biqueiras.empty()) return empty;

    std::vector<Location> pool;
    int playerCity = ClosestCityToPlayer();

    for (auto& loc : g_biqueiras)
    {
        if (!g_acceptCalloutsOtherCities)
        {
            if (CityOfPos(loc.position) != playerCity)
                continue;
        }
        pool.push_back(loc);
    }
    if (pool.empty())
        pool = g_biqueiras;

    // Se outras cidades = 0: sorteia entre as 3 mais proximas da cidade
    // Se outras cidades = 1: qualquer da lista (nao forca as mais proximas)
    if (!g_acceptCalloutsOtherCities)
    {
        int limit = std::min(3, (int)pool.size());
        std::partial_sort(pool.begin(), pool.begin() + limit, pool.end(),
            [&point](const Location& a, const Location& b) {
                return distanceBetweenPoints(a.position, point) <
                       distanceBetweenPoints(b.position, point);
            });
        int index = getRandomNumber(0, limit - 1);
        return pool[index];
    }

    int index = getRandomNumber(0, (int)pool.size() - 1);
    return pool[index];
}
