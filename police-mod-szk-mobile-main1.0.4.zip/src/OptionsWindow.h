#pragma once

#include "pch.h"

class OptionsWindow {
public:
    static void OpenWindow();
};
