#pragma once

#include "IModPolicia.h"

class ModPolicia : public IModPolicia {
public:
    bool IsRadioOpen() override;
    bool IsMenuOpen() override;
    bool HasDualPatrolUnits() override;
    int GetDualPatrolVehicles(int* outHandles, int* outModels, int maxCount) override;
};

extern IModPolicia* modPolicia;
