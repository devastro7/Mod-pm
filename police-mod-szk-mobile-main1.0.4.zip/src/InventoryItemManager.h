#pragma once

#include "pch.h"
#include "ItemDefinition.h"
#include <unordered_map>
#include <memory>
#include <string>

class InventoryItemManager {
public:
    static std::unordered_map<std::string, std::shared_ptr<ItemDefinition>> itemDefinitions;
    static std::unordered_map<std::string, std::shared_ptr<ItemDefinition>> carItemDefinitions;

    static void Initialize();
    static void LoadItems();
    static void LoadCarItems();
};
