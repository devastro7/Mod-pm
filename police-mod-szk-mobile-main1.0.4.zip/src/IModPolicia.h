#pragma once

// Interface version: 1.6.0
// 1.5.0: IsRadioOpen, IsMenuOpen
// 1.6.0: DualPatrol vehicle handles for giroflex sync (lights only, no siren)

class IModPolicia {
public:
    virtual bool IsRadioOpen() = 0;
    virtual bool IsMenuOpen() = 0;

    // true se existir pelo menos 1 unidade DualPatrol ativa
    virtual bool HasDualPatrolUnits() = 0;

    // Preenche outHandles/outModels com as viaturas de apoio (max maxCount).
    // Retorna quantas foram escritas. 0 se nao houver.
    // Chamado apenas no clique do botao de luz — nao por frame.
    virtual int GetDualPatrolVehicles(int* outHandles, int* outModels, int maxCount) = 0;
};
