#include "NearbyStolenSystem.h"

#include "Vehicles.h"
#include "Vehicle.h"
#include "Peds.h"
#include "Ped.h"
#include "Callouts.h"
#include "DispatchPanel.h"
#include "BottomMessage.h"
#include "Criminals.h"
#include "CleoFunctions.h"
#include "simpleGta.h"
#include "AudioCollection.h"
#include "RadioSounds.h"

// Estado
static bool s_active = false;
static int s_targetCarRef = -1;
static std::string s_announcedPlate;
static float s_tryTimerMs = 0.0f;
static float s_blip3dTimerMs = 0.0f;
static float s_bigCircleRefreshMs = 0.0f;
static bool s_showBigCircle = false;
static CVector s_bigCirclePos = CVector(0, 0, 0);
static bool s_uiBlocking = false;
static float s_uiBlockTimerMs = 0.0f;

extern bool g_onService;
extern bool g_onACallout;
extern void* textureBigCircle;

void NearbyStolenSystem::Initialize()
{
    s_active = false;
    s_targetCarRef = -1;
    s_announcedPlate.clear();
    s_tryTimerMs = 0.0f;
    s_blip3dTimerMs = 0.0f;
    s_bigCircleRefreshMs = 0.0f;
    s_showBigCircle = false;
    s_uiBlocking = false;
    s_uiBlockTimerMs = 0.0f;
}

bool NearbyStolenSystem::IsActive()
{
    return s_active;
}

bool NearbyStolenSystem::IsBlockingOtherCallouts()
{
    // Nao bloqueia mais: permite empilhar ocorrencias + prioridade de audio
    return false;
}

Vehicle* NearbyStolenSystem::GetTargetVehicle()
{
    if (!s_active || s_targetCarRef <= 0) return nullptr;
    auto v = Vehicles::GetVehicle(s_targetCarRef);
    if (!v || !Vehicles::IsValid(v) || !CAR_DEFINED(v->ref))
        return nullptr;
    return v;
}

bool NearbyStolenSystem::IsTargetVehicle(Vehicle* v)
{
    if (!v || !s_active) return false;
    return v->ref == s_targetCarRef;
}

bool NearbyStolenSystem::IsTargetVehicleRef(int carRef)
{
    return s_active && carRef > 0 && carRef == s_targetCarRef;
}

float NearbyStolenSystem::GetFleeMultiplierForVehicle(Vehicle* v)
{
    if (IsTargetVehicle(v)) return 2.0f;
    return 1.0f;
}

void NearbyStolenSystem::ClearActive(bool fromAbort)
{
    auto v = GetTargetVehicle();
    if (v)
    {
        v->flags.isNearbyStolenTarget = false;
        // nao zera isStolen do doc (pode ser legitimo); so tira o blip de alvo se ainda nosso
        if (v->flags.showBlip)
            v->HideBlip();
    }

    s_active = false;
    s_targetCarRef = -1;
    s_announcedPlate.clear();
    s_blip3dTimerMs = 0.0f;
    s_bigCircleRefreshMs = 0.0f;
    s_showBigCircle = false;
    s_uiBlocking = false;
    s_uiBlockTimerMs = 0.0f;

    if (fromAbort)
        BottomMessage::SetMessage("~y~Busca por veiculo roubado encerrada", 2500);
}

static bool IsPlayerOwnedVehicle(Vehicle* v)
{
    if (!v || !CAR_DEFINED(v->ref)) return true;
    // Dentro do carro agora
    if (v->IsPlayerInside()) return true;
    // Ultima viatura que o player usou
    if (g_lastPlayerVehicle > 0 && v->ref == g_lastPlayerVehicle) return true;
    // Carro que o player esta usando (redundante mas seguro)
    int player = GetPlayerActor();
    if (ACTOR_DEFINED(player) && IS_CHAR_IN_ANY_CAR(player))
    {
        int pc = GetVehiclePedIsUsing(player);
        if (pc > 0 && v->ref == pc) return true;
    }
    return false;
}

static Vehicle* PickNearbyCandidate()
{
    if (!g_playerPosition) return nullptr;

    // Veiculos ja registrados perto do player
    auto list = Vehicles::GetAllCarsInSphere(*g_playerPosition, 120.0f);
    std::vector<Vehicle*> candidates;
    for (auto v : list)
    {
        if (!v || !Vehicles::IsValid(v) || !CAR_DEFINED(v->ref)) continue;
        if (IsPlayerOwnedVehicle(v)) continue; // nunca o carro do jogador
        if (!v->HasDriver()) continue;
        // Evita viaturas policiais do mod
        if (v->policeVehicleData != nullptr) continue;
        if (v->flags.isNearbyStolenTarget) continue;
        candidates.push_back(v);
    }

    if (candidates.empty()) return nullptr;
    int idx = getRandomNumber(0, (int)candidates.size() - 1);
    return candidates[idx];
}

static void ActivateOnVehicle(Vehicle* v)
{
    if (!v) return;

    s_active = true;
    s_targetCarRef = v->ref;

    // Placa anunciada = placa atual do veiculo (bate na consulta)
    s_announcedPlate = v->currentDoc.plate;
    v->originalDoc.isStolen = true;
    v->currentDoc.isStolen = true;
    v->flags.isNearbyStolenTarget = true;

    // Chance de fuga 2x + arma (weapon_chance)
    auto occupants = v->GetCurrentOccupants();
    for (int pedRef : occupants)
    {
        auto ped = Peds::GetPed(pedRef);
        if (!ped) continue;
        float baseFlee = CHANCE_RUNNING_AWAY_WHEN_VEHICLE_IRREGULAR;
        if (baseFlee < 0.0f) baseFlee = 0.0f;
        if (baseFlee > 1.0f) baseFlee = 1.0f;
        float fleeChance = baseFlee * 2.0f;
        if (fleeChance > 1.0f) fleeChance = 1.0f;
        bool willSurrender = !calculateProbability(fleeChance);
        ped->flags.willSurrender = willSurrender;
        if (!willSurrender)
            ped->flags.willKillCops = calculateProbability(CHANCE_CRIMINAL_KILL_COPS * 0.5f);
    }

    // Arma no motorista (chance configuravel, padrao 0.5)
    if (v->HasDriver() && calculateProbability((float)STOLEN_NEARBY_WEAPON_CHANCE))
    {
        int driverRef = v->GetCurrentDriver();
        if (driverRef > 0 && ACTOR_DEFINED(driverRef))
        {
            GIVE_ACTOR_WEAPON(driverRef, 22, 50); // pistola
            SET_CURRENT_ACTOR_WEAPON(driverRef, 22);
        }
    }

    // Blip no radar: se big circle OFF e show_blip_3d ON -> blip pequeno normal
    // Se big circle ON -> usa o circulo grande (atualiza pos a cada 10s)
    if (STOLEN_NEARBY_SHOW_BIG_CIRCLE == 1)
    {
        s_showBigCircle = true;
        s_bigCirclePos = v->GetPosition();
        s_bigCircleRefreshMs = 10000.0f;
        // Tambem marca blip 3d se pedido
        if (STOLEN_NEARBY_SHOW_BLIP_3D == 1)
            v->ShowBlip(COLOR_CRIMINAL);
    }
    else if (STOLEN_NEARBY_SHOW_BLIP_3D == 1)
    {
        v->ShowBlip(COLOR_CRIMINAL);
        if (STOLEN_NEARBY_BLIP_3D_SECONDS > 0)
            s_blip3dTimerMs = (float)STOLEN_NEARBY_BLIP_3D_SECONDS * 1000.0f;
        else
            s_blip3dTimerMs = 0.0f;
    }

    std::string callType = "Denuncias relatam que ha um veiculo roubado na sua regiao";
    std::string location = std::string("Placa: ") + s_announcedPlate;
    std::string instruction = "Encontre o veiculo suspeito";
    int duration = CALLOUT_UI_DURATION_MS;

    // Sempre sobrescreve a tabela com a de carro roubado
    if (CALLOUT_UI_STYLE == 0 || CALLOUT_UI_STYLE == 2)
        BottomMessage::SetMessage(std::string("~b~[COPOM] ~w~") + callType, duration);
    if (CALLOUT_UI_STYLE == 1 || CALLOUT_UI_STYLE == 2)
        DispatchPanel::Show(callType, location, instruction, duration);

    // Voz do callout de carro roubado (se existir no audio pack)
    if (audioCalloutStolenCar)
    {
        auto audio = audioCalloutStolenCar->GetRandomAudio();
        if (audio)
            RadioSounds::PlayAudioNowDontAttach(audio);
    }

    s_uiBlocking = true;
    s_uiBlockTimerMs = (float)duration;
}

void NearbyStolenSystem::Update()
{
    float dt = menuSZK ? (float)menuSZK->deltaTime : 50.0f;

    // Big circle: desenha e a cada 10s reposiciona na posicao atual do veiculo
    if (s_showBigCircle && STOLEN_NEARBY_SHOW_BIG_CIRCLE == 1 && textureBigCircle != nullptr)
    {
        auto color = COLOR_CRIMINAL;
        menuSZK->DrawTextureOnRadar(textureBigCircle, s_bigCirclePos, color, 150.0f);
        s_bigCircleRefreshMs -= dt;
        if (s_bigCircleRefreshMs <= 0.0f)
        {
            s_bigCircleRefreshMs = 10000.0f;
            auto tv = GetTargetVehicle();
            if (tv)
                s_bigCirclePos = tv->GetPosition();
        }
    }

    // Timer da UI bloqueando outras ocorrencias
    if (s_uiBlocking)
    {
        s_uiBlockTimerMs -= dt;
        if (s_uiBlockTimerMs <= 0.0f)
            s_uiBlocking = false;
    }

    // Alvo ativo: validar se ainda existe / distancia
    if (s_active)
    {
        auto v = GetTargetVehicle();
        if (!v)
        {
            // Carro despawnou / sumiu
            ClearActive(false);
            return;
        }

        // Se afastar > 350m do player: limpa estado e destroi o veiculo com seguranca
        // (para de "carregar" o alvo; nao fica preso pra sempre)
        if (g_playerPosition)
        {
            float dist = (float)distanceBetweenPoints(v->GetPosition(), *g_playerPosition);
            if (dist > 350.0f)
            {
                int carRef = v->ref;
                // Ocupantes: remove blip e agenda destroy seguro
                auto occupants = v->GetCurrentOccupants();
                for (int pedRef : occupants)
                {
                    auto ped = Peds::GetPed(pedRef);
                    if (!ped) continue;
                    ped->HideBlip();
                    if (Criminals::IsCriminal(ped))
                        Criminals::RemoveCriminal(ped);
                    ped->QueueDestroy();
                }
                v->flags.isNearbyStolenTarget = false;
                v->HideBlip();
                v->QueueDestroy(false); // destroi carro de forma segura (fila do mod)
                ClearActive(false);
                return;
            }
        }

        // Timer do blip 3D
        if (STOLEN_NEARBY_SHOW_BLIP_3D == 1 && STOLEN_NEARBY_BLIP_3D_SECONDS > 0)
        {
            if (s_blip3dTimerMs > 0.0f)
            {
                s_blip3dTimerMs -= dt;
                if (s_blip3dTimerMs <= 0.0f)
                    v->HideBlip();
            }
        }

        // Enquanto ativo, NAO tenta escolher outro carro (sem spam)
        return;
    }

    // Pode aparecer perto / em perseguicao, inclusive com outra ocorrencia na tabela
    if (STOLEN_NEARBY_ENABLED != 1) return;
    if (!g_onService) return;

    int intervalSec = STOLEN_NEARBY_INTERVAL_SECONDS;
    if (intervalSec < 5) intervalSec = 5;
    s_tryTimerMs += dt;
    if (s_tryTimerMs < (float)intervalSec * 1000.0f)
        return;
    s_tryTimerMs = 0.0f;

    // 1) Perseguicao: carro a frente perto do player (< 40m)
    if (g_playerPosition && IS_CHAR_IN_ANY_CAR(GetPlayerActor()))
    {
        int playerCar = GetVehiclePedIsUsing(GetPlayerActor());
        if (playerCar > 0 && CAR_DEFINED(playerCar))
        {
            float px = 0, py = 0, pz = 0;
            STORE_COORDS_FROM_ACTOR_WITH_OFFSET(GetPlayerActor(), 0.0f, 18.0f, 0.0f, &px, &py, &pz);
            auto ahead = Vehicles::GetAllCarsInSphere(CVector(px, py, pz), 25.0f);
            Vehicle* chaseCand = nullptr;
            float best = 9999.0f;
            for (auto v : ahead)
            {
                if (!v || !Vehicles::IsValid(v) || !CAR_DEFINED(v->ref)) continue;
                if (IsPlayerOwnedVehicle(v)) continue; // nunca o carro do jogador
                if (!v->HasDriver()) continue;
                if (v->policeVehicleData != nullptr) continue;
                if (v->flags.isNearbyStolenTarget) continue;
                float d = (float)distanceBetweenPoints(v->GetPosition(), *g_playerPosition);
                if (d < best && d < 40.0f)
                {
                    best = d;
                    chaseCand = v;
                }
            }
            // Em perseguicao: chance maior (70%) de marcar como roubado
            if (chaseCand && calculateProbability(0.70f))
            {
                ActivateOnVehicle(chaseCand);
                return;
            }
        }
    }

    // 2) Chance normal: veiculo qualquer na regiao
    float chance = (float)STOLEN_NEARBY_CHANCE;
    if (chance < 0.0f) chance = 0.0f;
    if (chance > 1.0f) chance = 1.0f;
    if (!calculateProbability(chance))
        return;

    auto candidate = PickNearbyCandidate();
    if (!candidate)
        return;

    ActivateOnVehicle(candidate);
}
