#pragma once

#include "pch.h"

// Sistema ambiente: marca um veiculo JA existente no trafego como "roubado na regiao"
// (nao spawna carro novo). Controlado por [stolen_nearby] no settings.ini
class NearbyStolenSystem {
public:
    static void Initialize();
    static void Update();
    static void ClearActive(bool fromAbort = false);

    // true enquanto a denuncia estiver ativa (bloqueia outras ocorrencias do tipo / gerais)
    static bool IsActive();
    static bool IsBlockingOtherCallouts();

    // Veiculo alvo atual (ou nullptr)
    static class Vehicle* GetTargetVehicle();
    static bool IsTargetVehicle(class Vehicle* v);
    static bool IsTargetVehicleRef(int carRef);

    // Chance de fuga 2x para o alvo
    static float GetFleeMultiplierForVehicle(class Vehicle* v);
};
