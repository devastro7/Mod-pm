#pragma once

#include "pch.h"
#include <vector>
#include <string>
#include <functional>

// Painel lateral generico (revista, RG, CNH, consulta veiculo, bafometro...)
// Posicao/tamanho/animacao = mesmos do Dispatch (CALLOUT_UI_*)
// Suporta ate 3 paineis simultaneos empilhados (sobe o mais antigo).
class FriskPanel {
public:
    static void Initialize();
    static void Update();
    static void ApplyLayout();

    // API generica
    // title = titulo principal (ex: "REVISTA", "RG", "CNH")
    // badge = texto curto no badge (ex: "REV", "RG", "CNH")
    // subtitle = linha secundaria
    // items = linhas de conteudo (podem comecar com ~r~ para vermelho)
    static void Show(const std::string& title,
                     const std::string& badge,
                     const std::string& subtitle,
                     const std::vector<std::string>& items,
                     int durationMs = 0);

    // Atalho antigo (revista)
    static void Show(const std::vector<std::string>& items, const std::string& subtitle, int durationMs = 0);

    static void Hide();
    static bool IsVisible();
    static void SetOnClosed(std::function<void()> cb);

    // Helpers de estilo (FRISK_UI_STYLE: 0 menu, 1 painel, 2 ambos)
    static bool UsePanel();
    static bool UseClassic();
};
