#include "TrafficControl.h"

#include "CleoFunctions.h"
#include "Peds.h"
#include "Vehicles.h"
#include "Partners.h"
#include "Criminals.h"
#include "BackupUnits.h"
#include "DualPatrol.h"
#include "Chase.h"

#include <set>

static bool s_enabled = false;
static bool s_densityApplied = false;
static int s_accumMs = 0;
static std::set<int> s_frozenPedRefs;
static std::set<int> s_frozenCarRefs;

static const float FREEZE_RADIUS = 120.0f;
static const int FREEZE_INTERVAL_MS = 400;

// Animacao de parado (idle) — evita "andar parado"
static void ApplyStandIdleAnim(int pedRef)
{
    if (!ACTOR_DEFINED(pedRef)) return;
    CLEAR_ACTOR_TASK(pedRef);
    // PED idle em loop: fica parado de pe, sem walk cycle
    PERFORM_ANIMATION_AS_ACTOR(pedRef, "IDLE_chat", "PED", 4.0f, 1, 0, 0, 0, -1);
}

static bool IsPartnerPed(Ped* ped)
{
    if (!ped) return false;
    for (auto* p : Partners::GetPartners())
        if (p == ped) return true;
    return false;
}

static bool IsProtectedPed(Ped* ped)
{
    if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
        return true;
    if (ped->ref == GetPlayerActor()) return true;
    if (IsPartnerPed(ped)) return true;
    if (ped->flags.showBlip) return true;
    if (ped->flags.hasSurrended) return true;
    if (ped->flags.isFleeing) return true;
    if (ped->flags.isHandcuffed) return true;
    if (Criminals::IsCriminal(ped)) return true;
    return false;
}

static bool IsProtectedVehicle(Vehicle* veh)
{
    if (!veh || !Vehicles::IsValid(veh) || !CAR_DEFINED(veh->ref))
        return true;
    if (veh->ref == g_lastPlayerVehicle) return true;
    if (veh->IsPlayerInside()) return true;
    if (veh->flags.showWidget) return true;
    if (veh->flags.showBlip) return true;
    for (auto* v : BackupUnits::backupVehicles)
        if (v == veh) return true;
    for (auto* v : DualPatrol::escortVehicles)
        if (v == veh) return true;
    if (Chase::IsVehicleRunningFromCops(veh)) return true;
    if (veh->HasDriver())
    {
        auto* driver = Peds::GetPed(veh->GetCurrentDriver());
        if (driver && IsProtectedPed(driver)) return true;
    }
    return false;
}

static void ApplyDensityStopSpawn()
{
    SET_PED_DENSITY_MULTIPLIER(0.0f);
    SET_CAR_DENSITY_MULTIPLIER(0.0f);
    s_densityApplied = true;
}

static void RestoreDensity()
{
    SET_PED_DENSITY_MULTIPLIER(1.0f);
    SET_CAR_DENSITY_MULTIPLIER(1.0f);
    s_densityApplied = false;
}

static void FreezeNearby()
{
    auto playerPos = GetPlayerPosition();
    int playerActor = GetPlayerActor();

    for (auto& pair : Peds::GetPedsMap())
    {
        Ped* ped = pair.second;
        if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref)) continue;
        if (ped->ref == playerActor) continue;
        if (IsProtectedPed(ped))
        {
            FREEZE_CHAR_POSITION(ped->ref, false);
            continue;
        }
        // Nao trava quem esta dentro de carro (motorista fica com o veiculo)
        if (IS_CHAR_IN_ANY_CAR(ped->ref))
            continue;

        auto pos = ped->GetPosition();
        if (distanceBetweenPoints(pos, playerPos) > FREEZE_RADIUS) continue;

        // Idle so uma vez (evita reiniciar anim e tremer)
        if (s_frozenPedRefs.find(ped->ref) == s_frozenPedRefs.end())
        {
            ApplyStandIdleAnim(ped->ref);
            s_frozenPedRefs.insert(ped->ref);
        }
        FREEZE_CHAR_POSITION(ped->ref, true);
    }

    for (auto& pair : Vehicles::GetVehiclesMap())
    {
        Vehicle* veh = pair.second;
        if (!veh || !Vehicles::IsValid(veh) || !CAR_DEFINED(veh->ref)) continue;
        if (IsProtectedVehicle(veh))
        {
            FREEZE_CAR_POSITION(veh->ref, false);
            continue;
        }

        auto pos = veh->GetPosition();
        if (distanceBetweenPoints(pos, playerPos) > FREEZE_RADIUS) continue;

        SET_CAR_MAX_SPEED(veh->ref, 0.0f);
        CAR_TURN_OFF_ENGINE(veh->ref);
        FREEZE_CAR_POSITION(veh->ref, true);
        s_frozenCarRefs.insert(veh->ref);
    }
}

static void UnfreezeAllKnown()
{
    for (auto& pair : Peds::GetPedsMap())
    {
        Ped* ped = pair.second;
        if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref)) continue;
        if (ped->ref == GetPlayerActor()) continue;

        FREEZE_CHAR_POSITION(ped->ref, false);
        if (s_frozenPedRefs.count(ped->ref))
            CLEAR_ACTOR_TASK(ped->ref);
    }
    s_frozenPedRefs.clear();

    for (auto& pair : Vehicles::GetVehiclesMap())
    {
        Vehicle* veh = pair.second;
        if (!veh || !Vehicles::IsValid(veh) || !CAR_DEFINED(veh->ref)) continue;

        FREEZE_CAR_POSITION(veh->ref, false);

        // Carros que o trafego tinha parado: restaura motor + AI de trânsito de forma mais agressiva
        if (s_frozenCarRefs.count(veh->ref) && !IsProtectedVehicle(veh))
        {
            // Libera ocupantes (podem ter ficado sem task / congelados)
            for (int pedRef : veh->GetCurrentOccupants())
            {
                if (!ACTOR_DEFINED(pedRef)) continue;
                if (pedRef == GetPlayerActor()) continue;
                FREEZE_CHAR_POSITION(pedRef, false);
                CLEAR_ACTOR_TASK(pedRef);
            }

            // Liga o motor de novo
            SET_CAR_ENGINE_OPERATION(veh->ref, true);

            // Velocidade e comportamento de trânsito normais (evita ficar “travado” no mobile)
            SET_CAR_MAX_SPEED(veh->ref, 50.0f);
            SET_CAR_TRAFFIC_BEHAVIOUR(veh->ref, DrivingMode::AvoidCars);

            // Volta AI de motorista civil (nao psycho / nao fuga)
            SET_CAR_TO_NORMAL_DRIVER(veh->ref);

            // Garante que o motorista não está congelado e sem task
            int driver = veh->GetCurrentDriver();
            if (driver > 0 && ACTOR_DEFINED(driver) && driver != GetPlayerActor())
            {
                FREEZE_CHAR_POSITION(driver, false);
                CLEAR_ACTOR_TASK(driver);
            }
        }
        else
        {
            // Mesmo carros não listados: garante unfreeze de posição
            FREEZE_CAR_POSITION(veh->ref, false);
        }
    }
    s_frozenCarRefs.clear();
}

void TrafficControl::SetEnabled(bool enabled)
{
    if (s_enabled == enabled) return;
    s_enabled = enabled;
    if (enabled)
    {
        ApplyDensityStopSpawn();
        FreezeNearby();
    }
    else
    {
        RestoreDensity();
        UnfreezeAllKnown();
    }
}

bool TrafficControl::IsEnabled()
{
    return s_enabled;
}

void TrafficControl::Update()
{
    if (!s_enabled)
        return;
    if (!s_densityApplied)
        ApplyDensityStopSpawn();
    s_accumMs += (int)menuSZK->deltaTime;
    if (s_accumMs < FREEZE_INTERVAL_MS)
        return;
    s_accumMs = 0;
    FreezeNearby();
}
