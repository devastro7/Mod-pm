#include "RadioConfigWindow.h"

#include "BottomMessage.h"
#include "ModData.h"
#include "RadioSounds.h"

void RadioConfigWindow::OpenWindow()
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Configuracoes do Radio");

    // 1) Som ao aceitar ocorrencia
    {
        auto options = window->AddOptions("Som ao aceitar ocorrencia");
        options->AddOption("Nao", 0);
        options->AddOption("Sim", 1);
        options->SetOptionIndex(RADIO_PLAY_ACCEPT_CALLOUT_SOUND ? 1 : 0);
        options->onOptionChange->Add([options]() {
            RADIO_PLAY_ACCEPT_CALLOUT_SOUND = (options->GetCurrentOptionValue() == 1);
            modData->SaveSettings();
        });
    }

    // 2) Volume do som de chamados
    {
        auto options = window->AddOptions("Volume do som de chamados");
        int selectedIdx = 0;
        int i = 0;
        for (int v = 30; v <= 500; v += 10)
        {
            options->AddOption(std::to_string(v), v);
            if (v == RADIO_CALLOUT_VOLUME) selectedIdx = i;
            i++;
        }
        options->SetOptionIndex(selectedIdx);
        options->onOptionChange->Add([options]() {
            RADIO_CALLOUT_VOLUME = options->GetCurrentOptionValue();
            modData->SaveSettings();
        });
    }

    // 3) Distancia do som de chamados
    {
        auto options = window->AddOptions("Distancia do som de chamados");
        int selectedIdx = 0;
        int i = 0;
        for (int v = 30; v <= 500; v += 10)
        {
            options->AddOption(std::to_string(v), v);
            if (v == RADIO_CALLOUT_DISTANCE) selectedIdx = i;
            i++;
        }
        options->SetOptionIndex(selectedIdx);
        options->onOptionChange->Add([options]() {
            RADIO_CALLOUT_DISTANCE = options->GetCurrentOptionValue();
            modData->SaveSettings();
        });
    }

    // 4) Radio de viaturas on/off
    {
        auto options = window->AddOptions("Radio de viaturas");
        options->AddOption("Off", 0);
        options->AddOption("On", 1);
        options->SetOptionIndex(RADIO_VEHICLE_RADIO_ENABLED ? 1 : 0);
        options->onOptionChange->Add([options]() {
            RADIO_VEHICLE_RADIO_ENABLED = (options->GetCurrentOptionValue() == 1);
            modData->SaveSettings();
            if (!RADIO_VEHICLE_RADIO_ENABLED)
                RadioSounds::StopCurrent();
        });
    }

    // 5) Som do radio (setas esquerda/direita)
    {
        auto options = window->AddOptions("Som do radio");
        int count = RadioSounds::GetAudioCount();
        if (count <= 0)
        {
            options->AddOption("Nenhum", 0);
            options->SetOptionIndex(0);
        }
        else
        {
            if (RADIO_SOUND_INDEX < 0) RADIO_SOUND_INDEX = 0;
            if (RADIO_SOUND_INDEX >= count) RADIO_SOUND_INDEX = count - 1;

            for (int i = 0; i < count; i++)
                options->AddOption(std::to_string(i + 1), i);

            options->SetOptionIndex(RADIO_SOUND_INDEX);
            options->onOptionChange->Add([options]() {
                RADIO_SOUND_INDEX = options->GetCurrentOptionValue();
                modData->SaveSettings();
                RadioSounds::PlaySelectedIndex();
            });
        }
    }

    // 6) Volume do radio
    {
        auto options = window->AddOptions("Volume do radio");
        int selectedIdx = 0;
        int i = 0;
        for (int v = 30; v <= 500; v += 10)
        {
            options->AddOption(std::to_string(v), v);
            if (v == RADIO_SOUND_VOLUME) selectedIdx = i;
            i++;
        }
        options->SetOptionIndex(selectedIdx);
        options->onOptionChange->Add([options]() {
            RADIO_SOUND_VOLUME = options->GetCurrentOptionValue();
            modData->SaveSettings();
            RadioSounds::ApplyCurrentVolume();
        });
    }

    // 7) Distancia do radio
    {
        auto options = window->AddOptions("Distancia do radio");
        int selectedIdx = 0;
        int i = 0;
        for (int v = 30; v <= 500; v += 10)
        {
            options->AddOption(std::to_string(v), v);
            if (v == RADIO_SOUND_DISTANCE) selectedIdx = i;
            i++;
        }
        options->SetOptionIndex(selectedIdx);
        options->onOptionChange->Add([options]() {
            RADIO_SOUND_DISTANCE = options->GetCurrentOptionValue();
            modData->SaveSettings();
        });
    }

    {
        auto button = window->AddButton("~y~Fechar");
        button->onClick->Add([window]() {
            window->Close();
        });
    }
}
