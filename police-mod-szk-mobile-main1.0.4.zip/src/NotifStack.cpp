#include "NotifStack.h"
#include "pch.h"

static bool s_active[NotifStack::SLOT_COUNT] = {};
static float s_height[NotifStack::SLOT_COUNT] = {};

void NotifStack::SetActive(int slot, bool active, float height)
{
    if (slot < 0 || slot >= SLOT_COUNT) return;
    s_active[slot] = active;
    if (height > 40.0f)
        s_height[slot] = height;
}

float NotifStack::GetGap()
{
    int g = FRISK_UI_POPUP_GAP;
    if (g < 0) g = 0;
    if (g > 50) g = 50;
    return (float)g;
}

float NotifStack::GetOffsetY(int slot)
{
    if (slot < 0 || slot >= SLOT_COUNT || !s_active[slot])
        return 0.0f;

    // Empilha com VerticalAlign::Top (Y cresce pra baixo):
    // - extras: EXTRA_BASE = mais novo = base (embaixo)
    // - dispatch sempre no topo da pilha
    //
    // Gap borda-a-borda (respeita FRISK_UI_POPUP_GAP):
    //   offset[0] = 0
    //   offset[k] = -sum_{i=1..k} (H[i] + gap)   (inclui a propria altura)

    // Monta ordem de baixo pra cima
    int order[SLOT_COUNT];
    int n = 0;

    // extras do mais novo (base) ao mais antigo
    for (int i = SLOT_EXTRA_BASE; i < SLOT_COUNT; ++i)
    {
        if (s_active[i])
            order[n++] = i;
    }
    // dispatch no topo
    if (s_active[SLOT_DISPATCH])
        order[n++] = SLOT_DISPATCH;

    if (n == 0) return 0.0f;

    float gap = GetGap();
    float offset = 0.0f;
    for (int i = 0; i < n; ++i)
    {
        if (i > 0)
            offset -= (s_height[order[i]] + gap);

        if (order[i] == slot)
            return offset;
    }
    return 0.0f;
}
