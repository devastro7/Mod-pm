#include "TicketWindow.h"

#include "ModData.h"
#include "IniReaderWriter.hpp"
#include "BottomMessage.h"
#include "CleoFunctions.h"
#include "Vehicles.h"
#include "Pullover.h"
#include "Logger.h"

#include <filesystem>
#include <algorithm>

std::vector<FineData> TicketWindow::m_FineDatas;
std::vector<RolledFine> TicketWindow::m_RolledFines;
bool TicketWindow::m_FinesLoaded = false;
Vehicle* TicketWindow::m_Vehicle = nullptr;
std::map<int, VehicleFineHistory> TicketWindow::m_HistoryByVehicle;

static std::string GetMultasFolder()
{
    // com.rockstargames.gtasa/mods/mods_data/policeModSZK/data/multas/
    return modData->GetFile("data/multas");
}

void TicketWindow::EnsureFinesFolderAndDefaults()
{
    ModData::CreateFolder(modData->GetFile("data"));
    std::string path = GetMultasFolder();
    ModData::CreateFolder(path);

    if (!std::filesystem::exists(path))
    {
        fileLog->Log("TicketWindow: nao foi possivel criar pasta multas: " + path);
        return;
    }

    // Se ja existir qualquer .ini, nao cria os defaults
    bool hasIni = false;
    try
    {
        for (const auto& entry : std::filesystem::directory_iterator(path))
        {
            if (entry.is_regular_file() && entry.path().extension() == ".ini")
            {
                hasIni = true;
                break;
            }
        }
    }
    catch (...)
    {
        return;
    }

    if (hasIni) return;

    struct DefaultFine {
        const char* file;
        const char* name;
        float chance;
    };

    // So 3 defaults (limite do sistema)
    DefaultFine defaults[] = {
        { "Pneu careca.ini", "Pneu careca", 0.10f },
        { "Farol quebrado.ini", "Farol quebrado", 0.15f },
        { "Sem cinto.ini", "Sem cinto", 0.20f },
    };

    for (const auto& d : defaults)
    {
        std::string filePath = path + "/" + d.file;

        IniReaderWriter ini;
        ini.Set("Multa", "name", d.name);
        ini.SetDouble("Multa", "chance", d.chance);
        ini.SaveToFile(filePath);

        fileLog->Log("TicketWindow: criado default " + filePath);
    }
}

void TicketWindow::LoadFines()
{
    if (m_FinesLoaded) return;
    m_FinesLoaded = true;
    m_FineDatas.clear();

    EnsureFinesFolderAndDefaults();

    std::string path = GetMultasFolder();
    if (!std::filesystem::exists(path))
    {
        fileLog->Log("TicketWindow: pasta multas nao existe: " + path);
        return;
    }

    std::vector<std::filesystem::path> files;
    try
    {
        for (const auto& entry : std::filesystem::directory_iterator(path))
        {
            if (!entry.is_regular_file()) continue;
            if (entry.path().extension() != ".ini") continue;
            files.push_back(entry.path());
        }
    }
    catch (const std::exception& e)
    {
        fileLog->Log(std::string("TicketWindow: erro listando multas: ") + e.what());
        return;
    }

    std::sort(files.begin(), files.end());

    int count = 0;
    for (const auto& filePath : files)
    {
        if (count >= MAX_FINES) break;

        FineData fine;
        fine.id = filePath.filename().string();
        fine.name = filePath.stem().string();
        fine.chance = 0.10f;

        IniReaderWriter ini;
        if (ini.LoadFromFile(filePath.string()))
        {
            std::string n = ini.Get("Multa", "name", "");
            if (!n.empty()) fine.name = n;

            double chance = ini.GetDouble("Multa", "chance", fine.chance);
            fine.chance = (float)chance;
            if (fine.chance < 0.0f) fine.chance = 0.0f;
            if (fine.chance > 1.0f) fine.chance = 1.0f;
        }
        else
        {
            fileLog->Log("TicketWindow: erro lendo " + filePath.string());
        }

        m_FineDatas.push_back(fine);
        count++;
        fileLog->Log("TicketWindow: loaded " + fine.id + " chance=" + std::to_string(fine.chance));
    }

    fileLog->Log("TicketWindow: " + std::to_string(m_FineDatas.size()) + " multas carregadas (max " + std::to_string(MAX_FINES) + ")");
}

void TicketWindow::ClearVehicleHistory(int vehicleRef)
{
    auto it = m_HistoryByVehicle.find(vehicleRef);
    if (it != m_HistoryByVehicle.end())
    {
        m_HistoryByVehicle.erase(it);
        fileLog->Log("TicketWindow: historico limpo do veiculo " + std::to_string(vehicleRef));
    }
}

void TicketWindow::Open(Vehicle* vehicle)
{
    if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        return;

    LoadFines();

    m_Vehicle = vehicle;
    int hVeh = vehicle->ref;
    VehicleFineHistory& hist = m_HistoryByVehicle[hVeh];

    // Rola a chance UMA vez por veiculo; nas proximas aberturas reusa o resultado
    if (!hist.hasRolled)
    {
        hist.rolledIndices.clear();
        for (int i = 0; i < (int)m_FineDatas.size(); i++)
        {
            if (calculateProbability(m_FineDatas[i].chance))
                hist.rolledIndices.push_back(i);
        }
        hist.hasRolled = true;
    }

    // So mostra as que cairam E ainda nao foram aplicadas
    m_RolledFines.clear();
    for (int idx : hist.rolledIndices)
    {
        if (idx < 0 || idx >= (int)m_FineDatas.size()) continue;
        if (hist.appliedIds.count(m_FineDatas[idx].id) > 0) continue;

        RolledFine rolled;
        rolled.fineIndex = idx;
        rolled.selected = false;
        m_RolledFines.push_back(rolled);
    }

    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Aplicar multa");

    if (m_RolledFines.empty())
    {
        window->AddText("Nenhuma irregularidade encontrada");
    }
    else
    {
        window->AddText("Irregularidades encontradas:");

        for (size_t i = 0; i < m_RolledFines.size(); i++)
        {
            int idx = m_RolledFines[i].fineIndex;
            if (idx < 0 || idx >= (int)m_FineDatas.size()) continue;

            window->AddCheckbox(m_FineDatas[idx].name, &m_RolledFines[i].selected);
        }
    }

    {
        auto button = window->AddButton("Aplicar a multa");
        button->onClick->Add([window]() {
            window->Close();
            ApplySelectedFines();
        });
    }

    {
        auto button = window->AddButton("~y~Voltar");
        button->onClick->Add([window, vehicle]() {
            window->Close();
            m_Vehicle = nullptr;

            if (Vehicles::IsValid(vehicle))
                Pullover::OpenVehicleMenu(vehicle);
        });
    }
}

void TicketWindow::ApplySelectedFines()
{
    int count = 0;
    int hVeh = 0;
    if (m_Vehicle) hVeh = m_Vehicle->ref;

    auto histIt = m_HistoryByVehicle.find(hVeh);
    for (auto& rolled : m_RolledFines)
    {
        if (!rolled.selected) continue;
        if (rolled.fineIndex < 0 || rolled.fineIndex >= (int)m_FineDatas.size()) continue;

        if (histIt != m_HistoryByVehicle.end())
            histIt->second.appliedIds.insert(m_FineDatas[rolled.fineIndex].id);

        count++;
        fileLog->Log("Multa aplicada: " + m_FineDatas[rolled.fineIndex].name);
    }

    if (count == 0)
    {
        BottomMessage::SetMessage("~y~Nenhuma multa selecionada", 2500);
    }
    else
    {
        BottomMessage::SetMessage("~r~Multa aplicada (" + std::to_string(count) + ")", 3000);
    }

    m_Vehicle = nullptr;
}
