#include "Conversas.h"

#include "ModData.h"
#include "BottomMessage.h"
#include "CleoFunctions.h"
#include "Logger.h"
#include "Pullover.h"
#include "Peds.h"

#include <filesystem>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <cstdlib>

std::vector<Conversation> Conversas::s_conversations;
bool Conversas::s_loaded = false;

static void TrimInPlace(std::string& s)
{
    auto notSpace = [](unsigned char c) { return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notSpace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notSpace).base(), s.end());
}

static bool StartsWithIgnoreCase(const std::string& s, const std::string& prefix)
{
    if (s.size() < prefix.size()) return false;
    for (size_t i = 0; i < prefix.size(); ++i)
    {
        if (std::tolower((unsigned char)s[i]) != std::tolower((unsigned char)prefix[i]))
            return false;
    }
    return true;
}

std::string Conversas::GetConversasFolder()
{
    // mods/mods_data/policeModSZK/data/conversas/
    return modData->GetFile("data/conversas");
}

void Conversas::EnsureFolderAndDefaults()
{
    ModData::CreateFolder(modData->GetFile("data"));
    std::string path = GetConversasFolder();
    ModData::CreateFolder(path);

    if (!std::filesystem::exists(path))
    {
        fileLog->Log("Conversas: nao foi possivel criar pasta: " + path);
        return;
    }

    // Se ja existir qualquer .ini, nao cria defaults
    bool hasIni = false;
    try
    {
        for (const auto& entry : std::filesystem::directory_iterator(path))
        {
            if (entry.is_regular_file() && entry.path().extension() == ".ini")
            {
                hasIni = true;
                break;
            }
        }
    }
    catch (...)
    {
        return;
    }

    if (hasIni) return;

    // Default example: Estavaindoonde.ini
    std::string defaultPath = path + "/Estavaindoonde.ini";
    std::ofstream f(defaultPath);
    if (f.is_open())
    {
        f << "name = \"Perguntar para onde esta indo\"\n";
        f << "\n";
        f << "----\n";
        f << "P = Estava indo onde? 5\n";
        f << "P = Ta indo para onde? 5\n";
        f << "P = Vai onde? 3\n";
        f << "\n";
        f << "----\n";
        f << "R = To indo pra casa senhor 5\n";
        f << "R = Estava indo para o trabalho 5\n";
        f << "R = Estava viajando 4\n";
        f.close();
        fileLog->Log("Conversas: criado default " + defaultPath);
    }
}

bool Conversas::ParseConversationFile(const std::string& path, Conversation& out)
{
    std::ifstream file(path);
    if (!file.is_open())
        return false;

    out = Conversation();
    out.filePath = path;

    // name default = filename without .ini
    auto fname = std::filesystem::path(path).stem().string();
    out.name = fname;

    std::string line;
    while (std::getline(file, line))
    {
        // remove BOM / trim
        if (!line.empty() && (unsigned char)line[0] == 0xEF) // skip utf8 bom roughly
            continue;

        TrimInPlace(line);
        if (line.empty()) continue;
        if (line[0] == '#' || line[0] == ';') continue;

        // separators like ---- or ----(separa)
        if (line.find("---") == 0)
            continue;

        // name = "..."
        if (StartsWithIgnoreCase(line, "name"))
        {
            auto eq = line.find('=');
            if (eq != std::string::npos)
            {
                std::string val = line.substr(eq + 1);
                TrimInPlace(val);
                if (!val.empty() && val.front() == '"') val.erase(val.begin());
                if (!val.empty() && val.back() == '"') val.pop_back();
                TrimInPlace(val);
                if (!val.empty())
                    out.name = val;
            }
            continue;
        }

        // P = text seconds   or   R = text seconds
        bool isP = StartsWithIgnoreCase(line, "P");
        bool isR = StartsWithIgnoreCase(line, "R");
        if (!isP && !isR) continue;

        auto eq = line.find('=');
        if (eq == std::string::npos) continue;

        std::string rest = line.substr(eq + 1);
        TrimInPlace(rest);
        if (rest.empty()) continue;

        // last token that is a number = duration
        int duration = 3;
        std::string text = rest;

        // find last space-separated token
        size_t lastSpace = rest.find_last_of(" \t");
        if (lastSpace != std::string::npos)
        {
            std::string last = rest.substr(lastSpace + 1);
            TrimInPlace(last);
            // is number?
            bool isNum = !last.empty() && std::all_of(last.begin(), last.end(), [](unsigned char c) {
                return std::isdigit(c);
            });
            if (isNum)
            {
                try
                {
                    duration = std::stoi(last);
                    if (duration < 1) duration = 1;
                    if (duration > 30) duration = 30;
                    text = rest.substr(0, lastSpace);
                    TrimInPlace(text);
                }
                catch (...) {}
            }
        }

        if (text.empty()) continue;

        ConversationLine cl;
        cl.text = text;
        cl.durationSec = duration;

        if (isP)
        {
            if ((int)out.questions.size() < 20)
                out.questions.push_back(cl);
        }
        else
        {
            if ((int)out.responses.size() < 20)
                out.responses.push_back(cl);
        }
    }

    return !out.questions.empty() || !out.responses.empty();
}

void Conversas::LoadConversations()
{
    s_conversations.clear();
    EnsureFolderAndDefaults();

    std::string path = GetConversasFolder();
    if (!std::filesystem::exists(path))
    {
        fileLog->Log("Conversas: pasta nao existe: " + path);
        s_loaded = true;
        return;
    }

    try
    {
        for (const auto& entry : std::filesystem::directory_iterator(path))
        {
            if (!entry.is_regular_file()) continue;
            if (entry.path().extension() != ".ini") continue;

            Conversation conv;
            if (ParseConversationFile(entry.path().string(), conv))
            {
                s_conversations.push_back(std::move(conv));
                fileLog->Log("Conversas: carregado " + entry.path().filename().string() +
                             " (P=" + std::to_string(s_conversations.back().questions.size()) +
                             " R=" + std::to_string(s_conversations.back().responses.size()) + ")");
            }
        }
    }
    catch (const std::exception& e)
    {
        fileLog->Error(std::string("Conversas: erro ao listar pasta: ") + e.what());
    }

    // sort by name
    std::sort(s_conversations.begin(), s_conversations.end(),
              [](const Conversation& a, const Conversation& b) { return a.name < b.name; });

    s_loaded = true;
    fileLog->Log("Conversas: total carregadas = " + std::to_string(s_conversations.size()));
}

void Conversas::Initialize()
{
    if (!s_loaded)
        LoadConversations();
}

void Conversas::StartConversation(const Conversation& conv, Ped* ped)
{
    if (!ped || !Peds::IsValid(ped))
        return;

    // Random question
    std::string policeMsg = "Ola.";
    int policeDur = 3;
    if (!conv.questions.empty())
    {
        int idx = getRandomNumber(0, (int)conv.questions.size() - 1);
        policeMsg = conv.questions[idx].text;
        policeDur = conv.questions[idx].durationSec;
    }

    // Random response
    std::string pedMsg = "...";
    int pedDur = 3;
    if (!conv.responses.empty())
    {
        int idx = getRandomNumber(0, (int)conv.responses.size() - 1);
        pedMsg = conv.responses[idx].text;
        pedDur = conv.responses[idx].durationSec;
    }

    // Format: label color + message white-ish (mono color limit of BottomMessage)
    // Policial in blue, Indivíduo in red
    std::string msg1 = "~b~Policial: " + policeMsg;
    std::string msg2 = "~r~Indivíduo: " + pedMsg;

    BottomMessage::ClearMessages();
    BottomMessage::AddMessage(msg1, policeDur * 1000);
    BottomMessage::AddMessage(msg2, pedDur * 1000);
}

void Conversas::OpenConversarMenu(Ped* ped)
{
    if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
        return;

    Initialize();

    const int pedRef = ped->ref;

    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Conversar");

    if (s_conversations.empty())
    {
        window->AddText("Nenhuma conversa encontrada");
        window->AddText("Coloque arquivos .ini em:");
        window->AddText("data/conversas/");
    }
    else
    {
        for (const auto& conv : s_conversations)
        {
            Conversation convCopy = conv; // copy for lambda
            auto button = window->AddButton(conv.name);
            button->onClick->Add([window, pedRef, convCopy]() {
                window->Close();
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                Conversas::StartConversation(convCopy, p);
            });
        }
    }

    {
        auto button = window->AddButton("~y~Voltar");
        button->onClick->Add([window, pedRef]() {
            window->Close();
            auto p = Peds::GetPed(pedRef);
            if (p && Peds::IsValid(p))
                Pullover::OpenPedMenu(p);
        });
    }
}
