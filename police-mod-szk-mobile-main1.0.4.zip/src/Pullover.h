#pragma once

#include "pch.h"
#include "Ped.h"
#include "Vehicle.h"

class Pullover {
public:
    static void Update();
    static void OnClickWidget();

    static void TryPulloverFromVehicle();
    static void TryPulloverOnFoot();
    static void TryPulloverClosestVehicle();
    static void TryPulloverClosestPed(float maxDistance, bool requireInFront);
    static void TryPulloverClosestTarget(float maxDistance, bool requireInFront);

    static void PulloverPed(Ped* ped);
    static void PulloverPed(Ped* ped, bool fromVehicle);
    static void FreePed(Ped* ped);

    static void PulloverVehicle(Vehicle* vehicle);
    static void PulloverVehicle(Vehicle* vehicle, bool fromVehicle);
    static void FreeVehicle(Vehicle* vehicle);

    static int FindAimingPed();

    static void OpenPedMenu(Ped* ped);
    static void OpenVehicleMenu(Vehicle* vehicle);

    static void CallTowTruck(Vehicle* vehicle);
    static void AskVehicleToMoveToTheRight(Vehicle* vehicle);

    static void TeleportVehicleInFrontOfPlayer(Vehicle* vehicle);

    static void StartFriskVehicle(Vehicle* vehicle);
    static void MandarRevistarPed(Ped* ped);
    static void MandarAlgemarPed(Ped* ped);
    static void TeleportVehicleToPatio(Vehicle* vehicle);
};
