#pragma once

#include "pch.h"
#include <fstream>
#include <filesystem>

struct SkinInfo {
    int id;
    std::string name;
};

// Lista padrao (fallback)
inline std::vector<SkinInfo> g_policeSkinsDefault = {
    {71,  "Security Guard"},
    {73,  "Hippy"},
    {280, "LS Officer"},
    {281, "SF Officer"},
    {282, "LV Officer"},
    {283, "County Sheriff"},
    {284, "Motorbike Cop"},
    {285, "SWAT"},
    {286, "FBI"},
    {287, "Army"}
};

inline std::vector<SkinInfo> g_policeSkins = g_policeSkinsDefault;

inline std::string GetApoioPPath()
{
    return modData->GetFile("data/dualpatrol/apoioP.ini");
}

// Carrega TODOS os [PED] de data/dualpatrol/apoioP.ini
// Chaves: name, ped_id (ou skin_id / model_id)
inline void ReloadPoliceSkinsFromApoioP()
{
    std::string path = GetApoioPPath();
    if (!std::filesystem::exists(path))
    {
        // cria pasta + arquivo padrao
        ModData::CreateFolder(modData->GetFile("data"));
        ModData::CreateFolder(modData->GetFile("data/dualpatrol"));
        std::ofstream out(path);
        if (out.is_open())
        {
            out << "; Skins/policiais de apoio - adicione quantos [PED] quiser\n";
            out << "; name = nome exibido no menu\n";
            out << "; ped_id = ID do modelo do ped\n\n";
            for (auto& s : g_policeSkinsDefault)
                out << "[PED]\nname = " << s.name << "\nped_id = " << s.id << "\n\n";
            out.close();
        }
        g_policeSkins = g_policeSkinsDefault;
        fileLog->Log("Skins: apoioP.ini criado com padrao");
        return;
    }

    std::ifstream in(path);
    if (!in.is_open())
    {
        g_policeSkins = g_policeSkinsDefault;
        return;
    }

    std::vector<SkinInfo> loaded;
    SkinInfo cur;
    bool inPed = false;
    bool hasId = false;

    auto flush = [&]() {
        if (inPed && hasId && cur.id > 0)
        {
            if (cur.name.empty())
                cur.name = "Ped " + std::to_string(cur.id);
            loaded.push_back(cur);
        }
        cur = SkinInfo();
        inPed = false;
        hasId = false;
    };

    auto toLower = [](std::string s) {
        for (char& c : s) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
        return s;
    };

    std::string line;
    while (std::getline(in, line))
    {
        while (!line.empty() && (line.back()=='\r' || line.back()==' ' || line.back()=='\t')) line.pop_back();
        size_t a = 0;
        while (a < line.size() && (line[a]==' ' || line[a]=='\t')) a++;
        line = line.substr(a);
        if (line.empty() || line[0]=='#' || line[0]==';') continue;

        if (line.front()=='[' && line.back()==']')
        {
            flush();
            std::string sec = toLower(line.substr(1, line.size()-2));
            // aceita [PED], [Ped], [ped]
            if (sec == "ped")
                inPed = true;
            continue;
        }
        if (!inPed) continue;

        auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string key = toLower(line.substr(0, eq));
        std::string val = line.substr(eq + 1);
        while (!key.empty() && (key.back()==' '||key.back()=='\t')) key.pop_back();
        while (!val.empty() && (val.front()==' '||val.front()=='\t'||val.front()=='"')) val.erase(val.begin());
        while (!val.empty() && (val.back()==' '||val.back()=='\t'||val.back()=='"')) val.pop_back();

        // remove comentario inline
        auto sc = val.find(';');
        if (sc != std::string::npos) val = val.substr(0, sc);
        while (!val.empty() && (val.back()==' '||val.back()=='\t')) val.pop_back();

        if (key == "name")
            cur.name = val;
        else if (key == "ped_id" || key == "skin_id" || key == "model_id" || key == "id")
        {
            try {
                cur.id = std::stoi(val);
                hasId = true;
            } catch (...) {}
        }
    }
    flush();

    if (loaded.empty())
    {
        fileLog->Log("Skins: apoioP.ini sem [PED] validos — usando padrao");
        g_policeSkins = g_policeSkinsDefault;
    }
    else
    {
        g_policeSkins = loaded;
        fileLog->Log("Skins: carregados " + std::to_string(loaded.size()) + " peds de apoioP.ini");
    }
}

inline bool IsPoliceSkin(int modelId)
{
    for (const auto& s : g_policeSkins)
        if (s.id == modelId)
            return true;
    return false;
}
