#include "Pullover.h"

#include <cmath>
#include "simpleGta.h"

#include "Peds.h"
#include "CleoFunctions.h"
#include "Criminals.h"
#include "ModelLoader.h"
#include "Vehicles.h"
#include "BottomMessage.h"
#include "TopMessage.h"
#include "ScriptTask.h"
#include "Chase.h"
#include "RadioWindow.h"
#include "Escort.h"
#include "DocsWindow.h"
#include "FriskPanel.h"
#include "AudioCollection.h"
#include "RadioSounds.h"
#include "RGWindow.h"
#include "CNHWindow.h"
#include "TicketWindow.h"
#include "FriskWindow.h"
#include "Conversas.h"
#include "Bafometro.h"

static IWindow* g_currentPedMenuWindow = nullptr;
static IWindow* g_currentVehicleMenuWindow = nullptr;

static void ClosePedMenuIfOpen()
{
    // Zera o ponteiro ANTES do Close para evitar double-destroy
    auto* w = g_currentPedMenuWindow;
    g_currentPedMenuWindow = nullptr;
    if (w)
        w->Close();
}

static void CloseVehicleMenuIfOpen()
{
    // Zera o ponteiro ANTES do Close para evitar double-destroy
    auto* w = g_currentVehicleMenuWindow;
    g_currentVehicleMenuWindow = nullptr;
    if (w)
        w->Close();
}

// Fecha a janela e limpa o ponteiro global se for a de abordagem atual
static void SafeCloseMenuWindow(IWindow* window)
{
    if (!window)
        return;
    if (g_currentPedMenuWindow == window)
        g_currentPedMenuWindow = nullptr;
    if (g_currentVehicleMenuWindow == window)
        g_currentVehicleMenuWindow = nullptr;
    // Fecha no proximo tick — evita SIGILL destruir IWindow no meio do callback do botao
    WAIT(0, [window]() {
        if (window)
            window->Close();
    });
}

#include "Partners.h"
#include "pch.h"
#include <cmath>
#include "simpleGta.h"

int aimingPed = NO_PED_FOUND;

void CheckAimingPed()
{
    aimingPed = Pullover::FindAimingPed();
}


// Widget 7 = botão de buzina original do GTA (mesmo do mod antigo)
static const int HORN_WIDGET_ID = 7;

void Pullover::Update()
{
    int dt = menuSZK ? menuSZK->deltaTime : 16;

    static int accumulatorMs = 0;
    accumulatorMs += dt;

    if (accumulatorMs >= 300)
    {
        accumulatorMs = 0;
        CheckAimingPed();
    }

    // Buzina original → deitar no chão
    // SÓ a pé + SÓ enquanto mira em ped JÁ RENDIDO
    int player = GET_PLAYER_ACTOR(0);
    bool onFoot = ACTOR_DEFINED(player) && !IS_CHAR_IN_ANY_CAR(player);

    static bool lastHornPressed = false;
    bool hornNow = false;

    if (onFoot && aimingPed != NO_PED_FOUND)
    {
        auto* ped = Peds::GetPed(aimingPed);
        bool canUseHorn = ped && Peds::IsValid(ped) && ACTOR_DEFINED(ped->ref)
            && ped->flags.hasSurrended
            && !ped->flags.isInconcious
            && !ped->flags.isHandcuffed;

        if (canUseHorn)
        {
            // Só escuta a buzina enquanto mira no rendido (a pé)
            hornNow = IS_WIDGET_PRESSED(HORN_WIDGET_ID);

            if (hornNow && !lastHornPressed)
            {
                ped->SetAnim("car_hookertalk", "PED");
                ped->flags.isFleeing = false;
                AudioCollection::PlayAsVoice(audioLieDown);
            }
        }
    }

    lastHornPressed = hornNow;
}

void Pullover::OnClickWidget()
{
    fileLog->Log("Clicked pullover widget");

    int playerActor = GET_PLAYER_ACTOR(0);

    if(IS_CHAR_IN_ANY_CAR(playerActor))
    {
        TryPulloverFromVehicle();
    } else {
        TryPulloverOnFoot();
    }

    blockInput = !blockInput;
}

void Pullover::TryPulloverFromVehicle()
{
    // De dentro do carro: alcance 2x (antes 10.5 -> 21.0)
    // requireInFront=true: so alvos a frente; escolhe o mais proximo (ped ou veiculo)
    TryPulloverClosestTarget(21.0f, true);
}

void Pullover::TryPulloverOnFoot()
{
    fileLog->Log("try pullover on foot");

    if(aimingPed != NO_PED_FOUND)
    {
        auto ped = Peds::GetPed(aimingPed);
        if (ped)
        {
            PulloverPed(ped, false);
            aimingPed = NO_PED_FOUND;
            return;
        }
    }

    // Sem mira: apenas o mais perto (pedestre OU veiculo, nunca os dois)
    TryPulloverClosestTarget(4.0f, false);
}

// Escolhe so o alvo mais proximo: pedestre a pe OU veiculo (nunca os dois)
void Pullover::TryPulloverClosestTarget(float maxDistance, bool requireInFront)
{
    int playerActor = GET_PLAYER_ACTOR(0);
    auto playerPos = GetPlayerPosition();
    bool fromVehicle = IS_CHAR_IN_ANY_CAR(playerActor);

    Ped* closestPed = nullptr;
    double bestPedDist = maxDistance;

    for (auto& pair : Peds::GetPedsMap())
    {
        Ped* ped = pair.second;
        if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref)) continue;
        if (ped->ref == playerActor) continue;
        if (IS_CHAR_IN_ANY_CAR(ped->ref)) continue;
        // ja rendido e sem fuga: nao e alvo de nova ordem
        if (ped->flags.hasSurrended && !ped->flags.isFleeing) continue;

        auto pedPos = GetPedPosition(ped->ref);
        double dist = distanceBetweenPoints(playerPos, pedPos);
        if (dist > maxDistance) continue;

        if (requireInFront)
        {
            float fx=0, fy=0, fz=0;
            STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, 5.0f, 0.0f, &fx, &fy, &fz);
            double distFront = distanceBetweenPoints(CVector(fx, fy, fz), pedPos);
            float bx=0, by=0, bz=0;
            STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, -3.0f, 0.0f, &bx, &by, &bz);
            double distBack = distanceBetweenPoints(CVector(bx, by, bz), pedPos);
            if (distFront > distBack) continue;
        }

        if (dist < bestPedDist)
        {
            bestPedDist = dist;
            closestPed = ped;
        }
    }

    Vehicle* closestCar = nullptr;
    double bestCarDist = maxDistance;

    auto vehicles = Vehicles::GetAllCarsInSphere(playerPos, maxDistance);
    float fx=0, fy=0, fz=0;
    STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, 5.0f, 0.0f, &fx, &fy, &fz);
    float bx=0, by=0, bz=0;
    STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, -3.0f, 0.0f, &bx, &by, &bz);

    for (auto vehicle : vehicles)
    {
        if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref)) continue;
        if (vehicle->IsPlayerInside()) continue;

        auto carPos = GetCarPosition(vehicle->ref);
        double dist = distanceBetweenPoints(playerPos, carPos);
        if (dist > maxDistance) continue;

        if (requireInFront)
        {
            double distFront = distanceBetweenPoints(CVector(fx, fy, fz), carPos);
            double distBack = distanceBetweenPoints(CVector(bx, by, bz), carPos);
            if (distFront > distBack) continue;
        }

        if (dist < bestCarDist)
        {
            bestCarDist = dist;
            closestCar = vehicle;
        }
    }

    // So um alvo: o mais perto
    if (closestPed && closestCar)
    {
        if (bestPedDist <= bestCarDist)
            PulloverPed(closestPed, fromVehicle);
        else
            PulloverVehicle(closestCar, fromVehicle);
    }
    else if (closestPed)
    {
        PulloverPed(closestPed, fromVehicle);
    }
    else if (closestCar)
    {
        PulloverVehicle(closestCar, fromVehicle);
    }
}

void Pullover::TryPulloverClosestPed(float maxDistance, bool requireInFront)
{
    int playerActor = GET_PLAYER_ACTOR(0);
    auto playerPos = GetPlayerPosition();

    Ped* closest = nullptr;
    double bestDist = maxDistance;

    for (auto& pair : Peds::GetPedsMap())
    {
        Ped* ped = pair.second;
        if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref)) continue;
        if (ped->ref == playerActor) continue;
        if (IS_CHAR_IN_ANY_CAR(ped->ref)) continue;
        if (ped->flags.hasSurrended) continue;

        auto pedPos = GetPedPosition(ped->ref);
        double dist = distanceBetweenPoints(playerPos, pedPos);
        if (dist > maxDistance) continue;

        if (requireInFront)
        {
            float fx=0, fy=0, fz=0;
            STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, 5.0f, 0.0f, &fx, &fy, &fz);
            double distFront = distanceBetweenPoints(CVector(fx, fy, fz), pedPos);
            float bx=0, by=0, bz=0;
            STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, -3.0f, 0.0f, &bx, &by, &bz);
            double distBack = distanceBetweenPoints(CVector(bx, by, bz), pedPos);
            if (distFront > distBack) continue;
        }

        if (dist < bestDist)
        {
            bestDist = dist;
            closest = ped;
        }
    }

    if (closest)
    {
        bool fromVehicle = IS_CHAR_IN_ANY_CAR(playerActor);
        PulloverPed(closest, fromVehicle);
    }
}

void Pullover::TryPulloverClosestVehicle()
{
    int playerActor = GET_PLAYER_ACTOR(0);
    auto playerPos = GetPlayerPosition();

    // A pe: 4m | Da viatura: 7m + 50% = 10.5m
    float maxRange = 4.0f;
    if (IS_CHAR_IN_ANY_CAR(playerActor))
        maxRange = 10.5f;

    // Carros no raio ao redor do player
    auto vehicles = Vehicles::GetAllCarsInSphere(playerPos, maxRange);

    Vehicle* closestCar = nullptr;
    double bestDist = maxRange;

    // Ponto a frente / atras do player para filtrar so quem esta NA FRENTE
    float fx=0, fy=0, fz=0;
    STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, 5.0f, 0.0f, &fx, &fy, &fz);
    float bx=0, by=0, bz=0;
    STORE_COORDS_FROM_ACTOR_WITH_OFFSET(playerActor, 0.0f, -3.0f, 0.0f, &bx, &by, &bz);

    for (auto vehicle : vehicles)
    {
        if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref)) continue;
        if (vehicle->IsPlayerInside()) continue;

        auto carPos = GetCarPosition(vehicle->ref);
        double dist = distanceBetweenPoints(playerPos, carPos);
        if (dist > maxRange) continue;

        // So veiculos a frente do player
        double distFront = distanceBetweenPoints(CVector(fx, fy, fz), carPos);
        double distBack = distanceBetweenPoints(CVector(bx, by, bz), carPos);
        if (distFront > distBack) continue;

        if (dist < bestDist)
        {
            bestDist = dist;
            closestCar = vehicle;
        }
    }

    if (closestCar == nullptr)
        return;

    bool fromVehicle = IS_CHAR_IN_ANY_CAR(playerActor);
    PulloverVehicle(closestCar, fromVehicle);
}

void Pullover::PulloverPed(Ped* ped)
{
    PulloverPed(ped, false);
}

void Pullover::PulloverPed(Ped* ped, bool fromVehicle)
{
    if(!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref)) return;

    if(ped->flags.isInconcious)
    {
        menuDebug->AddLine("~g~pull over ped incounsious");
        ped->flags.showWidget = true;
        return;
    }

    // Se ja esta fugindo: ordem de parada
    if(ped->flags.isFleeing)
    {
        // Armado hostil: so rende com chance_of_armed_surrender
        if (ped->flags.willKillCops && !calculateProbability(CHANCE_ARMED_SURRENDER))
        {
            // Continua hostil / pode atirar
            ped->ShowBlip(COLOR_CRIMINAL);
            Criminals::AddCriminal(ped);
            KILL_ACTOR(ped->ref, GetPlayerActor());
            BottomMessage::SetMessage("~r~suspeito armado nao se rendeu", 2500);
            return;
        }

        ped->flags.isFleeing = false;
        ped->flags.willKillCops = false;
        ped->flags.hasSurrended = true;
        ped->flags.showWidget = true;
        CLEAR_ACTOR_TASK(ped->ref);
        ped->SetCanDoHandsup();
        ped->ShowBlip(COLOR_CRIMINAL);
        Criminals::AddCriminal(ped);
        BottomMessage::SetMessage("~g~individuo se rendeu", 3000);
        return;
    }

    if (fromVehicle)
        AudioCollection::PlayAsVoice(audioPulloverCar);
    else
        AudioCollection::PlayAsVoice(audioPulloverPed);


    menuDebug->AddLine("~g~pull over ped");

    // Armado / hostil: chance configuravel de se render (settings chance_of_armed_surrender)
    if(ped->flags.willSurrender == false && ped->flags.willKillCops == true)
    {
        ped->ShowBlip(COLOR_CRIMINAL);
        Criminals::AddCriminal(ped);

        if (calculateProbability(CHANCE_ARMED_SURRENDER))
        {
            // Se rende e deita (ordem de parada / mira)
            ped->flags.willKillCops = false;
            ped->flags.willSurrender = true;
            ped->flags.hasSurrended = true;
            ped->flags.isFleeing = false;
            ped->flags.showWidget = true;
            CLEAR_ACTOR_TASK(ped->ref);
            // Deitar no chao
            ped->SetAnim("car_hookertalk", "PED");
            BottomMessage::SetMessage("~g~individuo armado se rendeu", 3000);
            return;
        }

        ModelLoader::AddModelToLoad(346);
        ModelLoader::LoadAll([ped]() {
            GIVE_ACTOR_WEAPON(ped->ref, 22, 500);
        });

        KILL_ACTOR(ped->ref, GetPlayerActor());

        return;
    }

    // Chance de o pedestre a pe fugir NA HORA da abordagem (ajustavel no settings.ini)
    // Invasao/callout com canFleeAfterSurrender: multiplica por 3
    {
    float runNowChance = CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED;
    if (ped->flags.canFleeAfterSurrender)
    {
        runNowChance *= 3.0f;
        if (runNowChance > 1.0f) runNowChance = 1.0f;
    }
    if (!fromVehicle && !IS_CHAR_IN_ANY_CAR(ped->ref) && !ped->flags.isHandcuffed
        && calculateProbability(runNowChance))
    {
        ped->flags.isFleeing = true;
        ped->flags.hasSurrended = false;
        ped->flags.showWidget = true; // mantem icone da mao durante a fuga
        ped->flags.healthWhenStartedFleeing = (float)ACTOR_HEALTH(ped->ref);
        ped->ShowBlip(COLOR_CRIMINAL);
        Criminals::AddCriminal(ped);

        CLEAR_ACTOR_TASK(ped->ref);
        FLEE_FROM_ACTOR(ped->ref, GetPlayerActor(), 80.0f, GetFleeTaskDurationMs());

        ClosePedMenuIfOpen();
        BottomMessage::SetMessage("~r~individuo correu", 3500);
        return;
    }
    } // fim runNowChance

    ped->flags.hasSurrended = true;
    ped->flags.showWidget = true;
    ped->SetCanDoHandsup();
    ped->ShowBlip(COLOR_CRIMINAL);
    Criminals::AddCriminal(ped);

    // Fuga apos render: so se flag canFleeAfterSurrender (ex.: invasao domiciliar)
    // chance = chance_of_fleeing_during_approach * 3
    if (ped->flags.canFleeAfterSurrender && !ped->flags.isHandcuffed && !ped->flags.isKidnapVictim)
    {
        float fleeChance = CHANCE_FLEE_DURING_APPROACH * 3.0f;
        if (fleeChance > 1.0f) fleeChance = 1.0f;
        if (calculateProbability(fleeChance))
        {
            int minS = FLEE_DURING_APPROACH_MIN_SECONDS;
            int maxS = FLEE_DURING_APPROACH_MAX_SECONDS;
            if (minS < 1) minS = 1;
            if (maxS < minS) maxS = minS;
            int delayMs = getRandomNumber(minS, maxS) * 1000;
            int pedRef = ped->ref;

            WAIT(delayMs, [pedRef]() {
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                if (p->flags.isHandcuffed) return;
                if (p->flags.isFleeing) return;
                if (!p->flags.hasSurrended) return;
                if (p->flags.isInconcious || ACTOR_DEAD(p->ref)) return;
                if (p->flags.isBeingFrisked) return;

                p->flags.isFleeing = true;
                p->flags.hasSurrended = false;
                p->flags.showWidget = true;
                p->flags.healthWhenStartedFleeing = (float)ACTOR_HEALTH(p->ref);
                p->ClearAnim();
                CLEAR_ACTOR_TASK(p->ref);
                FLEE_FROM_ACTOR(p->ref, GetPlayerActor(), 80.0f, GetFleeTaskDurationMs());
                ClosePedMenuIfOpen();
                BottomMessage::SetMessage("~r~individuo correu", 3500);
            });
        }
    }
}


void Pullover::FreePed(Ped* ped)
{
    if (!ped || !Peds::IsValid(ped)) return;

    menuDebug->AddLine("~g~free ped");

    AudioCollection::PlayAsVoice(audioFreePed);

    ped->flags.showWidget = false;
    ped->flags.hasSurrended = false;
    ped->flags.isFleeing = false;
    ped->ClearAnim();
    CLEAR_ACTOR_TASK(ped->ref);
    ped->HideBlip();
    Criminals::RemoveCriminal(ped);

    // Faz o NPC sair andando (evita ficar parado apos liberar — sequestro etc.)
    if (ACTOR_DEFINED(ped->ref) && !IS_CHAR_IN_ANY_CAR(ped->ref))
    {
        REMOVE_REFERENCES_TO_ACTOR(ped->ref);
        auto pos = ped->GetPosition();
        float ox = (float)getRandomNumber(-40, 40);
        float oy = (float)getRandomNumber(-40, 40);
        TASK_GO_STRAIGHT_TO_COORD(ped->ref, pos.x + ox, pos.y + oy, pos.z, 4, 15000);
    }
}

void Pullover::PulloverVehicle(Vehicle* vehicle)
{
    int playerActor = GET_PLAYER_ACTOR(0);
    bool fromVehicle = IS_CHAR_IN_ANY_CAR(playerActor);
    PulloverVehicle(vehicle, fromVehicle);
}

void Pullover::PulloverVehicle(Vehicle* vehicle, bool fromVehicle)
{
    if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        return;

    // Veiculo vazio ja marcado / em fuga: abre o menu (nao mostra "individuo fugiu")
    if (!vehicle->HasDriver() && (vehicle->flags.showWidget || Chase::IsVehicleRunningFromCops(vehicle)))
    {
        vehicle->ShowBlip(COLOR_CRIMINAL);
        vehicle->flags.showWidget = true;
        OpenVehicleMenu(vehicle);
        return;
    }

    // Em fuga com motorista: mantem icone e abre menu para interagir com o veiculo
    if (Chase::IsVehicleRunningFromCops(vehicle))
    {
        vehicle->ShowBlip(COLOR_CRIMINAL);
        vehicle->flags.showWidget = true;
        OpenVehicleMenu(vehicle);
        return;
    }

    // Ja abordado (icone ativo): abre o menu de veiculo
    if (vehicle->flags.showWidget)
    {
        OpenVehicleMenu(vehicle);
        return;
    }

    if(vehicle->HasDriver())
    {
        BottomMessage::SetMessage(GetTranslatedText("officer_pullover_vehicle"), 3000);

        if (fromVehicle)
            AudioCollection::PlayAsVoice(audioPulloverCar);
        else
            AudioCollection::PlayAsVoice(audioPulloverPed);
    }

    if(vehicle->HasDriver())
    {
        auto driver = Peds::GetPed(vehicle->GetCurrentDriver());
        if (driver && driver->flags.isFleeing)
        {
            // Pedestre fugindo a pe: ainda marca o veiculo com icone
            vehicle->ShowBlip(COLOR_CRIMINAL);
            vehicle->flags.showWidget = true;
            OpenVehicleMenu(vehicle);
            return;
        }

        if(driver && driver->flags.willSurrender == false)
        {
            BottomMessage::SetMessage(GetTranslatedText("suspect_ran_away"), 3000);

            vehicle->ShowBlip(COLOR_CRIMINAL);
            vehicle->flags.showWidget = true;
            Chase::StartChaseWithVehicle(vehicle);

            return;
        }
    }

    vehicle->ShowBlip(COLOR_CRIMINAL);
    vehicle->flags.showWidget = true;

    if(vehicle->HasDriver())
    {
        WAIT(1000, [vehicle]() {
            if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref)) return;
            // Nao desliga motor se ja estiver em fuga
            if (Chase::IsVehicleRunningFromCops(vehicle)) return;
            CAR_TURN_OFF_ENGINE(vehicle->ref);
        });

        WAIT(2500, []() {
            BottomMessage::SetMessage(GetTranslatedText("pullover_get_close_to_vehicle"), 3000);
        });

        // Chance de fugir dirigindo DEPOIS de parado (durante a abordagem)
        // Alvo de veiculo roubado na regiao: chance 2x
        {
        float fleeChance = CHANCE_FLEE_DRIVING_DURING_APPROACH;
        if (vehicle && vehicle->flags.isNearbyStolenTarget)
            fleeChance *= 2.0f;
        if (fleeChance > 1.0f) fleeChance = 1.0f;
        if (calculateProbability(fleeChance))
        {
            int minS = FLEE_DRIVING_DURING_APPROACH_MIN_SECONDS;
            int maxS = FLEE_DRIVING_DURING_APPROACH_MAX_SECONDS;
            if (minS < 1) minS = 1;
            if (maxS < minS) maxS = minS;
            int delayMs = getRandomNumber(minS, maxS) * 1000;
            int carRef = vehicle->ref;

            WAIT(delayMs, [carRef]() {
                auto veh = Vehicles::GetVehicle(carRef);
                if (!veh || !Vehicles::IsValid(veh) || !CAR_DEFINED(veh->ref)) return;
                if (Chase::IsVehicleRunningFromCops(veh)) return;
                if (!veh->HasDriver()) return; // so foge se ainda estiver no carro
                if (!veh->flags.showWidget) return; // ja liberou / encerrou abordagem

                // Fecha menu de veiculo e inicia fuga de carro
                CloseVehicleMenuIfOpen();
                // Icone no veiculo durante a fuga (durante a abordagem)
                if (veh)
                {
                    veh->ShowBlip(COLOR_CRIMINAL);
                    veh->flags.showWidget = true;
                }
                BottomMessage::SetMessage("~r~individuo fugiu", 3500);
                Chase::StartChaseWithVehicle(veh);
            });
        }
        } // fim bloco fleeChance
    } else {
        BottomMessage::SetMessage(GetTranslatedText("pullover_get_close_to_vehicle"), 3000);
    }
}

void Pullover::FreeVehicle(Vehicle* vehicle)
{
    vehicle->HideBlip();
    vehicle->flags.showWidget = false;

    vehicle->ValidateOwners();
    vehicle->MakeOwnersEnter();

    auto owners = vehicle->GetOwners();
    for(auto pedRef : owners)
    {
        auto ped = Peds::GetPed(pedRef);

        if(ped)
        {
            Criminals::RemoveCriminal(ped);
            ped->HideBlip();
            ped->flags.hasSurrended = false;
            ped->flags.showWidget = false;
        }
    }

    AudioCollection::PlayAsVoice(audioFreePed);

    CleoFunctions::AddWaitForFunction("passengers_enter_vehicle_to_free", [vehicle] () {
        if(!Vehicles::IsValid(vehicle)) return true;

        auto ownersCount = vehicle->GetOwners().size();
        auto ocuppantsCount = vehicle->GetCurrentOccupants().size();

        if(ocuppantsCount >= ownersCount) return true;

        return false;
    }, [vehicle] () {
        if(!Vehicles::IsValid(vehicle)) return;

        auto driverRef = vehicle->GetCurrentDriver();
        
        if(!ACTOR_DEFINED(driverRef)) return;

        auto driver = Peds::GetPed(driverRef);
        driver->StartDrivingRandomly();
    });
}

int Pullover::FindAimingPed()
{
    for(int ped = 1; ped < 35584; ped++)
    {
        if(PLAYER_AIMING_AT_ACTOR(0, ped))
        {
            aimingPed = ped;
            return ped;
        }
    }
    return NO_PED_FOUND;
}

void Pullover::OpenPedMenu(Ped* ped)
{
    if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
        return;

    // Se estava fugindo e abriu o menu (icone da mao), para a fuga e se rende
    if (ped->flags.isFleeing && !ped->flags.isInconcious)
    {
        ped->flags.isFleeing = false;
        ped->flags.hasSurrended = true;
        ped->flags.showWidget = true;
        CLEAR_ACTOR_TASK(ped->ref);
        ped->SetCanDoHandsup();
        ped->ShowBlip(COLOR_CRIMINAL);
        Criminals::AddCriminal(ped);
    }

    const int pedRef = ped->ref;

    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_pullover_title"));
    g_currentPedMenuWindow = window;
    
    if(ped->flags.isInconcious)
    {
        {
            auto button = window->AddButton(GetTranslatedText("reanimate_ped"));
            button->onClick->Add([window, pedRef]() {
                SafeCloseMenuWindow(window);
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                p->Reanimate();
            });
        }

        {
            auto button = window->AddButton("Teleport to hospital");
            button->onClick->Add([window, pedRef]() {
                SafeCloseMenuWindow(window);
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                Criminals::RemoveCriminal(p);
                p->QueueDestroy();
            });
        }
    }

    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton(GetTranslatedText("ask_for_rg"));
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);

            BottomMessage::SetMessage(GetTranslatedText("dialog_ask_for_rg"), 3000);

            AudioCollection::PlayAsVoice(audioAskRG, [pedRef]() {
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                p->flags.shownRG = true;
                // Estilo painel: pop-up + consulta automatica
                // Estilo classico (ou ambos): ainda pode abrir o cartao RG se UseClassic
                if (FriskPanel::UsePanel() && !FriskPanel::UseClassic())
                {
                    DocsWindow::ShowRG(p);
                }
                else if (FriskPanel::UsePanel() && FriskPanel::UseClassic())
                {
                    // ambos: painel+consulta e tambem cartao
                    DocsWindow::ShowRG(p);
                    RGWindow::CreateRG(p);
                }
                else
                {
                    RGWindow::CreateRG(p);
                }
            });
        });
    }

    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton(GetTranslatedText("ask_for_cnh"));
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);
            g_blockInteractions = true;

            BottomMessage::SetMessage(GetTranslatedText("dialog_ask_for_cnh"), 3000);

            AudioCollection::PlayAsVoice(audioAskCNH, [pedRef]() {
                g_blockInteractions = false;
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                if (FriskPanel::UsePanel() && !FriskPanel::UseClassic())
                {
                    DocsWindow::ShowCNH(p);
                }
                else if (FriskPanel::UsePanel() && FriskPanel::UseClassic())
                {
                    DocsWindow::ShowCNH(p);
                    CNHWindow::CreateCNH(p);
                }
                else
                {
                    CNHWindow::CreateCNH(p);
                }
            });
        });
    }

    if(ped->flags.isInconcious == false)
    {
        if(ped->vehicleOwned > 0)
        {
            auto vehicle = Vehicles::GetVehicle(ped->vehicleOwned);
            int vehicleRef = vehicle ? vehicle->ref : -1;

            auto button = window->AddButton(GetTranslatedText("ask_for_crlv"));
            button->onClick->Add([window, pedRef, vehicleRef]() {
                SafeCloseMenuWindow(window);

                auto p = Peds::GetPed(pedRef);
                auto v = Vehicles::GetVehicle(vehicleRef);
                if (!p || !Peds::IsValid(p) || !v || !Vehicles::IsValid(v)) return;

                if(v->originalDoc.isStolen)
                {
                    BottomMessage::SetMessage("Eu nao tenho o documento do veiculo..", 3000);
                } else {
                    BottomMessage::SetMessage(GetTranslatedText("dialog_ask_for_crlv"), 3000);
                    
                    g_blockInteractions = true;

                    AudioCollection::PlayAsVoice(audioAskCRLV, [pedRef, vehicleRef]() {
                        g_blockInteractions = false;
                        auto p2 = Peds::GetPed(pedRef);
                        auto v2 = Vehicles::GetVehicle(vehicleRef);
                        if (!p2 || !Peds::IsValid(p2) || !v2 || !Vehicles::IsValid(v2)) return;
                        DocsWindow::ShowCRLV(p2, v2);
                    });
                }
            });
        }
    }

    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton("Bafometro");
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);
            auto p = Peds::GetPed(pedRef);
            if (!p || !Peds::IsValid(p)) return;
            Bafometro::PerformTest(p);
        });
    }

    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton("Conversar");
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);
            auto p = Peds::GetPed(pedRef);
            if (!p || !Peds::IsValid(p)) return;
            Conversas::OpenConversarMenu(p);
        });
    }

    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton(GetTranslatedText("frisk_ped"));
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);
            auto p = Peds::GetPed(pedRef);
            if (!p || !Peds::IsValid(p)) return;
            p->flags.isBeingFrisked = true; // impede fuga durante a revista
            p->flags.showBackCheckpoint = true;
            p->flags.canShowFriskMenu = true;
        });
    }

    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton("Mandar revistar");
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);
            auto p = Peds::GetPed(pedRef);
            if (!p || !Peds::IsValid(p)) return;
            p->flags.isBeingFrisked = true; // impede fuga durante a revista do parceiro
            MandarRevistarPed(p);
        });
    }
    
    if(ped->flags.isInconcious == false)
    {
        auto button = window->AddButton(GetTranslatedText("escort_ped"));
        button->onClick->Add([window, pedRef]() {
            SafeCloseMenuWindow(window);
            auto p = Peds::GetPed(pedRef);
            if (!p || !Peds::IsValid(p)) return;
            Escort::OpenEscortWindow(p);
        });
    }

    if(ped->flags.isInconcious == false)
    {
        // Nova opção "Posição" — agrupa mão na cabeça / mão pra trás / deitar / normal
        {
            auto button = window->AddButton("Posicao");
            button->onClick->Add([window, pedRef]() {
                SafeCloseMenuWindow(window);
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p) || !ACTOR_DEFINED(p->ref)) return;

                auto* posWindow = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Posicao");
                g_currentPedMenuWindow = posWindow;
                posWindow->AddText("~b~Escolha a posicao");

                // Ao mudar posicao o menu NAO fecha
                auto btnHead = posWindow->AddButton(GetTranslatedText("hands_on_head"));
                btnHead->onClick->Add([pedRef]() {
                    auto pp = Peds::GetPed(pedRef);
                    if (!pp || !Peds::IsValid(pp) || !ACTOR_DEFINED(pp->ref)) return;
                    AudioCollection::PlayAsVoice(audioPutHandsHead);
                    pp->SetAnim("handscower", "PED");
                    pp->flags.isFleeing = false;
                });

                auto btnBehind = posWindow->AddButton(GetTranslatedText("hands_behind"));
                btnBehind->onClick->Add([pedRef]() {
                    auto pp = Peds::GetPed(pedRef);
                    if (!pp || !Peds::IsValid(pp) || !ACTOR_DEFINED(pp->ref)) return;
                    AudioCollection::PlayAsVoice(audioPutHandsBehind);
                    pp->SetAnim("bomber", "PED");
                    pp->flags.isFleeing = false;
                });

                auto btnLie = posWindow->AddButton("Deitar no chao");
                btnLie->onClick->Add([pedRef]() {
                    auto pp = Peds::GetPed(pedRef);
                    if (!pp || !Peds::IsValid(pp) || !ACTOR_DEFINED(pp->ref)) return;
                    pp->SetAnim("car_hookertalk", "PED");
                    pp->flags.isFleeing = false;
                    AudioCollection::PlayAsVoice(audioLieDown);
                });

                auto btnNormal = posWindow->AddButton("Padrao");
                btnNormal->onClick->Add([pedRef]() {
                    auto pp = Peds::GetPed(pedRef);
                    if (!pp || !Peds::IsValid(pp) || !ACTOR_DEFINED(pp->ref)) return;
                    // Fica parado na animacao idle (stance) — posicao normal
                    pp->SetAnim("IDLE_stance", "PED");
                    pp->flags.isFleeing = false;
                });

                // Voltar = retorna ao menu de abordagem (nao fecha tudo)
                auto btnClose = posWindow->AddButton("~y~Voltar");
                btnClose->onClick->Add([posWindow, pedRef]() {
                    SafeCloseMenuWindow(posWindow);
                    auto pp = Peds::GetPed(pedRef);
                    if (pp && Peds::IsValid(pp) && ACTOR_DEFINED(pp->ref))
                        Pullover::OpenPedMenu(pp);
                });
            });
        }

        {
            auto button = window->AddButton("Algemar");
            button->onClick->Add([window, pedRef]() {
                SafeCloseMenuWindow(window);
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p) || !ACTOR_DEFINED(p->ref)) return;

                auto* cuffWindow = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Algemar");
                g_currentPedMenuWindow = cuffWindow;
                cuffWindow->AddText("~b~Escolha a acao");

                auto btnSelf = cuffWindow->AddButton("Algemar");
                btnSelf->onClick->Add([cuffWindow, pedRef]() {
                    SafeCloseMenuWindow(cuffWindow);
                    auto pp = Peds::GetPed(pedRef);
                    if (!pp || !Peds::IsValid(pp)) return;
                    pp->flags.isHandcuffed = true;
                    pp->flags.isFleeing = false;
                    pp->SetAnim("bomber", "PED");
                    if (audioHandcuff)
                    {
                        auto a = audioHandcuff->GetRandomAudio();
                        if (a)
                            a->Play();
                        else
                            fileLog->Error("handcuff.wav nao carregado (coloque em assets/audios/officer/handcuff.wav)");
                    }
                    BottomMessage::SetMessage("~r~individuo algemado", 3000);
                });

                auto btnOrder = cuffWindow->AddButton("Mandar algemar");
                btnOrder->onClick->Add([cuffWindow, pedRef]() {
                    SafeCloseMenuWindow(cuffWindow);
                    auto pp = Peds::GetPed(pedRef);
                    if (!pp || !Peds::IsValid(pp)) return;
                    Pullover::MandarAlgemarPed(pp);
                });

                auto btnBack = cuffWindow->AddButton("~y~Voltar");
                btnBack->onClick->Add([cuffWindow, pedRef]() {
                    SafeCloseMenuWindow(cuffWindow);
                    auto pp = Peds::GetPed(pedRef);
                    if (pp && Peds::IsValid(pp) && ACTOR_DEFINED(pp->ref))
                        Pullover::OpenPedMenu(pp);
                });
            });
        }
    }

    if(ped->flags.isInconcious == false)
    {
        if(ped->vehicleOwned > 0)
        {
            auto vehicle = Vehicles::GetVehicle(ped->vehicleOwned);
            int vehicleRef = vehicle ? vehicle->ref : -1;

            auto button = window->AddButton("~g~Liberar");
            button->onClick->Add([window, vehicleRef]() {
                SafeCloseMenuWindow(window);
                auto v = Vehicles::GetVehicle(vehicleRef);
                if(!v || !Vehicles::IsValid(v))
                {
                    BottomMessage::SetMessage("~r~An error ocurred", 2000);
                    return;
                }
                FreeVehicle(v);
            });
        } else {
            auto button = window->AddButton("~g~Liberar");
            button->onClick->Add([window, pedRef]() {
                SafeCloseMenuWindow(window);
                auto p = Peds::GetPed(pedRef);
                if (!p || !Peds::IsValid(p)) return;
                FreePed(p);
            });
        }
    }

    {
        auto button = window->AddButton("~y~" + GetTranslatedText("close"));
        button->onClick->Add([window]() {
            SafeCloseMenuWindow(window);
        });
    }
}

void Pullover::OpenVehicleMenu(Vehicle* vehicle)
{
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, GetTranslatedText("window_pullover_title"));
    g_currentVehicleMenuWindow = window;
    
    bool vehicleIsEmpty = vehicle->GetCurrentOccupants().size() == 0;

    if(vehicleIsEmpty == false)
    {
        auto button = window->AddButton(GetTranslatedText("ask_leave_vehicle"));
        button->onClick->Add([window, vehicle]() {
            // Um unico Close (antes dava double-destroy e crash no MenuSZK)
            SafeCloseMenuWindow(window);
            
            AudioCollection::PlayAsVoice(audioExitVehicleHandsUp, [vehicle]() {

                auto ocuppants = vehicle->GetCurrentOccupants();
            
                vehicle->SetOwners();
                vehicle->MakeOccupantsLeave();

                // Cancela fuga de carro (motorista desceu)
                vehicle->flags.showWidget = false;

                for(auto pedRef : ocuppants)
                {
                    auto ped = Peds::GetPed(pedRef);
                    if (!ped) continue;

                    Criminals::AddCriminal(ped);
                    ped->ShowBlip(COLOR_CRIMINAL);
                    ped->flags.showWidget = true;

                    // Sequestro / armados: reagem (IA de combate), nao ficam parados com mao pra cima
                    if (ped->flags.willKillCops || !ped->flags.willSurrender)
                    {
                        ped->flags.hasSurrended = false;
                        ped->flags.willKillCops = true;
                        CLEAR_ACTOR_TASK(ped->ref);
                    }
                    else
                    {
                        ped->flags.hasSurrended = true;
                        ped->SetCanDoHandsup();
                    }
                }

            });
        });
    }

    if(vehicleIsEmpty == false)
    {
        auto button = window->AddButton(GetTranslatedText("ask_move_to_the_right"));
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            
            AskVehicleToMoveToTheRight(vehicle);
        });
    }

    if(vehicleIsEmpty == false)
    {
        auto button = window->AddButton("Bafometro");
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            // Testa o motorista (primeiro ocupante)
            auto occupants = vehicle->GetCurrentOccupants();
            if (occupants.empty())
            {
                BottomMessage::SetMessage("~r~Nenhum ocupante no veiculo", 2500);
                return;
            }
            auto ped = Peds::GetPed(occupants[0]);
            if (!ped || !Peds::IsValid(ped))
            {
                BottomMessage::SetMessage("~r~Individuo invalido", 2500);
                return;
            }
            Bafometro::PerformTest(ped);
        });
    }

    if(vehicleIsEmpty)
    {
        auto button = window->AddButton(GetTranslatedText("call_tow_truck"));
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            
            auto owners = vehicle->GetOwners();

            for(auto pedRef : owners)
            {
                auto ped = Peds::GetPed(pedRef);
                ped->vehicleOwned = -1;
                ped->UpdateSeatPosition();
            }

            vehicle->flags.showWidget = false;

            auto audio = audioRequestTowTruck->GetRandomAudio();

            RadioSounds::PlayAudioNowDontAttach(audio);
            
            WaitForAudioFinish(audio, [vehicle]() {
                CallTowTruck(vehicle);
            });
        });
    }

    {
        auto button = window->AddButton(GetTranslatedText("check_vehicle"));
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);

            DocsWindow::ShowVehicleVisualInfo(vehicle);
        });
    }

    if(vehicle->policeVehicleData != nullptr)
    {
        auto button = window->AddButton(GetTranslatedText("customize_trunk"));
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);

            vehicle->trunk->CreatePreviewPeds();

            WAIT(200, [vehicle]() {
                Trunk::OpenCustomizeMenu(vehicle->ref);
            });
        });
    }

    {
        auto button = window->AddButton("Aplicar multa");
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            TicketWindow::Open(vehicle);
        });
    }

    {
        auto button = window->AddButton("Revistar veiculo");
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            StartFriskVehicle(vehicle);
        });
    }

    {
        auto button = window->AddButton("Mover veiculo");
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            TeleportVehicleInFrontOfPlayer(vehicle);
        });
    }

    {
        auto button = window->AddButton("Teleportar para o patio");
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);
            TeleportVehicleToPatio(vehicle);
        });
    }

    {
        auto button = window->AddButton("~g~Liberar");
        button->onClick->Add([window, vehicle]() {
            SafeCloseMenuWindow(window);

            FreeVehicle(vehicle);
        });
    }

    {
        auto button = window->AddButton("~y~" + GetTranslatedText("close"));
        button->onClick->Add([window]() {
            SafeCloseMenuWindow(window);
        });
    }
}

void Pullover::CallTowTruck(Vehicle* vehicle)
{
    fileLog->Log("Pullover: CallTowTruck");

    int towModelId = 578;
    int driverId = 50;

    ModelLoader::AddModelToLoad(towModelId);
    ModelLoader::AddModelToLoad(driverId);

    ModelLoader::LoadAll([towModelId, driverId, vehicle]() {
        
        fileLog->Log("spawning tow truck...");

        auto playerPosition = GetPlayerPosition();
        auto spawnPosition = GET_CLOSEST_CAR_NODE(playerPosition.x, playerPosition.y + 100, playerPosition.z);

        auto towRef = CREATE_CAR_AT(towModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        auto towTruck = Vehicles::RegisterVehicle(towRef);

        towTruck->ShowBlip(COLOR_YELLOW);

        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(towRef, PedType::CivFemale, driverId);
        Peds::RegisterPed(driverRef);

        auto targetPosition = GET_CLOSEST_CAR_NODE(playerPosition.x, playerPosition.y, playerPosition.z);

        ScriptTask* taskDrive = new ScriptTask("drive");

        taskDrive->onBegin = [towRef, targetPosition]() {
            SET_CAR_MAX_SPEED(towRef, 20.0f);
            SET_CAR_TRAFFIC_BEHAVIOUR(towRef, DrivingMode::AvoidCars);
            CAR_DRIVE_TO(towRef, targetPosition.x, targetPosition.y, targetPosition.z);
        };
        taskDrive->onExecute = [towTruck, targetPosition]() {
            
            if(!Vehicles::IsValid(towTruck)) return SCRIPT_CANCEL;

            if(RadioWindow::m_cancelServices) return SCRIPT_CANCEL;

            auto distance = DistanceFromVehicle(towTruck->ref, targetPosition);

            if(distance < 10.0f) return SCRIPT_SUCCESS;

            return SCRIPT_KEEP_GOING;
        };
        taskDrive->onCancel = [towTruck]() {
            TopMessage::ClearMessage();

            if(!Vehicles::IsValid(towTruck)) return;

            BottomMessage::SetMessage("Guincho cancelado!", 3000);

            if(Vehicles::IsValid(towTruck))
            {
                towTruck->QueueDestroy(true);
            }
        };
        taskDrive->onComplete = [vehicle, towTruck]() {
            
            TopMessage::ClearMessage();

            //

            CVector offset = CVector(0, -0.5, 0.6);

            if(Vehicles::IsValid(vehicle))
            {
                ATTACH_CAR_TO_CAR(vehicle->ref, towTruck->ref, offset.x, offset.y, offset.z, 0, 0, 0);
            }

            vehicle->HideBlip();

            //

            ScriptTask* taskLeave = new ScriptTask("task_leave");
            taskLeave->onBegin = [towTruck]() {
                ScriptTask::MakeVehicleLeave(towTruck->ref);
            };
            taskLeave->onExecute = [towTruck]() {
                if(!Vehicles::IsValid(towTruck)) return SCRIPT_CANCEL;

                auto towPosition = GetCarPosition(towTruck->ref);
                auto distance = DistanceFromPed(GetPlayerActor(), towPosition);

                menuDebug->AddLine("leave, " + std::to_string(distance));

                if(distance > 120.0f) return SCRIPT_SUCCESS;

                return SCRIPT_KEEP_GOING;
            };
            taskLeave->onComplete = [vehicle, towTruck]() {
                //on complete

                if(Vehicles::IsValid(vehicle))
                {
                    vehicle->QueueDestroy(true);
                }
                
                if(Vehicles::IsValid(towTruck))
                {
                    towTruck->QueueDestroy(true);
                }
            };
            taskLeave->Start();

        };
        taskDrive->Start();

        TopMessage::SetMessage(GetTranslatedText("wait_for_tow_truck"));
    });
}

void Pullover::AskVehicleToMoveToTheRight(Vehicle* vehicle)
{
    // Comportamento antigo: pedir para encostar a direita do proprio carro
    if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        return;

    AudioCollection::PlayAsVoice(audioMoveVehicleToRight);

    auto stopPosition = GetCarPositionWithOffset(vehicle->ref, CVector(5.0f, 7.0f, 0));
    
    auto sphere = CREATE_SPHERE(stopPosition.x, stopPosition.y, stopPosition.z, 1.0f);

    SET_CAR_ENGINE_OPERATION(vehicle->ref, true);
    SET_CAR_TRAFFIC_BEHAVIOUR(vehicle->ref, DrivingMode::StopForCars);
    SET_CAR_MAX_SPEED(vehicle->ref, 30.0f);
    CAR_DRIVE_TO(vehicle->ref, stopPosition.x, stopPosition.y, stopPosition.z);

    WAIT(2000, [sphere]() {
        DESTROY_SPHERE(sphere);
    });
}


void Pullover::TeleportVehicleInFrontOfPlayer(Vehicle* vehicle)
{
    // Teleporta a viatura para a frente de onde o player esta olhando.
    // Mantem o heading original do carro (nao gira).
    // Z = Z do player. Sem no de rua.
    if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
    {
        BottomMessage::SetMessage("~r~Veiculo invalido", 2500);
        return;
    }

    int playerActor = GET_PLAYER_ACTOR(0);
    if (!ACTOR_DEFINED(playerActor))
        return;

    if (vehicle->IsPlayerInside())
    {
        BottomMessage::SetMessage("~r~Saia do veiculo primeiro", 2500);
        return;
    }

    int carRef = vehicle->ref;

    SET_CAR_MAX_SPEED(carRef, 0.0f);
    SET_CAR_ENGINE_OPERATION(carRef, false);
    for (int pedRef : vehicle->GetCurrentOccupants())
    {
        if (ACTOR_DEFINED(pedRef))
            CLEAR_ACTOR_TASK(pedRef);
    }

    auto playerPos = GetPedPosition(playerActor);
    const float distFront = 3.0f; // metade da distancia anterior (6m)

    float hRad = GET_CHAR_HEADING(playerActor) * (3.14159265f / 180.0f);
    float x = playerPos.x - sinf(hRad) * distFront;
    float y = playerPos.y + cosf(hRad) * distFront;
    float z = playerPos.z;

    // Mantem orientacao atual do veiculo (nao aplica SET_CAR_Z_ANGLE)
    auto applyPos = [vehicle, x, y, z](bool unfreeze) {
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
            return;

        int carRef = vehicle->ref;
        FREEZE_CAR_POSITION(carRef, true);
        PUT_CAR_AT(carRef, x, y, z);

        if (vehicle->ptr)
        {
            CVehicle* pVeh = (CVehicle*)vehicle->ptr;
            CMatrix* mat = pVeh->GetMatrix();
            if (mat)
            {
                // so posicao — preserva right/forward/up (nao gira)
                mat->m_pos.x = x; mat->m_pos.y = y; mat->m_pos.z = z;
                mat->pos.x = x;   mat->pos.y = y;   mat->pos.z = z;
                mat->px = x;      mat->py = y;      mat->pz = z;
            }
            CSimpleTransform* place = pVeh->GetPlacement();
            if (place)
            {
                place->pos.x = x;
                place->pos.y = y;
                place->pos.z = z;
                // nao altera place->heading
            }
        }

        if (unfreeze)
        {
            FREEZE_CAR_POSITION(carRef, false);
            SET_CAR_ENGINE_OPERATION(carRef, true);
        }
    };

    applyPos(false);

    WAIT(0, [applyPos]() {
        applyPos(false);
    });

    WAIT(50, [applyPos]() {
        applyPos(true);
        BottomMessage::SetMessage("~b~Veiculo movido", 2000);
    });
}

void Pullover::StartFriskVehicle(Vehicle* vehicle)
{
    if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
    {
        BottomMessage::SetMessage("~r~Veiculo invalido", 2500);
        return;
    }

    BottomMessage::SetMessage("Aproxime-se do veiculo...", 3000);

    CleoFunctions::AddCondition([vehicle](std::function<void()> complete, std::function<void()> cancel) {
        if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        {
            cancel();
            return;
        }

        auto playerActor = GET_PLAYER_ACTOR(0);
        auto dist = DistanceFromPed(playerActor, GetCarPosition(vehicle->ref));

        if (dist > 15.0f)
        {
            BottomMessage::SetMessage("~r~Muito longe do veiculo", 2500);
            cancel();
            return;
        }

        if (dist < 3.0f)
            complete();
    }, [vehicle]() {
        if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
            return;

        auto playerActor = GET_PLAYER_ACTOR(0);

        if (!HAS_ANIMATION_LOADED("gangs"))
            LOAD_ANIMATION("gangs");

        // Nao usa freeze: no mobile freeze cancela/impede a IFP
        CLEAR_ACTOR_TASK(playerActor);
        PERFORM_ANIMATION_AS_ACTOR(playerActor, "hndshkfa_swt", "gangs", 8.0f, 0, 0, 0, 0, -1);

        WAIT(2800, [vehicle]() {
            if (Vehicles::IsValid(vehicle) && CAR_DEFINED(vehicle->ref))
                FriskWindow::OpenForVehicle(vehicle);
        });
    }, []() {
        // cancel
    });
}

void Pullover::MandarRevistarPed(Ped* ped)
{
    // Fluxo: tira do grupo + clear task -> posiciona -> anim IFP (SEM freeze) -> devolve ao grupo
    if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
    {
        BottomMessage::SetMessage("~r~Pedestre invalido", 2500);
        return;
    }

    auto pedPos = GetPedPosition(ped->ref);
    Ped* partner = Partners::GetClosestPartnerOnFoot(pedPos);

    if (!partner)
    {
        BottomMessage::SetMessage("~r~nao ha parceiros", 3000);
        ped->flags.isBeingFrisked = false;
        return;
    }

    int partnerHandle = partner->ref;
    int pedHandle = ped->ref;

    ped->flags.isBeingFrisked = true;

    if (!HAS_ANIMATION_LOADED("gangs"))
        LOAD_ANIMATION("gangs");

    BottomMessage::SetMessage("~b~Parceiro revistando", 2000);

    // Tira do grupo para a IA de seguir não puxar ele do lugar
    REMOVE_ACTOR_FROM_GROUP(partnerHandle);
    CLEAR_ACTOR_TASK(partnerHandle);

    // Posiciona atras do pedestre (~0.9m)
    auto heading = GET_CHAR_HEADING(pedHandle);
    auto newPos = GetPedPositionWithOffset(pedHandle, CVector(0.0f, -0.9f, 0.0f));

    SET_CHAR_COORDINATES(partnerHandle, newPos.x, newPos.y, newPos.z);
    SET_CHAR_HEADING(partnerHandle, heading);

    // Animacao mais longa (~ +5s): loop ligado, tempo estendido
    CLEAR_ACTOR_TASK(partnerHandle);
    PERFORM_ANIMATION_AS_ACTOR(partnerHandle, "hndshkfa_swt", "gangs", 8.0f, 1, 0, 0, 0, 8500);

    // Abre o menu de revista durante a animacao
    WAIT(2500, [ped]() {
        if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
            return;
        FriskWindow::OpenForPed(ped);
    });

    // Depois da animacao (+5s em relacao aos 3500ms anteriores): limpa task e devolve ao grupo
    WAIT(8500, [partnerHandle]() {
        if (!ACTOR_DEFINED(partnerHandle))
            return;

        CLEAR_ACTOR_TASK(partnerHandle);

        auto playerActor = GET_PLAYER_ACTOR(0);
        auto playerGroup = GET_PLAYER_GROUP(0);
        PUT_ACTOR_IN_GROUP_AS_LEADER(partnerHandle, playerActor);
        PUT_ACTOR_IN_GROUP(playerGroup, partnerHandle);
    });
}


void Pullover::MandarAlgemarPed(Ped* ped)
{
    if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref))
    {
        BottomMessage::SetMessage("~r~Pedestre invalido", 2500);
        return;
    }

    auto pedPos = GetPedPosition(ped->ref);
    Ped* partner = Partners::GetClosestPartnerOnFoot(pedPos);

    if (!partner)
    {
        BottomMessage::SetMessage("~r~nao ha parceiros proximos", 3000);
        return;
    }

    int partnerHandle = partner->ref;
    int pedHandle = ped->ref;

    // Impede fuga durante a algema
    ped->flags.isBeingFrisked = true;
    ped->flags.isFleeing = false;

    BottomMessage::SetMessage("~b~Parceiro algemando", 2000);

    // Tira do grupo para a IA de seguir nao puxar ele do lugar
    REMOVE_ACTOR_FROM_GROUP(partnerHandle);
    CLEAR_ACTOR_TASK(partnerHandle);

    // Mesmo offset da revista (~atras do individuo)
    auto heading = GET_CHAR_HEADING(pedHandle);
    auto newPos = GetPedPositionWithOffset(pedHandle, CVector(0.0f, -0.9f, 0.0f));
    SET_CHAR_COORDINATES(partnerHandle, newPos.x, newPos.y, newPos.z);
    SET_CHAR_HEADING(partnerHandle, heading);
    CLEAR_ACTOR_TASK(partnerHandle);

    // Som da algema no individuo
    if (audioHandcuff)
    {
        auto a = audioHandcuff->GetRandomAudio();
        if (a)
            a->Play();
        else
            fileLog->Error("handcuff.wav nao carregado (coloque em assets/audios/officer/handcuff.wav)");
    }

    ped->flags.isHandcuffed = true;
    ped->SetAnim("bomber", "PED");

    // 2 segundos parado no offset, depois volta ao grupo (sem anim extra)
    WAIT(2000, [partnerHandle, pedHandle]() {
        auto pp = Peds::GetPed(pedHandle);
        if (pp && Peds::IsValid(pp))
            pp->flags.isBeingFrisked = false;

        if (!ACTOR_DEFINED(partnerHandle))
            return;

        CLEAR_ACTOR_TASK(partnerHandle);

        auto playerActor = GET_PLAYER_ACTOR(0);
        auto playerGroup = GET_PLAYER_GROUP(0);
        PUT_ACTOR_IN_GROUP_AS_LEADER(partnerHandle, playerActor);
        PUT_ACTOR_IN_GROUP(playerGroup, partnerHandle);

        BottomMessage::SetMessage("~r~individuo algemado", 3000);
    });
}

void Pullover::TeleportVehicleToPatio(Vehicle* vehicle)
{
    // Nome "patio": na pratica DESTROI o veiculo com checks (nao teleporta)
    if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
    {
        BottomMessage::SetMessage("~r~Veiculo invalido", 2500);
        return;
    }

    // Nao destroi se o player estiver dentro
    if (vehicle->IsPlayerInside())
    {
        BottomMessage::SetMessage("~r~Saia do veiculo primeiro", 2500);
        return;
    }

    int carRef = vehicle->ref;

    // Limpa ocupantes atuais do carro (se ainda estiverem dentro)
    auto occupants = vehicle->GetCurrentOccupants();
    for (int pedRef : occupants)
    {
        if (!ACTOR_DEFINED(pedRef)) continue;
        if (IS_CHAR_IN_ANY_CAR(pedRef))
        {
            // tira do carro com seguranca
            // (CLEAR + deixar o destroy do veiculo cuidar depois)
            CLEAR_ACTOR_TASK(pedRef);
        }
    }

    vehicle->flags.showWidget = false;
    vehicle->HideBlip();

    // Desvincula owners para nao deixar ponteiro morto
    auto owners = vehicle->GetOwners();
    for (int pedRef : owners)
    {
        auto ped = Peds::GetPed(pedRef);
        if (ped)
        {
            ped->vehicleOwned = -1;
            Criminals::RemoveCriminal(ped);
            ped->flags.showWidget = false;
            ped->HideBlip();
        }
    }

    // Destroi com o fluxo seguro do mod
    vehicle->QueueDestroy(false);

    BottomMessage::SetMessage("~b~Veiculo enviado ao patio", 3000);
}
