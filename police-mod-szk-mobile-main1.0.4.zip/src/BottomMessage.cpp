#include "BottomMessage.h"

int s_timer = 0.0f;
int s_currentIndex = -1;
IContainer* s_container = nullptr;

std::vector<IMessage> BottomMessage::Messages;

static CRGBA s_defaultColor = CRGBA(255, 255, 255);

// Converte ~r~ / ~g~ / ~y~ / ~b~ / ~w~ do inicio do texto em cor do menuSZK
static std::string ApplyGtaColorToContainer(IContainer* container, const std::string& message)
{
    if (!container) return message;

    CRGBA color = s_defaultColor;
    std::string text = message;

    auto takeCode = [&](char code, CRGBA c) {
        std::string token = std::string("~") + code + "~";
        if (text.rfind(token, 0) == 0)
        {
            color = c;
            text = text.substr(token.size());
            return true;
        }
        return false;
    };

    // aceita varios codigos no inicio (pega o primeiro de cor)
    while (text.size() >= 3 && text[0] == '~')
    {
        char code = text[1];
        if (code == 'r' || code == 'R') { takeCode(code, CRGBA(255, 40, 40)); break; }
        if (code == 'g' || code == 'G') { takeCode(code, CRGBA(40, 255, 40)); break; }
        if (code == 'y' || code == 'Y') { takeCode(code, CRGBA(255, 220, 40)); break; }
        if (code == 'b' || code == 'B') { takeCode(code, CRGBA(40, 120, 255)); break; }
        if (code == 'w' || code == 'W') { takeCode(code, CRGBA(255, 255, 255)); break; }
        break;
    }

    container->textFont.color = color;
    return text;
}

void BottomMessage::Initialize()
{
    auto container = menuSZK->CreateContainer("bottomMessage");
    container->horizontalAlign = HorizontalAlign::Middle;
    container->verticalAlign = VerticalAlign::Bottom;
    container->localOffset = CVector2D(0, -100);
    container->clickThroughMode = ClickThroughMode::ClickThroughThisAndChildren;
    container->drawBackground = false;

    container->text = "";
    container->textHorizontalAlign = HorizontalAlign::Middle;
    container->textVerticalAlign = VerticalAlign::Middle;

    auto font = &container->textFont;
    font->fontSize = 2.0f;
    font->align = eFontAlignment::ALIGN_CENTER;
    font->color = s_defaultColor;

    menuSZK->GetRootContainer()->AddChild(container);

    s_container = container;
}

void BottomMessage::Update()
{
    if (!s_container) return;

    int dt = menuSZK->deltaTime;

    if (Messages.empty()) {
        s_container->text = "";
        return;
    }

    // se nenhuma mensagem atual, mostra a primeira
    if (s_currentIndex < 0 && !Messages.empty()) {
        s_currentIndex = 0;
        s_timer = 0;
        s_container->text = ApplyGtaColorToContainer(s_container, Messages[s_currentIndex].text);
    }

    if (s_currentIndex >= 0 && s_currentIndex < (int)Messages.size()) {
        s_timer += dt;
        auto& msg = Messages[s_currentIndex];

        if (s_timer >= msg.time) {
            s_timer = 0;
            s_currentIndex++;

            if (s_currentIndex >= (int)Messages.size()) {
                // acabou todas
                ClearMessages();
                s_currentIndex = -1;
            } else {
                // próxima
                s_container->text = ApplyGtaColorToContainer(s_container, Messages[s_currentIndex].text);
            }
        }
    }
}

void BottomMessage::AddMessage(const std::string& message, int timeMs)
{
    Messages.push_back({ message, timeMs });
}

void BottomMessage::SetMessage(const std::string& message, int timeMs)
{
    Messages.clear();
    Messages.push_back({ message, timeMs });
    s_timer = 0;
    s_currentIndex = 0;
    if (s_container)
        s_container->text = ApplyGtaColorToContainer(s_container, message);
}

void BottomMessage::ClearMessages()
{
    Messages.clear();
    s_timer = 0;
    if (s_container)
        s_container->text = "";
}