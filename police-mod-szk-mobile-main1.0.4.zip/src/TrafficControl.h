#pragma once

#include "pch.h"

// Sessao apenas: default OFF ao abrir o jogo. Nao salva no ini.
// ON = sem spawn e NPCs/carros parados (exceto abordados e parceiros).
class TrafficControl {
public:
    static void Update();
    static void SetEnabled(bool enabled);
    static bool IsEnabled();
};
