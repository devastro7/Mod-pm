#include "AudioVariationGroup.h"

std::vector<std::string> GetSoundVariants(const std::string& fullPath)
{
    namespace fs = std::filesystem;
    std::vector<std::string> sounds;

    fileLog->Log("[Variants] Checking file: " + fullPath);

    fs::path path(fullPath);

    // Normaliza barras duplicadas no caminho (Android às vezes gera //)
    std::string normalized = fullPath;
    while (normalized.find("//") != std::string::npos)
    {
        size_t p = normalized.find("//");
        // preserva prefixo de URI tipo file:// se existir
        if (p == 0 || (p >= 1 && normalized[p - 1] == ':'))
        {
            // evita destruir "file://" — só colapsa a partir daí
            size_t start = (p >= 1 && normalized[p - 1] == ':') ? p + 2 : p;
            while (start + 1 < normalized.size() && normalized[start] == '/' && normalized[start + 1] == '/')
                normalized.erase(start, 1);
            if (normalized.find("//", start) == std::string::npos)
                break;
            continue;
        }
        normalized.replace(p, 2, "/");
    }
    path = fs::path(normalized);

    if (!fs::exists(path))
    {
        // tenta o caminho original também
        if (!fs::exists(fs::path(fullPath)))
        {
            fileLog->Error("[Variants] ❌ Base file NOT FOUND: " + normalized);
            return sounds;
        }
        path = fs::path(fullPath);
        normalized = fullPath;
    }

    // Remove extensão para poder gerar shootout2.wav, 3.wav...
    std::string baseName = path.replace_extension().string();
    std::string ext = ".wav";

    fileLog->Log("[Variants] Base name: " + baseName);
    fileLog->Log("[Variants] Extension: " + ext);

    // 🔹 Carrega o arquivo original primeiro
    fileLog->Log("[Variants] ✔ Loaded original");
    sounds.push_back(normalized);

    // 🔹 Começa procurar as variantes seguindo padrão *2.wav, *3.wav, ...
    for (int i = 2; ; i++)
    {
        std::string candidate = baseName + std::to_string(i) + ext;

        fileLog->Log("[Variants] Checking: " + candidate);

        if (!fs::exists(candidate))
        {
            fileLog->Error("[Variants] ❌ Not found. Stopping.");
            break;
        }

        fileLog->Log("[Variants] ✔ Found variant");
        sounds.push_back(candidate);
    }

    fileLog->Log("[Variants] Total loaded = " + std::to_string(sounds.size()));
    return sounds;
}

IAudio* AudioVariationGroup::GetRandomAudio()
{
    if (audios.empty())
        return nullptr;

    // Gera um índice aleatório válido
    int index = getRandomNumber(0, static_cast<int>(audios.size()) - 1);

    auto audio = audios[index];
    
    return audio;
}

IAudio* AudioVariationGroup::PlayRandom()
{
    auto audio = GetRandomAudio();
    
    if (audio)
        audio->Play();

    return audio;
}

void AudioVariationGroup::LoadNewAudio(std::string src, bool in3d)
{
    IAudio* audio = nullptr;

    if (in3d)
        audio = menuSZK->Load3DAudio(src);

    // Fallback: se 3D falhar (ou in3d=false), tenta áudio 2D normal
    if (!audio)
        audio = menuSZK->LoadAudio(src);

    if (!audio)
    {
        fileLog->Error("[AudioVariationGroup] Error loading audio (3D e 2D): " + src);
        return;
    }

    audios.push_back(audio);
    fileLog->Log("[AudioVariationGroup] Registered audio: " + src);
}

void AudioVariationGroup::FindAndLoadAudioVariants(std::string src, bool in3d)
{
    auto variants = GetSoundVariants(src);

    if (variants.empty())
    {
        fileLog->Error("[AudioVariationGroup] Nenhum arquivo de audio encontrado para: " + src);
        return;
    }

    for (auto variant : variants)
    {
        LoadNewAudio(variant, in3d);
    }

    if (audios.empty())
        fileLog->Error("[AudioVariationGroup] Grupo ficou vazio apos tentar carregar: " + src);
}
