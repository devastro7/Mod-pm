#pragma once

#include "pch.h"
#include "Vehicle.h"
#include "PoliceVehicleData.h"
#include <vector>
#include <map>

// Comboio / Apoio — viaturas com CAR_FOLLOW_CAR; heli com FOLLOW ou ORBIT (portado do mod antigo).
class DualPatrol {
public:
    static std::vector<Vehicle*> escortVehicles;

    static int selectedVehicleIndex;
    static int selectedHeliIndex;
    static float followDistance;
    static bool showBlips;
    static bool followOnFoot;        // seguir a pe quando jogador desce (config do menu/ini)
    static int selectedOccupants;      // 1..4 policiais na viatura
    static int selectedSkinIndex;      // indice da farda (apoioP.ini / skins)
    static int selectedRemapIndex;     // 0=Padrao, 1=Aleatorio, 2+=remap do MultiRemap
    static int selectedHeliRemapIndex;

    // Menu heli (igual antigo, adaptado)
    static int selectedHeliMode;       // 0=follow, 1=orbit, 2=orbit lock
    static int selectedHeliHeight;     // 50..150 ou 999=variavel
    static int selectedHeliRadius;     // 10..150 ou 999=variavel
    static int selectedHeliSpeed;      // 10..200
    static int selectedHeliAngle;      // 0..60 step 5 (bank)
    static int selectedHeliDirection;  // 0=anti-horario, 1=horario

    // Auto Heli pós-ocorrência
    static bool autoHeliEnabled;
    static int autoHeliOrbitSeconds;   // 5..20 step 5 (tempo orbitando antes de ir embora)

    static void Initialize();
    static void Update(int dt);
    static void LoadSettings();
    static void SaveSettings();

    static void CreateMenu();
    static void CreateHeliMenu();

    static void SpawnEscortUnit(PoliceVehicleData* unit, bool forceHelicopter = false);
    static void SpawnEscortHeli(PoliceVehicleData* unit);
    // Orbit lock fixo em coordenada (assalto a banco etc.)
    static void SpawnOrbitLockHeliAt(CVector center, int vehicleModelId, int heightMenu, int radiusMenu, int speedMenuOrVar, int angleDeg, bool clockwise);
    static void StartBankHeliLeave();
    static void SpawnAutoHeliAfterCallout();
    static void RemoveAll();
    static void RemoveVehiclesOnly();
    static void RemoveHelisOnly();
    static bool HasAnyUnit();

    static void CheckIfVehiclesAreValid();
    static void UpdateSirenSync();
};
