#include "Partners.h"

#include "BottomMessage.h"
#include "Weapons.h"
#include "Skins.h"
#include "CleoFunctions.h"
#include "Peds.h"
#include "ModelLoader.h"
#include "OptionsWindow.h"

int g_currentSelectedSkinIndex = 0;
int g_currentSelectedWeaponIndex = 0;

std::vector<Ped*> g_allPartners;

void Partners::CreateSpawnPartnerMenu()
{
    ReloadPoliceSkinsFromApoioP();

    auto window = menuSZK->CreateWindow(400, 200, 800, "Parceiros");

    {
        auto options = window->AddOptions("Skin ID");
        options->onOptionChange->Add([options]() {
            auto value = options->GetCurrentOptionValue();
            g_currentSelectedSkinIndex = value;
        });

        for (size_t i = 0; i < g_policeSkins.size(); i++)
        {
            auto skinInfo = g_policeSkins[i];

            options->AddOption(skinInfo.name + " (" + std::to_string(skinInfo.id) + ")", (int)i);
        }
        options->SetOptionIndex(0);
    }

    {
        auto options = window->AddOptions("Weapon ID");
        options->onOptionChange->Add([options]() {
            auto value = options->GetCurrentOptionValue();
            g_currentSelectedWeaponIndex = value;
        });

        for (size_t i = 0; i < g_weaponList.size(); i++)
        {
            auto weaponInfo = g_weaponList[i];
            options->AddOption(weaponInfo.name, i);
        }
        options->SetOptionIndex(0);
    }

    {
        auto button = window->AddButton(GetTranslatedText("spawn_partner"));
        button->onClick->Add([]() {
            // Menu permanece aberto — só fecha no botão Voltar
            auto spawnPosition = GetPedPositionWithOffset(GetPlayerActor(), CVector(0, 1, 0));
            SpawnPartner(spawnPosition);
        });
    }

    {
        auto button = window->AddButton(GetTranslatedText("remove_partners"));
        button->onClick->Add([]() {
            // Menu permanece aberto — só fecha no botão Voltar
            DestroyPartners();
        });
    }

    {
        auto button = window->AddButton("~y~Voltar");
        button->onClick->Add([window]() {
            window->Close();
            OptionsWindow::OpenWindow();
        });
    }
}

void Partners::SpawnPartner(CVector position)
{
    fileLog->Log("Partners: SpawnPartner");
    ReloadPoliceSkinsFromApoioP();

    if (g_policeSkins.empty()) ReloadPoliceSkinsFromApoioP();
    if (g_currentSelectedSkinIndex < 0) g_currentSelectedSkinIndex = 0;
    if (g_currentSelectedSkinIndex >= (int)g_policeSkins.size())
        g_currentSelectedSkinIndex = 0;
    auto skinInfo = g_policeSkins[g_currentSelectedSkinIndex];
    auto weaponInfo = g_weaponList[g_currentSelectedWeaponIndex];

    fileLog->Log("weapon " + weaponInfo.name);
    fileLog->Log("skin " + skinInfo.name);

    // allowSpecial=true: permite 288 e outros do apoioP.ini (como no 1.0.2)
    ModelLoader::AddModelToLoad(skinInfo.id, true); // qualquer ped do apoioP.ini
    ModelLoader::AddModelToLoad(weaponInfo.modelId, true);

    ModelLoader::LoadAll([skinInfo, weaponInfo, position]() {
        if (!HAS_MODEL_LOADED(skinInfo.id))
        {
            fileLog->Error("Partners: modelo " + std::to_string(skinInfo.id) + " nao carregou — spawn cancelado");
            BottomMessage::SetMessage("~r~Falha ao carregar skin " + std::to_string(skinInfo.id), 3500);
            return;
        }

        auto pedRef = CREATE_ACTOR_PEDTYPE(PedType::Gang2, skinInfo.id, position.x, position.y, position.z);
        if (!ACTOR_DEFINED(pedRef))
        {
            BottomMessage::SetMessage("~r~Falha ao criar parceiro", 3000);
            return;
        }
        auto ped = Peds::RegisterPed(pedRef);

        REMOVE_REFERENCES_TO_ACTOR(pedRef);

        g_allPartners.push_back(ped);

        auto playerActor = GET_PLAYER_ACTOR(0);
        auto playerGroup = GET_PLAYER_GROUP(0);

        PUT_ACTOR_IN_GROUP_AS_LEADER(pedRef, playerActor);
        PUT_ACTOR_IN_GROUP(playerGroup, pedRef);

        GIVE_ACTOR_WEAPON(pedRef, weaponInfo.weaponId, 10000);
        SET_ACTOR_HEALTH(pedRef, 500.0f);
    });
}

void Partners::DestroyPartners()
{
    for(auto ped : g_allPartners)
    {
        ped->QueueDestroy();
    }

    g_allPartners.clear();
}

std::vector<Ped*>& Partners::GetPartners()
{
    return g_allPartners;
}

Ped* Partners::GetClosestPartnerOnFoot(CVector nearPos)
{
    Ped* best = nullptr;
    double bestDist = 999999.0;
    for (auto ped : g_allPartners)
    {
        if (!ped || !Peds::IsValid(ped) || !ACTOR_DEFINED(ped->ref)) continue;
        if (IS_CHAR_IN_ANY_CAR(ped->ref)) continue;
        auto pp = GetPedPosition(ped->ref);
        double d = distanceBetweenPoints(pp, nearPos);
        if (d < bestDist) { bestDist = d; best = ped; }
    }
    return best;
}
