#pragma once

#include "pch.h"

class CalloutConfigWindow {
public:
    static void OpenWindow();
};
