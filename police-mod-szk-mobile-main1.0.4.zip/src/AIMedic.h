#pragma once

#include "pch.h"
#include "AIPed.h"
#include "Ped.h"

class AIMedic : public AIPed {
public:
    CVector targetPosition = CVector();

    int targetPedRef = -1;
    std::vector<int> targetPeds;

    bool isDrivingAway = false;
    bool leftOnce = false;
    bool isIML = false; // true = Instituto Médico Legal (foto + remove corpo)

    ~AIMedic() override;

    void Start() override;
    void Update() override;

    void FindTarget();

    void DoAction();

    void AproachPed(Ped* ped);
    void RessurectPed(Ped* ped);
    void ProcessIMLBody(Ped* deadPed);

    static bool AllMedicsAreDone(int vehicleRef);
};