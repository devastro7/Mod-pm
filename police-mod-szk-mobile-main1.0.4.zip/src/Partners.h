#pragma once

#include "pch.h"
#include "Ped.h"
#include <vector>

class Partners {
public:
    static void CreateSpawnPartnerMenu();
    static void SpawnPartner(CVector position);
    static void DestroyPartners();
    static std::vector<Ped*>& GetPartners();
    static Ped* GetClosestPartnerOnFoot(CVector nearPos);
};
