#include "InventoryItemManager.h"
#include "IniReaderWriter.hpp"
#include "ModData.h"
#include "Logger.h"
#include <filesystem>

std::unordered_map<std::string, std::shared_ptr<ItemDefinition>> InventoryItemManager::itemDefinitions;
std::unordered_map<std::string, std::shared_ptr<ItemDefinition>> InventoryItemManager::carItemDefinitions;

void InventoryItemManager::Initialize()
{
    LoadItems();
    LoadCarItems();
}

static void LoadFromFolder(const std::string& folder, std::unordered_map<std::string, std::shared_ptr<ItemDefinition>>& out)
{
    if (!std::filesystem::exists(folder))
    {
        ModData::CreateFolder(folder);
        return;
    }

    IniReaderWriter ini;
    try
    {
        for (const auto& entry : std::filesystem::directory_iterator(folder))
        {
            if (!entry.is_regular_file()) continue;
            if (entry.path().extension() != ".ini") continue;

            std::string path = entry.path().string();
            std::string id = entry.path().stem().string();
            if (!ini.LoadFromFile(path)) continue;

            auto itemDef = std::make_shared<ItemDefinition>();
            itemDef->name = ini.Get("item", "name", id);
            itemDef->description = ini.Get("item", "description", "No description");
            itemDef->chance = ini.GetDouble("item", "chance", 1.00);
            itemDef->maxAmount = ini.GetInt("item", "max_amount", 1);
            itemDef->isIllegal = ini.GetBool("item", "is_illegal", false);
            itemDef->flags = ini.Get("item", "flags", "");
            itemDef->isStolen = ini.GetBool("item", "is_stolen", false);
            itemDef->amountFormat = ini.Get("item", "amount_format", "");
            out[id] = itemDef;
        }
    }
    catch (const std::exception& e)
    {
        fileLog->Log(std::string("InventoryItemManager error: ") + e.what());
    }
}

void InventoryItemManager::LoadItems()
{
    itemDefinitions.clear();
    auto itemsFolder = modData->GetFile("data/items");
    ModData::CreateFolder(modData->GetFile("data"));
    ModData::CreateFolder(itemsFolder);
    LoadFromFolder(itemsFolder, itemDefinitions);
    fileLog->Log("InventoryItemManager: " + std::to_string(itemDefinitions.size()) + " ped items");
}

void InventoryItemManager::LoadCarItems()
{
    carItemDefinitions.clear();
    auto folder = modData->GetFile("data/revista_carro");
    ModData::CreateFolder(modData->GetFile("data"));
    ModData::CreateFolder(folder);
    LoadFromFolder(folder, carItemDefinitions);

    if (carItemDefinitions.empty())
    {
        struct Def { const char* id; const char* name; double chance; int maxAmount; bool illegal; };
        Def defaults[] = {
            { "documento_veiculo", "Documento do veiculo", 0.80, 1, false },
            { "ferramentas", "Ferramentas", 0.25, 1, false },
            { "arma_ilegal", "Arma ilegal", 0.08, 1, true },
            { "drogas", "Drogas", 0.12, 3, true },
            { "dinheiro", "Dinheiro", 0.30, 500, false },
        };
        for (const auto& d : defaults)
        {
            std::string path = std::string(folder) + "/" + d.id + ".ini";
            IniReaderWriter ini;
            ini.Set("item", "name", d.name);
            ini.Set("item", "description", d.name);
            ini.SetDouble("item", "chance", d.chance);
            ini.SetInt("item", "max_amount", d.maxAmount);
            ini.SetBool("item", "is_illegal", d.illegal);
            ini.Set("item", "flags", "can_spawn_on_any_car");
            ini.SaveToFile(path);

            auto itemDef = std::make_shared<ItemDefinition>();
            itemDef->name = d.name;
            itemDef->description = d.name;
            itemDef->chance = d.chance;
            itemDef->maxAmount = d.maxAmount;
            itemDef->isIllegal = d.illegal;
            itemDef->flags = "can_spawn_on_any_car";
            carItemDefinitions[d.id] = itemDef;
        }
    }
    fileLog->Log("InventoryItemManager: " + std::to_string(carItemDefinitions.size()) + " car items");
}
