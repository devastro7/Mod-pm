#pragma once

#include "pch.h"

class ModelLoader {
private:
    static std::vector<int> modelsToLoad;
    static std::vector<bool> modelsAllowAny;
    static std::function<void()> onLoadAllCallback;
public:
    // allowAnyPed=true: carrega QUALQUER ped/modelo id > 0 (parceiros, comboio, apoioP.ini)
    static void AddModelToLoad(int modelId, bool allowAnyPed = false);
    static void LoadAll(std::function<void()> callback);
    static bool IsSpecialModel(int id);
    static bool IsValidModelId(int modelId, bool allowAnyPed = false);
private:
    static void LoadNextModel();
    static void ModelLoaded(int modelId);
};
