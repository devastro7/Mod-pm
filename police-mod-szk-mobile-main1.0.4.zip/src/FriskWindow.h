#pragma once

#include "pch.h"
#include "Ped.h"
#include "Vehicle.h"

class FriskWindow {
public:
    static void OpenForPed(Ped* ped);
    static void OpenForVehicle(Vehicle* vehicle);
};
