#pragma once

#include "pch.h"
#include "Vehicle.h"

#include <string>
#include <vector>
#include <map>
#include <set>

struct FineData {
    std::string id;     // nome do arquivo .ini
    std::string name;   // nome exibido
    float chance = 0.10f;
};

struct RolledFine {
    int fineIndex = -1;
    bool selected = false;
};

// Historico por veiculo (limpo quando o carro some)
struct VehicleFineHistory {
    bool hasRolled = false;
    std::vector<int> rolledIndices;
    std::set<std::string> appliedIds;
};

class TicketWindow {
public:
    static constexpr int MAX_FINES = 3; // ate 3 multas

    static std::vector<FineData> m_FineDatas;
    static std::vector<RolledFine> m_RolledFines;
    static bool m_FinesLoaded;
    static Vehicle* m_Vehicle;
    static std::map<int, VehicleFineHistory> m_HistoryByVehicle; // key = vehicle ref

    static void EnsureFinesFolderAndDefaults();
    static void LoadFines();
    static void Open(Vehicle* vehicle);
    static void ApplySelectedFines();
    static void ClearVehicleHistory(int vehicleRef);
};
