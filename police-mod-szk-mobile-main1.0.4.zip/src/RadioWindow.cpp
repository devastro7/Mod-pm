#include "RadioWindow.h"

#include "BottomMessage.h"
#include "Chase.h"
#include "CleoFunctions.h"
#include "BackupUnits.h"
#include "Callouts.h"
#include "TestWindow.h"
#include "OptionsWindow.h"
#include "RadioConfigWindow.h"
#include "CalloutConfigWindow.h"
#include "RadioExtrasWindow.h"
#include "ModelLoader.h"
#include "RadioSounds.h"
#include "DispatchPanel.h"
#include "Logger.h"
#include "NearbyStolenSystem.h"
#include <filesystem>

IContainer* RadioWindow::MainContainer = nullptr;
IContainer* RadioWindow::ScreenContainer = nullptr;

bool RadioWindow::m_cancelServices = false;

std::map<std::string, RadioScreenGroup> RadioWindow::groups;

std::string RadioWindow::currentGroupId;

int RadioWindow::currentScreenIndex = 0;

bool g_isWaitingForRadio = false;
static IContainer* g_acceptButton = nullptr;


static void SafeSetBg(IContainer* c, const std::string& relativePath)
{
    if (!c) return;
    std::string path = modData->GetFileFromAssets(relativePath);
    if (std::filesystem::exists(path))
    {
        c->SetBackgroundImage(path);
    }
    else
    {
        // fallback: fundo solido pra nao crashar CSprite2d com textura nula
        c->drawBackground = true;
        c->backgroundColor = CRGBA(40, 40, 40, 220);
        fileLog->Log("RadioWindow: textura ausente, usando fallback: " + relativePath);
    }
}

void RadioWindow::Initialize()
{
    auto container = menuSZK->CreateContainer("radio");
    container->localOffset = CVector2D(400, 170);
    container->size = CVector2D(600, 1000);
    container->horizontalAlign = HorizontalAlign::Left;
    container->verticalAlign = VerticalAlign::Bottom;
    container->drawBackground = false;
    container->clickThroughMode = ClickThroughMode::ClickThroughThisOnly;
    SafeSetBg(container, "radio/radio.png");
    menuSZK->GetRootContainer()->AddChild(container);

    MainContainer = container;

    {
        auto container = menuSZK->CreateContainer("up");
        container->localOffset = CVector2D(450, 450);
        container->size = CVector2D(100, 100);
        container->horizontalAlign = HorizontalAlign::Left;
        container->verticalAlign = VerticalAlign::Top;
        container->drawBackground = false;
        SafeSetBg(container, "radio/button_up.png");
        MainContainer->AddChild(container);

        container->onClick->Add([] () {
            PrevScreen();
        });
    }

    {
        auto container = menuSZK->CreateContainer("down");
        container->localOffset = CVector2D(450, 570);
        container->size = CVector2D(100, 100);
        container->horizontalAlign = HorizontalAlign::Left;
        container->verticalAlign = VerticalAlign::Top;
        container->drawBackground = false;
        SafeSetBg(container, "radio/button_down.png");
        MainContainer->AddChild(container);

        container->onClick->Add([] () {
            NextScreen();
        });
    }

    // Botao aceitar ocorrencia (abaixo do down, mesmo espacamento vertical 120)
    {
        auto container = menuSZK->CreateContainer("accept_callout");
        container->localOffset = CVector2D(450, 690);
        container->size = CVector2D(100, 100);
        container->horizontalAlign = HorizontalAlign::Left;
        container->verticalAlign = VerticalAlign::Top;
        container->drawBackground = false;
        SafeSetBg(container, "radio/button_accept.png");
        container->isVisible = false; // so aparece quando houver callout para aceitar
        MainContainer->AddChild(container);
        g_acceptButton = container;

        container->onClick->Add([] () {
            if (Callouts::HasCalloutToAccept())
            {
                Callouts::AcceptCallout();
                if (g_acceptButton)
                    g_acceptButton->isVisible = false;
            }
        });
    }

    {
        auto container = menuSZK->CreateContainer("select");
        container->localOffset = CVector2D(20, 530);
        container->size = CVector2D(100, 100);
        container->horizontalAlign = HorizontalAlign::Left;
        container->verticalAlign = VerticalAlign::Top;
        container->drawBackground = false;
        SafeSetBg(container, "radio/button_select.png");
        MainContainer->AddChild(container);

         container->onClick->Add([] () {
            Select();
        });
    }

    {
        auto container = menuSZK->CreateContainer("close");
        container->localOffset = CVector2D(20, 720);
        container->size = CVector2D(100, 100);
        container->horizontalAlign = HorizontalAlign::Left;
        container->verticalAlign = VerticalAlign::Top;
        container->drawBackground = false;
        SafeSetBg(container, "radio/button_close.png");
        MainContainer->AddChild(container);

        container->onClick->Add([] () {
            Back();
        });
    }

    {
        auto container = menuSZK->CreateContainer("radio_image");
        container->localOffset = CVector2D(198, 576);
        container->size = CVector2D(180, 170);  
        container->horizontalAlign = HorizontalAlign::Left;
        container->verticalAlign = VerticalAlign::Top;
        container->drawBackground = true;
        MainContainer->AddChild(container);

        ScreenContainer = container;
    }

    AddGroup("main", "");
    currentGroupId = "main";
    currentScreenIndex = 0;

    AddScreen("main", "send_qth", "send_qth.png");
    AddScreen("main", "call_helicopter", "call_helicopter.png");
    AddScreen("main", "callout_menu", "callout_menu.png");
    AddScreen("main", "cancel_chase", "cancel_chase.png");
    AddScreen("main", "cancel_services", "cancel_services.png");
    AddScreen("main", "call_backup", "call_backup.png");
    AddScreen("main", "emergence", "emergence.png"); // submenu resgate + IML
    AddScreen("main", "toggle_car_options", "toggle_car_options.png");
    AddScreen("main", "test_menu", "test_menu.png");
    AddScreen("main", "options_menu", "optionsT.png");
    AddScreen("main", "radio_configs", "radio_configs.png");
    AddScreen("main", "options_extras", "optionsextras.png");

    
    // AddGroup("test", "main");

    // AddScreen("test", "test1", "test.png");
    // AddScreen("test", "test2", "test.png");
    // AddScreen("test", "test3", "test.png");

    AddGroup("callout", "main");

    AddScreen("callout", "callout_accept", "callout_accept.png");
    // PNG em assets/radio/screens/consult_callout.png
    AddScreen("callout", "consult_callout", "consult_callout.png");
    // PNG em assets/radio/screens/config_callout.png
    AddScreen("callout", "config_callout", "config_callout.png");

    // Submenu emergência
    AddGroup("emergence", "main");
    AddScreen("emergence", "call_medic", "call_medic.png");
    AddScreen("emergence", "call_iml", "call_iml.png");
    AddScreen("emergence", "call_firemen", "call_firemen.png");

    UpdateScreenContainer();
    
    MainContainer->isVisible = false;
}

void RadioWindow::Toggle()
{
    bool visible = !MainContainer->isVisible;

    MainContainer->isVisible = visible;

    if(visible)
    {
        ToggleRadioAnim(true);
    } else {
        if(g_isWaitingForRadio) return;
        ToggleRadioAnim(false);
    }
}

void RadioWindow::OnSelect(std::string id)
{
    if(id == "send_qth")
    {
        ToggleRadioAnimOff(5000);
        Toggle();
        BackupUnits::SendQTH();
        return;
    }

    if(id == "call_helicopter")
    {
        ToggleRadioAnimOff(5000);
        Toggle();

        BottomMessage::SetMessage("Chamando apoio do aguia...", 3000);

        BackupUnits::SpawnHelicopterBackup();
        return;
    }

    if(id == "callout_menu")
    {
        SwitchToGroup("callout");
        return;
    }

    if(id == "cancel_chase")
    {
        Toggle();
        // Cancela chamado pendente (blip amarelo) ou ocorrencia ativa
        // Nao apaga carros civis nem comboio DualPatrol
        Callouts::CancelPendingOrActive();
        Chase::AbortChase();
        return;
    }

    if(id == "cancel_services")
    {
        m_cancelServices = true;
        Toggle();

        WAIT(1000, []() {
            m_cancelServices = false;
        });

        return;
    }

    if(id == "call_backup")
    {
        Toggle();
        BackupUnits::OpenSpawnBackupMenu();
        return;
    }

    if(id == "emergence")
    {
        SwitchToGroup("emergence");
        return;
    }

    if(id == "call_medic")
    {
        ToggleRadioAnimOff(5000);
        Toggle();

        BottomMessage::SetMessage("Chamando o resgate...", 3000);

        auto audio = audioRequestAmbulance->GetRandomAudio();

        RadioSounds::PlayAudioNowDontAttach(audio);

        WaitForAudioFinish(audio, []() {
            auto playerPosition = GetPlayerPosition();
            
            BackupUnits::SpawnMedicUnit(playerPosition);
        });

        return;
    }

    if(id == "call_iml")
    {
        ToggleRadioAnimOff(5000);
        Toggle();

        BottomMessage::SetMessage("Chamando o IML...", 3000);

        auto audio = audioRequestIML ? audioRequestIML->GetRandomAudio() : nullptr;
        if (audio)
        {
            RadioSounds::PlayAudioNowDontAttach(audio);
            WaitForAudioFinish(audio, []() {
                auto playerPosition = GetPlayerPosition();
                BackupUnits::SpawnIMLUnit(playerPosition);
            });
        }
        else
        {
            auto playerPosition = GetPlayerPosition();
            BackupUnits::SpawnIMLUnit(playerPosition);
        }

        return;
    }

    if(id == "call_firemen")
    {
        ToggleRadioAnimOff(5000);
        Toggle();

        BottomMessage::SetMessage("Chamando os bombeiros...", 3000);

        auto playerPosition = GetPlayerPosition();
        BackupUnits::SpawnFiremenUnit(playerPosition);
        return;
    }

    if(id == "test_menu")
    {
        Toggle();
        TestWindow::OpenWindow();
        return;
    }

    if(id == "callout_accept")
    {
        if(Callouts::HasCalloutToAccept())
        {
            Toggle();
            Callouts::AcceptCallout();
            return;
        }

        BottomMessage::SetMessage("~r~There are no active callouts", 3000);

        return;
    }

    // Consulta: reexibe ocorrencias. Se tiver roubo proximo + outra ocorrencia,
    // mostra a mais antiga primeiro e apos 500ms a mais recente (empilha).
    if(id == "config_callout")
    {
        Toggle();
        CalloutConfigWindow::OpenWindow();
        return;
    }

    if(id == "consult_callout")
    {
        bool hasStolen = NearbyStolenSystem::IsActive();
        bool hasLast = DispatchPanel::HasLast();

        if (!hasStolen && !hasLast)
        {
            BottomMessage::SetMessage("~y~Nenhuma ocorrencia para consultar", 2500);
            return;
        }

        if (hasStolen && hasLast)
        {
            // Mostra a ultima (mais antiga no stack do DispatchPanel) e re-show
            // do painel atual apos 500ms para empilhar as duas janelas.
            DispatchPanel::ShowLast();
            WAIT(500, []() {
                // Re-show empurra a anterior para o slot "prev" e exibe de novo
                if (DispatchPanel::HasLast())
                    DispatchPanel::ShowLast();
            });
            return;
        }

        if (hasStolen || hasLast)
        {
            DispatchPanel::ShowLast();
            return;
        }
        return;
    }

    if(id == "options_menu")
    {
        Toggle();
        OptionsWindow::OpenWindow();
        return;
    }

    if(id == "radio_configs")
    {
        Toggle();
        RadioConfigWindow::OpenWindow();
        return;
    }

    if(id == "options_extras")
    {
        Toggle();
        RadioExtrasWindow::OpenWindow();
        return;
    }

    if(id == "toggle_car_options")
    {
        Toggle();

        g_canShowCarWidgetAnyTime = !g_canShowCarWidgetAnyTime;
        if(g_canShowCarWidgetAnyTime)
        {
            BottomMessage::SetMessage("~g~Ativado ~w~botao de opcoes dos veiculos", 3000);
        } else {
            BottomMessage::SetMessage("~r~Desativado ~w~botao de opcoes dos veiculos", 3000);
        }
        return;
    }

    BottomMessage::SetMessage("~r~No action defined", 1000);
}

int g_radioObject = 0;

void RadioWindow::ToggleRadioAnim(bool state)
{
    if(state == false && g_isWaitingForRadio)
    {
        return;
    }

    if(g_radioObject != 0)
    {
        DESTROY_OBJECT(g_radioObject);
        g_radioObject = 0;
    }

    if(state)
    {
        int radioModelId = 321;

        ModelLoader::AddModelToLoad(radioModelId);
        ModelLoader::LoadAll([radioModelId]() {
            g_radioObject = CREATE_OBJECT(radioModelId, 0, 0, 0);
            ATTACH_TO_OBJECT_AND_PERFORM_ANIMATION(GetPlayerActor(), g_radioObject, 0, 0, 0, 6, 16, "PHONE_TALK", "PED", 1);
        });
    }
}

void RadioWindow::ToggleRadioAnimOff(int timeMs)
{
    g_isWaitingForRadio = true;
    
    WAIT(timeMs, []() {
        g_isWaitingForRadio = false;
        ToggleRadioAnim(false);
    });
}

void RadioWindow::UpdateAcceptButton()
{
    if (!g_acceptButton || !MainContainer)
        return;
    // So aparece se o radio estiver visivel E houver ocorrencia para aceitar
    bool show = MainContainer->isVisible && Callouts::HasCalloutToAccept();
    g_acceptButton->isVisible = show;
}
