#include "AIHelicopterCop.h"

#include "CleoFunctions.h"
#include "Criminals.h"
#include "Peds.h"
#include "Vehicles.h"
#include "BottomMessage.h"
#include "ScriptTask.h"

AIHelicopterCop::~AIHelicopterCop()
{

}

void AIHelicopterCop::Start()
{
    menuDebug->AddLine("AIHelicopterCop started");

    FindTarget();
    DoAction();
} 

void AIHelicopterCop::Update()
{
    if(isLeaving) return;
    if(!ACTOR_DEFINED(pedRef)) return;

    timer_findTarget += menuSZK->deltaTime;

    if(timer_findTarget > 3000)
    {
        timer_findTarget = 0;

        FindTarget();
        DoAction();
    }
}

void AIHelicopterCop::FindTarget()
{
    fileLog->Log("AICop: FindTarget");

    targetCriminal = -1;
    timer_findTarget = 0;

    // garante que o próprio cop exista
    auto selfPed = Peds::GetPed(pedRef);
    if (!selfPed) return;

    auto criminals = *Criminals::GetCriminals();
    if (criminals.empty()) return;

    Ped* nearestFree = nullptr;   // não surrender / não inconcious
    float nearestFreeDist = std::numeric_limits<float>::max();

    Ped* nearestAny = nullptr;    // qualquer um (fallback)
    float nearestAnyDist = std::numeric_limits<float>::max();

    auto selfPos = selfPed->GetPosition();

    for (auto crim : criminals)
    {
        if (!crim) continue;

        // tenta obter o Ped do criminoso
        auto crimPed = Peds::GetPed(crim->ref);
        if (!crimPed) continue;

        float dist = distanceBetweenPoints(selfPos, crimPed->GetPosition());

        // mantem o mais próximo de todos (fallback)
        if (dist < nearestAnyDist)
        {
            nearestAnyDist = dist;
            nearestAny = crim;
        }
    
        // considera apenas os que NÃO estão surrender ou inconcious
        if (!crim->flags.hasSurrended && !crim->flags.isInconcious)
        {
            if (dist < nearestFreeDist)
            {
                nearestFreeDist = dist;
                nearestFree = crim;
            }
        }
    }

    // prefere o nearestFree; caso não exista, usa nearestAny
    if (nearestFree)
        targetCriminal = nearestFree->ref;
    else if (nearestAny)
        targetCriminal = nearestAny->ref;
    // caso não tenha nenhum válido, targetPed já é -1
}

void AIHelicopterCop::DoAction()
{
    fileLog->Log("AIHelicopterCop: DoAction");
    
    auto cop = Peds::GetPed(pedRef);
    
    if(cop->isEnteringCar || cop->isLeavingCar) return;
    
    auto copVehicle = Vehicles::GetVehicle(cop->previousVehicle);
    
    menuDebug->AddLine("~b~cop do action");

    if(targetCriminal > 0)
    {
        if(copVehicle)
        {
            HELI_FOLLOW(copVehicle->ref, targetCriminal, -1, 16.0f);
        }
    } else {
        if(copVehicle)
        {
            if(!isLeaving)
            {
                isLeaving = true;

                // Saida gradual: sobe e aumenta o "raio" (distancia do player) enquanto
                // reduz a velocidade maxima na mesma proporcao.
                struct LeaveState {
                    Vehicle* vehicle = nullptr;
                    float progress = 0.0f;      // 0..1
                    float startSpeed = 40.0f;
                    float endSpeed = 8.0f;
                    float startAlt = 40.0f;
                    float endAlt = 220.0f;
                    CVector startPos{};
                    CVector awayDir{};
                };

                auto* st = new LeaveState();
                st->vehicle = copVehicle;
                st->startPos = GetCarPosition(copVehicle->ref);

                CVector playerPos = GetPlayerPosition();
                float dx = st->startPos.x - playerPos.x;
                float dy = st->startPos.y - playerPos.y;
                float len = sqrt(dx * dx + dy * dy);
                if (len < 1.0f) { dx = 1.0f; dy = 0.0f; len = 1.0f; }
                st->awayDir.x = dx / len;
                st->awayDir.y = dy / len;
                st->awayDir.z = 0.0f;

                // Velocidade inicial mais alta, depois desacelera conforme sobe/afasta
                SET_CAR_MAX_SPEED(copVehicle->ref, st->startSpeed);

                ScriptTask* taskLeave = new ScriptTask("task_heli_leave");
                taskLeave->onBegin = [st]() {
                    BottomMessage::SetMessage("O aguia esta saindo", 3000);

                    float alt = st->startAlt;
                    float dist = 30.0f;
                    float tx = st->startPos.x + st->awayDir.x * dist;
                    float ty = st->startPos.y + st->awayDir.y * dist;
                    float tz = st->startPos.z + alt;
                    HELI_FLY_TO(st->vehicle->ref, tx, ty, tz, alt * 0.5f, alt);
                };
                taskLeave->onExecute = [st]() {
                    if (!st || !Vehicles::IsValid(st->vehicle))
                    {
                        delete st;
                        return SCRIPT_CANCEL;
                    }

                    // ~8s para completar a saida gradual (progress 0->1)
                    const float durationMs = 8000.0f;
                    int dt = menuSZK ? menuSZK->deltaTime : 50;
                    st->progress += (float)dt / durationMs;
                    if (st->progress > 1.0f) st->progress = 1.0f;

                    // Velocidade cai na mesma proporcao que altitude/raio sobem
                    float speed = st->startSpeed + (st->endSpeed - st->startSpeed) * st->progress;
                    float alt = st->startAlt + (st->endAlt - st->startAlt) * st->progress;
                    float radius = 30.0f + 200.0f * st->progress; // raio/distancia aumenta

                    SET_CAR_MAX_SPEED(st->vehicle->ref, speed);

                    float tx = st->startPos.x + st->awayDir.x * radius;
                    float ty = st->startPos.y + st->awayDir.y * radius;
                    float tz = st->startPos.z + alt;
                    HELI_FLY_TO(st->vehicle->ref, tx, ty, tz, alt * 0.4f, alt);

                    auto pos = GetCarPosition(st->vehicle->ref);
                    auto distance = DistanceFromPed(GetPlayerActor(), pos);

                    // Termina quando longe o suficiente ou progress completo + distancia
                    if (st->progress >= 1.0f && distance > 150.0f)
                        return SCRIPT_SUCCESS;
                    if (distance > 280.0f)
                        return SCRIPT_SUCCESS;

                    return SCRIPT_KEEP_GOING;
                };
                taskLeave->onComplete = [st]() {
                    BottomMessage::SetMessage("O aguia sumiu", 3000);

                    if (st && Vehicles::IsValid(st->vehicle))
                    {
                        st->vehicle->QueueDestroy(true);
                    }
                    delete st;
                };
                taskLeave->Start();
            }
        }
    }
}
