#include "AIFireman.h"

#include "CleoFunctions.h"
#include "Peds.h"
#include "Vehicles.h"
#include "ScriptTask.h"
#include "BottomMessage.h"
#include "AIController.h"

AIFireman::~AIFireman()
{
}

void AIFireman::Start()
{
    fileLog->Log("AIFireman: Start");

    auto fireman = Peds::GetPed(pedRef);
    if (!fireman) return;

    if (!fireman->IsDriver())
        return;

    auto vehicle = Vehicles::GetVehicle(fireman->GetCurrentCar());
    if (!vehicle || !CAR_DEFINED(vehicle->ref))
        return;

    ScriptTask* taskDrive = new ScriptTask("fireman_drive");
    int* pDriveReissue = new int(0);
    taskDrive->onBegin = [this, vehicle]() {
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
            return;
        SET_CAR_MAX_SPEED(vehicle->ref, 28.0f);
        SET_CAR_TRAFFIC_BEHAVIOUR(vehicle->ref, DrivingMode::AvoidCars);
        CAR_DRIVE_TO(vehicle->ref, targetPosition.x, targetPosition.y, targetPosition.z);
        ENABLE_CAR_SIREN(vehicle->ref, true);
    };
    taskDrive->onExecute = [this, vehicle, pDriveReissue]() {
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref)) {
            delete pDriveReissue;
            return SCRIPT_CANCEL;
        }

        auto distance = DistanceFromVehicle(vehicle->ref, targetPosition);
        if (distance < 14.0f) {
            delete pDriveReissue;
            return SCRIPT_SUCCESS;
        }

        // Reemite destino a cada 2s
        *pDriveReissue += menuSZK ? menuSZK->deltaTime : 50;
        if (*pDriveReissue >= 2000)
        {
            *pDriveReissue = 0;
            SET_CAR_MAX_SPEED(vehicle->ref, 28.0f);
            SET_CAR_TRAFFIC_BEHAVIOUR(vehicle->ref, DrivingMode::AvoidCars);
            CAR_DRIVE_TO(vehicle->ref, targetPosition.x, targetPosition.y, targetPosition.z);
            ENABLE_CAR_SIREN(vehicle->ref, true);
        }

        return SCRIPT_KEEP_GOING;
    };
    taskDrive->onCancel = []() {};
    taskDrive->onComplete = [this, vehicle]() {
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
            return;

        SET_CAR_MAX_SPEED(vehicle->ref, 0.0f);
        ENABLE_CAR_SIREN(vehicle->ref, true);
        hasArrived = true;
        fileLog->Log("AIFireman: chegou no local");
        // Única mensagem de chegada
        BottomMessage::SetMessage("~b~Bombeiros no local", 2500);
    };
    taskDrive->Start();
}

void AIFireman::Update()
{
    if (!ACTOR_DEFINED(pedRef))
        return;

    auto fireman = Peds::GetPed(pedRef);
    if (!fireman || !fireman->IsDriver())
        return;

    if (!hasArrived || leaveScheduled || isLeaving || isSpraying)
        return;

    auto truck = Vehicles::GetVehicle(fireman->GetCurrentCar());
    if (!truck || !CAR_DEFINED(truck->ref))
    {
        truck = Vehicles::GetVehicle(fireman->previousVehicle);
        if (!truck || !CAR_DEFINED(truck->ref))
            return;
    }

    ENABLE_CAR_SIREN(truck->ref, true);

    Vehicle* wreck = FindWreckOrBurningNearby(50.0f);

    if (wreck)
    {
        SprayAndExtinguish(wreck, truck);
        return;
    }

    // Única mensagem quando não acha incêndio
    leaveScheduled = true;
    BottomMessage::SetMessage("~y~Nenhum incendio encontrado", 2500);
    WAIT(10000, [this, truck]() {
        LeaveScene(truck);
    });
}

Vehicle* AIFireman::FindWreckOrBurningNearby(float radius)
{
    auto fireman = Peds::GetPed(pedRef);
    if (!fireman) return nullptr;

    CVector origin = fireman->GetPosition();
    Vehicle* best = nullptr;
    float bestDist = radius;
    int bestScore = -1;

    auto consider = [&](Vehicle* car, float d) {
        if (!car || !Vehicles::IsValid(car) || !CAR_DEFINED(car->ref))
            return;
        if (car->GetModelId() == 407)
            return;
        if (d > radius)
            return;

        bool onFire = IS_CAR_ON_FIRE(car->ref);
        bool dead = IS_CAR_DEAD(car->ref);
        int hp = GET_CAR_HEALTH(car->ref);

        if (!onFire && !dead && hp > 350)
            return;

        int score = 0;
        if (dead) score += 3;
        if (onFire) score += 2;
        if (hp <= 100) score += 2;
        else if (hp <= 350) score += 1;

        if (score > bestScore || (score == bestScore && d < bestDist))
        {
            bestScore = score;
            bestDist = d;
            best = car;
        }
    };

    for (auto& pair : Vehicles::GetVehiclesMap())
    {
        auto* car = pair.second;
        if (!car) continue;
        float dHere = distanceBetweenPoints(origin, car->GetPosition());
        float dCall = distanceBetweenPoints(targetPosition, car->GetPosition());
        consider(car, dHere < dCall ? dHere : dCall);
    }

    return best;
}

void AIFireman::ExtinguishAt(CVector pos, float radius)
{
    EXTINGUISH_FIRE_AT_POINT(pos.x, pos.y, pos.z, radius);
}

void AIFireman::SprayAndExtinguish(Vehicle* wreck, Vehicle* truck)
{
    if (!wreck || !CAR_DEFINED(wreck->ref) || !truck)
        return;

    isSpraying = true;
    leaveScheduled = true;

    CVector wreckPos = wreck->GetPosition();

    // 2s de “jato” no ponto da sucata (sem mensagem)
    // O canhão de água do firetruck é hard-coded no SA — não há opcode
    // confiável para a IA disparar o jato visual como o jogador.
    ExtinguishAt(wreckPos, 8.0f);

    WAIT(700, [this, wreck]() {
        if (!Vehicles::IsValid(wreck) || !CAR_DEFINED(wreck->ref))
            return;
        ExtinguishAt(wreck->GetPosition(), 10.0f);
    });

    WAIT(1400, [this, wreck]() {
        if (!Vehicles::IsValid(wreck) || !CAR_DEFINED(wreck->ref))
            return;
        ExtinguishAt(wreck->GetPosition(), 12.0f);
    });

    WAIT(2000, [this, wreck, truck]() {
        if (Vehicles::IsValid(wreck) && CAR_DEFINED(wreck->ref))
        {
            CVector p = wreck->GetPosition();
            ExtinguishAt(p, 18.0f);
            ExtinguishAt(p, 22.0f);

            if (!IS_CAR_DEAD(wreck->ref))
            {
                int hp = GET_CAR_HEALTH(wreck->ref);
                if (hp < 600)
                    SET_CAR_HEALTH(wreck->ref, 800);
            }
        }
        else
        {
            ExtinguishAt(targetPosition, 25.0f);
        }

        WAIT(2500, [this, truck]() {
            LeaveScene(truck);
        });
    });
}

void AIFireman::LeaveScene(Vehicle* vehicle)
{
    if (isLeaving)
        return;
    isLeaving = true;

    if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        return;

    auto driver = Peds::GetPed(vehicle->GetCurrentDriver());
    if (!driver || !ACTOR_DEFINED(driver->ref))
        return;

    fileLog->Log("AIFireman: indo embora");

    SET_CAR_MAX_SPEED(vehicle->ref, 25.0f);
    SET_CAR_TRAFFIC_BEHAVIOUR(vehicle->ref, DrivingMode::AvoidCars);
    ENABLE_CAR_SIREN(vehicle->ref, false);

    driver->StartDrivingRandomly();
    REMOVE_REFERENCES_TO_CAR(vehicle->ref);
}
