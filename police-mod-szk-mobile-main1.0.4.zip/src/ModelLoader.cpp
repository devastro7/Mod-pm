#include "ModelLoader.h"

#include "CleoFunctions.h"

std::vector<int> ModelLoader::modelsToLoad;
std::vector<bool> ModelLoader::modelsAllowAny;
std::function<void()> ModelLoader::onLoadAllCallback;

bool ModelLoader::IsSpecialModel(int id)
{
    // Apenas informativo — com allowAnyPed esses ids SAO permitidos
    static const int specialModels[] = {
        265, 266, 267,
        274, 275, 276, 277, 278, 279,
        288, 289,
        290, 291, 292, 293, 294, 295, 296, 297, 298, 299
    };
    for (int s : specialModels)
    {
        if (s == id) return true;
    }
    return false;
}

bool ModelLoader::IsValidModelId(int modelId, bool allowAnyPed)
{
    // Unico bloqueio absoluto: id invalido
    if (modelId <= 0) return false;
    if (modelId > 20000) return false;
    if (allowAnyPed) return true;
    // Ocorrencias aleatorias: evita especiais perigosos sem intencao
    if (IsSpecialModel(modelId)) return false;
    return true;
}

void ModelLoader::AddModelToLoad(int modelId, bool allowAnyPed)
{
    if (modelId <= 0 || modelId > 20000)
    {
        fileLog->Error("ModelLoader: recusado modelId invalido " + std::to_string(modelId));
        return;
    }

    if (!allowAnyPed && IsSpecialModel(modelId))
    {
        fileLog->Error("ModelLoader: recusado model especial " + std::to_string(modelId) + " (sem allowAnyPed)");
        return;
    }

    if (allowAnyPed && IsSpecialModel(modelId))
        fileLog->Log("ModelLoader: ped/especial " + std::to_string(modelId) + " permitido (apoioP/parceiro/comboio)");

    if (!HAS_MODEL_LOADED(modelId))
    {
        for (int id : modelsToLoad)
        {
            if (id == modelId) return;
        }
        modelsToLoad.push_back(modelId);
        modelsAllowAny.push_back(allowAnyPed);
    }
}

void ModelLoader::LoadAll(std::function<void()> callback)
{
    onLoadAllCallback = callback;
    LoadNextModel();
}

void ModelLoader::LoadNextModel()
{
    while (!modelsToLoad.empty())
    {
        int front = modelsToLoad.front();
        bool allow = !modelsAllowAny.empty() && modelsAllowAny.front();
        if (IsValidModelId(front, allow))
            break;

        fileLog->Error("ModelLoader: removendo da fila modelId " + std::to_string(front));
        modelsToLoad.erase(modelsToLoad.begin());
        if (!modelsAllowAny.empty())
            modelsAllowAny.erase(modelsAllowAny.begin());
    }

    if (modelsToLoad.empty())
    {
        modelsAllowAny.clear();
        if (onLoadAllCallback)
        {
            auto cb = onLoadAllCallback;
            onLoadAllCallback = nullptr;
            cb();
        }
        return;
    }

    int modelId = modelsToLoad.front();

    if (HAS_MODEL_LOADED(modelId))
    {
        ModelLoaded(modelId);
        return;
    }

    // REQUEST_MODEL e o streaming correto (evita col model incompleto em customs)
    REQUEST_MODEL(modelId);
    LOAD_REQUESTED_MODELS();

    if (HAS_MODEL_LOADED(modelId))
    {
        ModelLoaded(modelId);
        return;
    }

    CleoFunctions::AddWaitForFunction("modelloader_load",
        [modelId]() {
            if (!HAS_MODEL_LOADED(modelId))
            {
                REQUEST_MODEL(modelId);
                LOAD_REQUESTED_MODELS();
            }
            return HAS_MODEL_LOADED(modelId);
        },
        [modelId]() { ModelLoaded(modelId); }
    );
}

void ModelLoader::ModelLoaded(int modelId)
{
    if (!modelsToLoad.empty() && modelsToLoad.front() == modelId)
    {
        modelsToLoad.erase(modelsToLoad.begin());
        if (!modelsAllowAny.empty())
            modelsAllowAny.erase(modelsAllowAny.begin());
    }
    else
    {
        for (size_t i = 0; i < modelsToLoad.size(); )
        {
            if (modelsToLoad[i] == modelId)
            {
                modelsToLoad.erase(modelsToLoad.begin() + (int)i);
                if (i < modelsAllowAny.size())
                    modelsAllowAny.erase(modelsAllowAny.begin() + (int)i);
            }
            else
                ++i;
        }
    }

    LoadNextModel();
}
