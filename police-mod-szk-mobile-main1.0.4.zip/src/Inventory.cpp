#include "Inventory.h"
#include "InventoryItemManager.h"

Inventory::Inventory() {}
Inventory::~Inventory() {}

void Inventory::AddItem(const std::string& id, int amount)
{
    std::shared_ptr<ItemDefinition> def;
    auto it = InventoryItemManager::itemDefinitions.find(id);
    if (it != InventoryItemManager::itemDefinitions.end()) def = it->second;
    else {
        auto itCar = InventoryItemManager::carItemDefinitions.find(id);
        if (itCar == InventoryItemManager::carItemDefinitions.end()) return;
        def = itCar->second;
    }

    for (auto& item : items)
    {
        if (item.GetDefinition() == def)
        {
            item.AddQuantity(amount);
            return;
        }
    }
    items.emplace_back(def, amount);
}

void Inventory::RemoveItem(const std::string& id)
{
    std::shared_ptr<ItemDefinition> def;
    auto it = InventoryItemManager::itemDefinitions.find(id);
    if (it != InventoryItemManager::itemDefinitions.end()) def = it->second;
    else {
        auto itCar = InventoryItemManager::carItemDefinitions.find(id);
        if (itCar == InventoryItemManager::carItemDefinitions.end()) return;
        def = itCar->second;
    }

    items.erase(std::remove_if(items.begin(), items.end(),
        [&](const InventoryItem& item) { return item.GetDefinition() == def; }), items.end());
}
