#include <mod/amlmod.h>
#include <mod/config.h>

#include "pch.h"

MYMODCFG(com.daniloszk.policemod, PoliceMod, 1.0.0, DaniloSZK)

extern "C" void OnModPreLoad()
{

}

extern "C" void OnModLoad()
{
}