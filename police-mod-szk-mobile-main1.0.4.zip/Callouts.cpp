#include "Callouts.h"
#include "RadioWindow.h"
#include "DualPatrol.h"

#include "BottomMessage.h"
#include "DispatchPanel.h"
#include "CleoFunctions.h"
#include "ATMSystem.h"
#include "ScriptTask.h"
#include "ModelLoader.h"
#include "Peds.h"
#include "Criminals.h"
#include "AIController.h"
#include "Chase.h"
#include "AICriminal.h"
#include "AudioCollection.h"
#include "RadioSounds.h"

#include "callouts/ATMCallout.h"
#include "callouts/TestCallout.h"
#include "callouts/StolenCarCallout.h"
#include "callouts/DrugDealerCallout.h"
#include "callouts/HomeInvasionCallout.h"
#include "callouts/KidnapCallout.h"
#include "callouts/BankRobberyCallout.h"
#include "callouts/ArmoredCarRobberyCallout.h"
#include "callouts/WantedSearchCallout.h"
#include "callouts/ShootoutCallout.h"
#include "callouts/FavelaShootoutCallout.h"
#include "callouts/AirRescueCallout.h"
#include "NearbyStolenSystem.h"

bool g_onACallout = false;
bool g_calloutReached = false;
int g_receiveCalloutTimer = 0;

static CalloutBase* g_broadcastingCallout = nullptr;
static CalloutBase* g_currentCallout = nullptr;
static CalloutBase* g_lastBroadcastedCallout = nullptr;

// Safety: se o audio do callout nunca marcar Finished(), libera o broadcast
static int g_broadcastingElapsed = 0;
static const int BROADCAST_MAX_MS = 20000;

// Se nao aceitar o callout, limpa apos este tempo
static int g_pendingAcceptElapsed = 0;
static const int PENDING_ACCEPT_MAX_MS = 45000;

bool g_spawnedCriminals = false;
int g_calloutEndGraceMs = 0; // evita encerrar callout logo apos spawn

void Callouts::Initialize()
{
    CalloutRegistry::Register(new ATMCallout());
    CalloutRegistry::Register(new StolenCarCallout());
    CalloutRegistry::Register(new DrugDealerCallout());
    CalloutRegistry::Register(new HomeInvasionCallout());
    CalloutRegistry::Register(new KidnapCallout());
    CalloutRegistry::Register(new BankRobberyCallout());
    CalloutRegistry::Register(new ArmoredCarRobberyCallout());
    CalloutRegistry::Register(new WantedSearchCallout());
    CalloutRegistry::Register(new ShootoutCallout());
    CalloutRegistry::Register(new FavelaShootoutCallout());
    CalloutRegistry::Register(new AirRescueCallout());
}

void Callouts::Update()
{
    AirRescueCallout::UpdateScene();
    RadioWindow::UpdateAcceptButton();
    // Timer so avanca com servico ativo e livre de broadcast/ocorrencia
    if (g_onService && g_broadcastingCallout == nullptr && !g_onACallout)
    {
        g_receiveCalloutTimer += menuSZK->deltaTime;
    }

    // Safety timeout do broadcast travado
    if (g_broadcastingCallout != nullptr)
    {
        g_broadcastingElapsed += menuSZK->deltaTime;
        if (g_broadcastingElapsed >= BROADCAST_MAX_MS)
        {
            g_broadcastingCallout = nullptr;
            g_broadcastingElapsed = 0;
            RadioSounds::UnmuteRadio();
        }
    }
    else
    {
        g_broadcastingElapsed = 0;
    }

    // Timeout de callout nao aceito
    if (g_lastBroadcastedCallout != nullptr && !g_onACallout)
    {
        g_pendingAcceptElapsed += menuSZK->deltaTime;
        if (g_pendingAcceptElapsed >= PENDING_ACCEPT_MAX_MS)
        {
            g_lastBroadcastedCallout = nullptr;
            g_pendingAcceptElapsed = 0;
            DispatchPanel::Hide();
        }
    }
    else
    {
        g_pendingAcceptElapsed = 0;
    }

    // Broadcast independente do RadioSounds (respeita seconds_between_callouts)
    if (g_onService && g_broadcastingCallout == nullptr && !g_onACallout)
    {
        TryBroadcastCallout();
    }

    if (!g_onACallout)
    {
        g_spawnedCriminals = false;
        g_calloutReached = false;
        g_kidnapRegionActive = false;
        g_calloutEndGraceMs = 0;
        // nao limpa g_customCalloutEndMessage aqui — ja limpou no fim
    }
    else
    {
        // Contagem regressiva da graca pos-spawn
        if (g_calloutEndGraceMs > 0)
        {
            g_calloutEndGraceMs -= menuSZK ? menuSZK->deltaTime : 50;
            if (g_calloutEndGraceMs < 0) g_calloutEndGraceMs = 0;
        }

        auto criminalsCount = Criminals::GetCriminals()->size();

        if (criminalsCount > 0 && g_calloutReached)
        {
            g_spawnedCriminals = true;
        }

        // So pode encerrar se ja passou a graca (evita sumir em 1s no procurado)
        if (g_spawnedCriminals && criminalsCount == 0 && g_calloutReached && g_calloutEndGraceMs <= 0)
        {
            g_onACallout = false;
            if (!g_customCalloutEndMessage.empty())
            {
                BottomMessage::AddMessage(g_customCalloutEndMessage, 4000);
                g_customCalloutEndMessage.clear();
            }
            else
            {
                BottomMessage::AddMessage("Ocorrencia encerrada", 3000);
            }

            // Limpa carro-forte (e ocupantes) no fim — igual some viatura apos ocorrencia
            if (g_armoredSecCarRef > 0 && CAR_DEFINED(g_armoredSecCarRef))
            {
                auto sv = Vehicles::GetVehicle(g_armoredSecCarRef);
                if (sv)
                {
                    for (auto o : sv->GetOwners())
                    {
                        auto ped = Peds::GetPed(o);
                        if (ped) ped->QueueDestroy();
                    }
                    sv->HideBlip();
                    sv->QueueDestroy(false);
                }
                g_armoredSecCarRef = -1;
            }
            g_armoredCrimCarRef = -1;

            // Assalto a banco: aguia ja em orbita → sobe/abre raio e vai embora (sem auto heli pos)
            if (g_bankRobberyHeliActive)
            {
                DualPatrol::StartBankHeliLeave();
                g_bankRobberyHeliActive = false;
            }
            else
            {
                DualPatrol::SpawnAutoHeliAfterCallout();
            }
        }
    }

    if (g_onACallout)
    {
        if (ACTOR_DEAD(GetPlayerActor()))
        {
            g_onACallout = false;
            g_kidnapRegionActive = false;

            BottomMessage::SetMessage("~r~Parece q o player morreu...", 2000);

            WAIT(500, []() {
                auto criminals = *Criminals::GetCriminals();

                for (auto criminal : criminals)
                {
                    Criminals::RemoveCriminal(criminal);
                    criminal->QueueDestroy();
                }
            });
        }
    }
}

void Callouts::TryBroadcastCallout()
{
    if (!g_onService)
        return;

    if (g_broadcastingCallout != nullptr || g_onACallout)
        return;

    // Carro roubado NAO bloqueia outras ocorrencias (UI empilha; audio prioriza o primeiro)
    if (g_receiveCalloutTimer >= (g_secondsBetweenCallouts * 1000))
    {
        BroadcastRandomCallout();
    }
}

void Callouts::BroadcastRandomCallout()
{
    auto callout = CalloutRegistry::GetRandom();
    BroadcastCallout(callout);
}

void Callouts::BroadcastCallout(CalloutBase* callout)
{
    if (!callout)
        return;

    g_receiveCalloutTimer = 0;
    g_broadcastingElapsed = 0;
    g_pendingAcceptElapsed = 0;

    g_broadcastingCallout = callout;
    g_lastBroadcastedCallout = callout;

    {
        std::string raw = g_broadcastingCallout->GetBroadcastMessage();
        {
            std::string s = raw;
            auto removeAll = [&](const std::string& token) {
                size_t p;
                while ((p = s.find(token)) != std::string::npos)
                {
                    size_t start = p;
                    if (start >= 3 && s[start - 3] == '~') start -= 3;
                    while (start > 0 && (s[start - 1] == '[' || s[start - 1] == ' ')) start--;
                    size_t end = p + token.size();
                    while (end < s.size() && (s[end] == ' ' || s[end] == ']')) end++;
                    s.erase(start, end - start);
                }
            };
            removeAll("COPOM");
            removeAll("Copom");
            while (!s.empty() && (s[0] == '[' || s[0] == ']' || s[0] == ' '))
                s.erase(0, 1);
            while (!s.empty() && s[0] == '~' && s.size() >= 3)
                s.erase(0, 3);
            while (!s.empty() && s[0] == ' ')
                s.erase(0, 1);
            for (size_t i = 0; i + 2 < s.size(); )
            {
                if (s[i] == '~' && s[i + 2] == '~')
                    s.erase(i, 3);
                else
                    ++i;
            }
            raw = s;
        }

        std::string callType = raw.empty() ? "Ocorrencia policial" : raw;
        std::string location = "Local no mapa";
        std::string instruction = "Desloque-se ate o local e ajude se possivel.";
        int duration = CALLOUT_UI_DURATION_MS;

        // Empilha com qualquer tabela ja aberta (ex.: carro roubado na regiao)
        // 0 = so padrao | 1 = so novo | 2 = ambos
        if (CALLOUT_UI_STYLE == 0 || CALLOUT_UI_STYLE == 2)
        {
            BottomMessage::SetMessage(std::string("~b~[COPOM] ~w~") + callType, duration);
        }
        if (CALLOUT_UI_STYLE == 1 || CALLOUT_UI_STYLE == 2)
        {
            DispatchPanel::Show(callType, location, instruction, duration);
        }
        else
        {
            DispatchPanel::Hide();
        }
    }

    auto audioGroup = g_broadcastingCallout->GetBroadcastAudio();
    IAudio* audio = audioGroup ? audioGroup->GetRandomAudio() : nullptr;

    // Radio da pasta continua tocando, mas fica MUDO durante a fala da ocorrencia
    if (DISABLE_CALLOUTS_RADIO_SOUND || !audio)
    {
        RadioSounds::MuteRadio();
        WAIT(5000, []() {
            g_broadcastingCallout = nullptr;
            g_broadcastingElapsed = 0;
            RadioSounds::UnmuteRadio();
        });
    }
    else
    {
        // PlayAudioNow: deixa radio mudo (sem resetar a faixa) e toca a voz do chamado
        RadioSounds::PlayAudioNow(audio);

        WaitForAudioFinish(audio, []() {
            RadioSounds::UnmuteRadio();
            WAIT(1000, []() {
                g_broadcastingCallout = nullptr;
                g_broadcastingElapsed = 0;
            });
        });
    }
}

void Callouts::AcceptCallout()
{
    auto callout = g_lastBroadcastedCallout;

    if (callout == nullptr) return;
    // Evita aceitar 2x (toque duplo no botao) enquanto ja esta em ocorrencia
    if (g_onACallout) return;

    g_onACallout = true;
    g_currentCallout = callout;
    g_lastBroadcastedCallout = nullptr;
    g_broadcastingCallout = nullptr;
    g_broadcastingElapsed = 0;
    g_pendingAcceptElapsed = 0;
    RadioSounds::UnmuteRadio();

    DispatchPanel::Hide();

    if (RADIO_PLAY_ACCEPT_CALLOUT_SOUND && audioAcceptCallout)
    {
        auto audio = audioAcceptCallout->GetRandomAudio();
        if (audio)
        {
            int vol = RADIO_CALLOUT_VOLUME;
            if (vol < 30) vol = 30;
            if (vol > 500) vol = 500;
            audio->SetVolume(vol / 100.0f);
            audio->Play();
        }
    }

    g_currentCallout->OnAccept();

    // Fecha o radio automaticamente ao aceitar
    if (RadioWindow::MainContainer && RadioWindow::MainContainer->isVisible)
        RadioWindow::Toggle();
}


void Callouts::CancelPendingOrActive()
{
    // Sempre limpa marker amarelo / blip de area
    ClearActiveCalloutMarker();
    g_kidnapRegionActive = false;
    g_lastBroadcastedCallout = nullptr;
    g_broadcastingCallout = nullptr;
    g_broadcastingElapsed = 0;
    g_pendingAcceptElapsed = 0;
    DispatchPanel::Hide();

    // Encerra tambem a busca por veiculo roubado na regiao
    if (NearbyStolenSystem::IsActive() || NearbyStolenSystem::IsBlockingOtherCallouts())
        NearbyStolenSystem::ClearActive(true);

    if (!g_onACallout)
    {
        BottomMessage::SetMessage("~y~Chamado cancelado", 2500);
        return;
    }

    // Limpa a cena especifica do resgate aereo antes da limpeza generica.
    AirRescueCallout::CleanupScene();

    // Em ocorrencia ativa: limpa estado + criminosos + chase, SEM apagar carros civis
    // e SEM remover viaturas de comboio (DualPatrol)
    g_onACallout = false;
    g_calloutReached = false;
    g_spawnedCriminals = false;
    g_calloutEndGraceMs = 0;
    g_customCalloutEndMessage.clear();
    g_armoredSecCarRef = -1;
    g_armoredCrimCarRef = -1;

    auto criminals = *Criminals::GetCriminals();
    for (auto criminal : criminals)
    {
        if (!criminal) continue;
        Criminals::RemoveCriminal(criminal);
        AIController::RemoveAIsFromPed(criminal);
        criminal->HideBlip();
        criminal->QueueDestroy();
    }

    Chase::AbortChase();
    Chase::vehiclesInChase.clear();

    // So esconde blips de ocorrencia; nao destroi veiculos civis
    for (auto& kv : Peds::GetPedsMap())
    {
        auto ped = kv.second;
        if (!ped) continue;
        if (ped->flags.showWidget || Criminals::IsCriminal(ped))
        {
            ped->HideBlip();
            ped->flags.showWidget = false;
        }
    }

    ClearActiveCalloutMarker();
    BottomMessage::SetMessage("~y~Ocorrencia cancelada", 3000);
}

bool Callouts::HasCalloutToAccept()
{
    return g_lastBroadcastedCallout != nullptr;
}

bool Callouts::IsBroacastingCallout()
{
    return g_broadcastingCallout != nullptr;
}

bool Callouts::IsInCallout()
{
    return g_onACallout;
}
