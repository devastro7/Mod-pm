#pragma once

#include "ModData.h"
#include "Logger.h"

// CLEO 2.0.1.3
#include "cleo.h"
extern cleo_ifs_t* cleo;

// SAUtils 1.6
#include "isautils.h"
extern ISAUtils* sautils;

// MenuSZK
#include "menuSZK/IMenuSZK.h"
extern IMenuSZK* menuSZK;

#define menuDebug menuSZK->debug

#define NO_PED_FOUND -1

#include "hooks.h"

#include <functional>
#include <map>
#include <string>
#include <sstream>
#include <iomanip>
#include <random>
#include <fstream>
#include <iostream>
#include <algorithm>

#include "EventListener.h"

inline bool HasCleo() { return cleo != nullptr; }

inline bool blockInput = false;

inline void* textureBlip = nullptr;
inline void* textureCircle = nullptr;
inline void* textureBigCircle = nullptr;

// Blip de regiao do sequestro (mesmo estilo QTH: textureBigCircle size 150, cor vermelha)
inline bool g_kidnapRegionActive = false;
inline CVector g_kidnapRegionPos = CVector(0, 0, 0);
inline void* texturePoliceDP = nullptr;

inline CVector* g_playerPosition = new CVector(0, 0, 0);
inline CVector2D g_defaultMenuPosition = CVector2D(400, 200);
inline int g_lastPlayerVehicle = -1;

inline EventListener<int>* g_onPedEnterVehicle = new EventListener<int>();
inline EventListener<int>* g_onPedLeaveVehicle = new EventListener<int>();
inline EventListener<int>* g_onVehicleDestroy = new EventListener<int>();

inline std::vector<int> g_vehiclesToDestroy;
inline std::vector<int> g_pedsToDestroy;

inline std::vector<int> g_criminalSkins = {20, 18, 28, 66, 108};

inline std::vector<int> g_stolenVehicleIds = {405, 414, 440, 456, 461, 522, 482, 496, 499, 507};

inline bool g_blockInteractions = false;

inline int CHASE_VEHICLE_MAX_SPEED = 50.0f;
inline int CHASE_POLICE_MAX_SPEED = 50.0f;
inline int CHASE_MIN_TIME_TO_SURRENDER = 40.0f;
inline bool CREATE_INJURED_PED = true;
inline bool DISABLE_CALLOUTS_RADIO_SOUND = false;

// Radio config (menu radio_configs)
inline bool RADIO_PLAY_ACCEPT_CALLOUT_SOUND = false; // som ao aceitar ocorrencia
inline int RADIO_CALLOUT_VOLUME = 100;               // 30..500 step 10
inline int RADIO_CALLOUT_DISTANCE = 100;             // 30..500 step 10 (escala)
inline bool RADIO_VEHICLE_RADIO_ENABLED = true;      // on/off audios da pasta radio
inline int RADIO_SOUND_INDEX = 0;                   // indice do som do radio (0-based)
inline int RADIO_SOUND_VOLUME = 100;                // 30..500 step 10
inline int RADIO_SOUND_DISTANCE = 100;              // 30..500 step 10 (escala)

// Estilo de chegada de ocorrencia:
// 0 = padrao (mensagem inferior)
// 1 = novo (painel 911 DISPATCH)
// 2 = ambos
inline int CALLOUT_UI_STYLE = 2;
// Tempo que o aviso fica na tela (ms). 3000..60000
inline int CALLOUT_UI_DURATION_MS = 12000;
// Posicao do painel (offset X / Y na tela)
inline int CALLOUT_UI_POS_X = 16;
inline int CALLOUT_UI_POS_Y = -30;
// Tamanho do painel 0..100 (100 = normal)
inline int CALLOUT_UI_SIZE = 100;
// Animacao do painel:
// 0 = desligada | 1 = de cima | 2 = de baixo | 3 = da esquerda | 4 = da direita | 5 = fade
inline int CALLOUT_UI_ANIM = 3;
// Duracao da animacao de entrada/saida (ms)
inline int CALLOUT_UI_ANIM_MS = 400;
// Estilo da revista: 0=padrao (menu) 1=novo (painel lateral) 2=ambos
inline int FRISK_UI_STYLE = 1;
// Quantidade maxima de pop-ups simultaneos (1..5)
inline int FRISK_UI_MAX_POPUPS = 3;
// Espaco vertical entre pop-ups empilhados (0..50)
inline int FRISK_UI_POPUP_GAP = 4;
// Duracao dos pop-ups de consulta/revista (ms) 3000..60000
inline int FRISK_UI_DURATION_MS = 8000;
// Codigo no badge vermelho: 0=911 1=190 2=192 3=193 4=197 5=153
inline int CALLOUT_UI_BADGE_CODE = 0;
inline const char* CALLOUT_UI_BADGE_CODES[] = { "911", "190", "192", "193", "197", "153" };
inline constexpr int CALLOUT_UI_BADGE_CODE_COUNT = 6;
inline const char* GetCalloutBadgeText()
{
    int i = CALLOUT_UI_BADGE_CODE;
    if (i < 0) i = 0;
    if (i >= CALLOUT_UI_BADGE_CODE_COUNT) i = 0;
    return CALLOUT_UI_BADGE_CODES[i];
}

inline float CHANCE_CRIMINAL_KILL_COPS = 0.40f;

inline float CHANCE_RUNNING_AWAY_WHEN_VEHICLE_IRREGULAR = 0.30f;
inline float CHANCE_PEDESTRIAN_RUNNING_AWAY_WHEN_APPROACHED = 0.25f;
inline float CHANCE_FLEE_DURING_APPROACH = 0.10f;
inline float CHANCE_FLEE_DRIVING_DURING_APPROACH = 0.10f;
inline int FLEE_DRIVING_DURING_APPROACH_MIN_SECONDS = 10;
inline int FLEE_DRIVING_DURING_APPROACH_MAX_SECONDS = 30;
inline int FLEE_DURING_APPROACH_MIN_SECONDS = 5;
inline int FLEE_DURING_APPROACH_MAX_SECONDS = 30;

// Duracao do task de fuga (FLEE_FROM_ACTOR) em segundos — configuravel no ini
inline int FLEE_TASK_MIN_SECONDS = 50;
inline int FLEE_TASK_MAX_SECONDS = 120;

// Tempo com veiculo parado (s) para o criminoso descer na perseguicao
inline int VEHICLE_STOPPED_EXIT_SECONDS = 15;

inline float CHANCE_BEEING_WANTED_BY_JUSTICE = 0.10;

// Pesos das ocorrencias (maior = mais chance). Nao precisa somar 100.
inline int CALLOUT_WEIGHT_ATM = 33;
inline int CALLOUT_WEIGHT_STOLEN_CAR = 33;
inline int CALLOUT_WEIGHT_DRUG_DEALER = 34;
inline int CALLOUT_WEIGHT_HOME_INVASION = 25;
inline int CALLOUT_WEIGHT_KIDNAP = 30;
inline int CALLOUT_WEIGHT_BANK_ROBBERY = 0; // padrao 0 (sem settings.ini); ative no ini se quiser
inline int CALLOUT_WEIGHT_ARMORED_CAR = 30;
inline int CALLOUT_WEIGHT_WANTED_SEARCH = 28;
inline int CALLOUT_WEIGHT_SHOOTOUT = 28;
inline int CALLOUT_WEIGHT_FAVELA_SHOOTOUT = 0; // padrao 0 (sem settings.ini); ative no ini se quiser
inline int CALLOUT_WEIGHT_AIR_RESCUE = 30;

// Nivel de cada ocorrencia (1..5). Usado pelo filtro do menu Ocorrencias.
inline int CALLOUT_LEVEL_ATM = 1;
inline int CALLOUT_LEVEL_STOLEN_CAR = 1;
inline int CALLOUT_LEVEL_DRUG_DEALER = 1;
inline int CALLOUT_LEVEL_HOME_INVASION = 1;
inline int CALLOUT_LEVEL_KIDNAP = 1;
inline int CALLOUT_LEVEL_BANK_ROBBERY = 1;
inline int CALLOUT_LEVEL_ARMORED_CAR = 1;
inline int CALLOUT_LEVEL_WANTED_SEARCH = 1;
inline int CALLOUT_LEVEL_SHOOTOUT = 1;
inline int CALLOUT_LEVEL_FAVELA_SHOOTOUT = 1;
inline int CALLOUT_LEVEL_AIR_RESCUE = 1;

// Filtro ativo no menu: 0 = Todas | 1..5 = so aquele nivel
inline int CALLOUT_LEVEL_FILTER = 0;

// 0 = so cidade atual | 1 = aceita ocorrencias de outras cidades
inline int g_acceptCalloutsOtherCities = 0;

// Mensagem custom ao encerrar ocorrencia (vazio = padrao)
inline std::string g_customCalloutEndMessage;

// Marker amarelo da ocorrencia ativa (blip no mapa)
inline int g_activeCalloutMarker = -1;


// --- [stolen_nearby] veiculo roubado na regiao (pega carro ja spawnado) ---
inline int STOLEN_NEARBY_ENABLED = 1;              // sistema ligado (usa chance/intervalo)
inline int STOLEN_NEARBY_INTERVAL_SECONDS = 60;    // a cada N s tenta gerar
inline double STOLEN_NEARBY_CHANCE = 0.6000;       // chance de aparecer
inline int STOLEN_NEARBY_SHOW_BLIP_3D = 1;         // blip 3d no veiculo
inline int STOLEN_NEARBY_BLIP_3D_SECONDS = 0;      // 0 = nao some
inline int STOLEN_NEARBY_SHOW_BIG_CIRCLE = 1;      // big circle no radar (reposiciona a cada 10s)
inline double STOLEN_NEARBY_WEAPON_CHANCE = 0.5000; // chance do motorista ter arma

// 1 = aguia automatico no assalto a banco; 0 = nao (favela usa [aguia_favela])
inline int g_aguiaNoBanco = 1;

// --- [aguia_favela] config do aguia automatico SO na ocorrencia de tiro na favela ---
inline int AGUIA_FAVELA_ENABLED = 1;       // 1=spawn automatico na favela, 0=nao
inline int AGUIA_FAVELA_MODEL_ID = 497;    // modelo do heli (497 = polmav)
inline int AGUIA_FAVELA_HEIGHT = 80;       // altura % (ou 1001-1004 variavel)
inline int AGUIA_FAVELA_RADIUS = 60;       // raio %
inline int AGUIA_FAVELA_SPEED = 1003;      // velocidade % ou 1001-1004 variavel
inline int AGUIA_FAVELA_ANGLE = 50;        // inclinacao/bank em graus
inline int AGUIA_FAVELA_DIRECTION = 0;     // 0=horario, 1=anti-horario

// Heli do banco ativo (nao dispara auto heli pos-ocorrencia)
inline bool g_bankRobberyHeliActive = false;
inline int g_bankRobberyHeliCarRef = -1;

// Sequestro (kidnap callout)
inline float CHANCE_KIDNAP_DRIVE_OFF = 0.35f;          // chance de acelerar apos o timer (sem marcar o carro)
inline float CHANCE_KIDNAP_FLEE_ON_PULLOVER = 0.55f;   // chance de fugir na ordem de parada (e atirar)
inline float CHANCE_MEDIC_REANIMATE_SUCCESS = 0.70f; // 0.00~1.00 chance do SAMU reanimar
inline float CHANCE_WANTED_SEARCH_USE_HOUSE = 0.50f; // busca e apreensao: chance de usar casa (invasao)
inline float CHANCE_ARMED_SURRENDER = 0.10f; // chance de armado se render na ordem de parada/mira/buzina
inline int KIDNAP_WAIT_MIN_SECONDS = 3;
inline int KIDNAP_WAIT_MAX_SECONDS = 30;

inline CVector2D g_widgetsStartPosition = CVector2D(450, 50);

inline void QueueDestroyPed(int ref)
{
    g_pedsToDestroy.push_back(ref);
}

inline void QueueDestroyVehicle(int ref)
{
    g_vehiclesToDestroy.push_back(ref);
}

#define COLOR_CRIMINAL CRGBA(255, 0, 0)
#define COLOR_GREEN CRGBA(0, 220, 0)
#define COLOR_YELLOW CRGBA(255, 255, 0)
#define COLOR_POLICE CRGBA(0, 150, 255)

template <typename T>
inline T* loadInterface(T** out, std::string name, bool optional = false)
{
    fileLog->Log("Looking for " + name + "...");

    void* interface = GetInterface(name.c_str());

    *out = static_cast<T*>(interface);

    if (*out)
    {
        fileLog->Log(name + " loaded");
    } else {

        if(optional)
        {
            fileLog->Log(name + " was not found, but its optional");
        } else {
            
            fileLog->Error(name + " was not found");
        }
    }

    return *out;
}

inline double distanceBetweenPoints(CVector point1, CVector point2)
{
    double dx = point1.x - point2.x;
    double dy = point1.y - point2.y;
    double dz = point1.z - point2.z;

    return sqrt( dx * dx + dy * dy + dz * dz );
}

inline double distanceBetweenPoints2D(CVector2D point1, CVector2D point2)
{
    double dx = point1.x - point2.x;
    double dy = point1.y - point2.y;

    return sqrt(dx * dx + dy * dy);
}

inline std::string VectorToString(const CVector& vec, int precision = 2)
{
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(precision);
    oss << "(" << vec.x << ", " << vec.y << ", " << vec.z << ")";
    return oss.str();
}

inline int getRandomNumber(int min, int max)
{
    int n = max - min + 1;
    int remainder = RAND_MAX % n;
    int x;
    do{
        x = rand();
    }while (x >= RAND_MAX - remainder);
    return min + x % n;
}


inline int GetFleeTaskDurationMs()
{
    int mn = FLEE_TASK_MIN_SECONDS;
    int mx = FLEE_TASK_MAX_SECONDS;
    if (mn < 5) mn = 5;
    if (mx < mn) mx = mn;
    return getRandomNumber(mn, mx) * 1000;
}

inline bool calculateProbability(float chance)
{
    int i = getRandomNumber(0, 99);
    return i < (int)(chance * 100.0f);
}

// Skins civis seguros (nunca especiais 274+ medic etc.)
inline const int kSafeCriminalSkins[] = {
    7, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 28, 29, 30,
    47, 48, 49, 50, 66, 67, 68, 98, 100, 101, 102, 103, 104, 105,
    106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117
};
inline const int kSafeCriminalSkinCount = (int)(sizeof(kSafeCriminalSkins) / sizeof(kSafeCriminalSkins[0]));

inline int GetSafeRandomPedSkin()
{
    int index = getRandomNumber(0, kSafeCriminalSkinCount - 1);
    return kSafeCriminalSkins[index];
}

inline int GetRandomCriminalSkin()
{
    // Prefer lista configuravel, mas so se o id for valido/civil
    if (!g_criminalSkins.empty())
    {
        for (int attempt = 0; attempt < 8; attempt++)
        {
            int index = getRandomNumber(0, static_cast<int>(g_criminalSkins.size()) - 1);
            int id = g_criminalSkins[index];
            if (id > 0 && id < 265) // evita especiais e 0
                return id;
        }
    }
    return GetSafeRandomPedSkin();
}

inline bool file_exists(const std::string& path)
{
    std::ifstream f(path.c_str());
    return f.good();
}

inline std::string randomPlate()
{
    // Letras permitidas (pode adicionar/remover)
    static const std::vector<std::string> prefixes = {
        "EGC", "BRA", "MNT", "CPU", "LVR", "SJP", "FGT", "QXZ", "HJK", "VPE", 
        "NDO", "RSC", "YAB", "ZGM", "PQL", "TJS", "WFM", "LXN", "CBF", "GVN"
    };

    // RNG (random device + Mersenne Twister)
    static std::random_device rd;
    static std::mt19937 gen(rd());

    // Sorteia prefixo
    std::uniform_int_distribution<> prefixDist(0, prefixes.size() - 1);
    std::string plate = prefixes[prefixDist(gen)];

    // Sorteia números (0000–9999)
    std::uniform_int_distribution<> numDist(0, 9999);
    int number = numDist(gen);

    // Formata para sempre ter 4 dígitos
    char buf[10];
    snprintf(buf, sizeof(buf), " %04d", number);

    plate += buf;
    return plate;
}

inline std::string randomPlateLimited()
{
    // Letras permitidas para o prefixo
    static const std::vector<char> letters = {'A', 'C', 'E', 'P'};
    // Números permitidos para os dígitos
    static const std::vector<char> numbers = {'3', '4', '6', '7', '8'};

    static std::random_device rd;
    static std::mt19937 gen(rd());

    std::uniform_int_distribution<> distLetters(0, letters.size() - 1);
    std::uniform_int_distribution<> distNumbers(0, numbers.size() - 1);

    std::string plate;

    // 3 letras
    for (int i = 0; i < 3; ++i)
        plate += letters[distLetters(gen)];

    plate += " "; // espaço antes dos números

    // 4 números
    for (int i = 0; i < 4; ++i)
        plate += numbers[distNumbers(gen)];

    return plate;
}

inline std::string randomVIN()
{
    static const std::string allowedChars = "0123456789ABCDEFGHJKLMNPRSTUVWXYZ";

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, allowedChars.size() - 1);

    std::string vin;
    vin.reserve(17);

    // WMI brasileiro (opcional)
    std::string wmi = "9BD"; // FIAT
    vin += wmi;

    // restante até 17 chars
    for (int i = 0; i < 14; i++) {
        vin += allowedChars[dis(gen)];
    }

    return vin;
}

inline std::string randomRENAVAM()
{
    // Gera 10 dígitos aleatórios (0-9)
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(0, 9);

    int nums[10];
    for (int i = 0; i < 10; i++)
        nums[i] = dist(gen);

    // Cálculo do dígito verificador (DV)
    // Peso oficial: 3 2 9 8 7 6 5 4 3 2
    static const int pesos[10] = {3,2,9,8,7,6,5,4,3,2};

    int soma = 0;
    for (int i = 0; i < 10; i++)
        soma += nums[i] * pesos[i];

    int dv = (soma * 10) % 11;
    if (dv == 10) dv = 0;

    // Monta a string final
    std::string renavam;
    renavam.reserve(11);
    for (int i = 0; i < 10; i++)
        renavam += std::to_string(nums[i]);
    renavam += std::to_string(dv);

    return renavam;
}

inline float CVectorDistance(const CVector& a, const CVector& b)
{
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    float dz = a.z - b.z;
    return std::sqrt(dx*dx + dy*dy + dz*dz);
}