#include "DualPatrol.h"
#include "Skins.h"
#include "IMultiRemap.h"
extern IMultiRemap* multiRemap;
#include "OptionsWindow.h"

#include "BottomMessage.h"
#include "CleoFunctions.h"
#include "ModelLoader.h"
#include "Vehicles.h"
#include "Peds.h"
#include "PoliceVehicles.h"
#include "ModData.h"
#include "IniReaderWriter.hpp"
#include "BackupUnits.h"
#include "simpleGta.h"

#include <filesystem>
#include <fstream>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

std::vector<Vehicle*> DualPatrol::escortVehicles;
int DualPatrol::selectedVehicleIndex = 0;
int DualPatrol::selectedHeliIndex = 0;
float DualPatrol::followDistance = 10.0f;
bool DualPatrol::showBlips = true;
bool DualPatrol::followOnFoot = false;
int DualPatrol::selectedOccupants = 2;
int DualPatrol::selectedSkinIndex = 0;
int DualPatrol::selectedRemapIndex = 0;
int DualPatrol::selectedHeliRemapIndex = 0;

int DualPatrol::selectedHeliMode = 0;
int DualPatrol::selectedHeliHeight = 100;
int DualPatrol::selectedHeliRadius = 100;
int DualPatrol::selectedHeliSpeed = 100;
int DualPatrol::selectedHeliAngle = 0;
int DualPatrol::selectedHeliDirection = 0;
bool DualPatrol::autoHeliEnabled = false;
int DualPatrol::autoHeliOrbitSeconds = 10;

// Estado por handle do heli (orbit / follow)
struct HeliOrbitState {
    int mode = 0; // 0 follow, 1 orbit, 2 orbit lock
    float orbitAngle = 0.0f;
    float heightScale = 1.0f;
    float radiusScale = 1.0f;
    float speedScale = 1.0f;
    float bankDeg = 0.0f;
    bool clockwise = false;
    bool fixedCenter = false;
    CVector orbitCenter = CVector(0, 0, 0);
    bool variableRadius = false;
    bool variableHeight = false;
    float varRadius = 115.0f;
    float varHeight = 100.0f;
    float varRadiusDir = 1.0f;
    float varHeightDir = 1.0f;
    bool followInit = false;
    // Variavel (menu escala): sobe/desce 10 a cada 5s entre min/max
    bool variableSpeed = false;
    float varSpeed = 100.0f;
    float varSpeedMin = 10.0f;
    float varSpeedMax = 50.0f;
    float varSpeedDir = 1.0f;
    float varSpeedTimer = 0.0f;

    float varRadiusMin = 10.0f;
    float varRadiusMax = 50.0f;
    float varRadiusTimer = 0.0f;

    float varHeightMin = 10.0f;
    float varHeightMax = 50.0f;
    float varHeightTimer = 0.0f;
};

static std::map<int, HeliOrbitState> g_heliStates;
static std::map<int, bool> g_escortOnFoot; // viatura -> ocupantes a pe
static std::map<int, bool> g_escortStandingStill; // ja mandou ficar parado
static std::map<int, bool> g_escortStayAtLocation; // unidade estacionada em uma ocorrencia

// Estado do auto heli pos-ocorrencia
struct AutoHeliState {
    int carRef = -1;
    int phase = 0; // 0=idle, 1=orbiting, 2=leaving
    float timer = 0.0f;
    float leaveRadiusBoost = 0.0f;
    float leaveHeightBoost = 0.0f;
};
static AutoHeliState g_autoHeli;

// Codigos variavel: 1001=10-50, 1002=50-100, 1003=100-160, 1004=10-150
static void ApplyVariableMode(int code, float& vmin, float& vmax, float& val)
{
    if (code == 1001) { vmin = 10.0f; vmax = 50.0f; val = 10.0f; }
    else if (code == 1002) { vmin = 50.0f; vmax = 100.0f; val = 50.0f; }
    else if (code == 1003) { vmin = 100.0f; vmax = 160.0f; val = 100.0f; }
    else if (code == 1004) { vmin = 10.0f; vmax = 150.0f; val = 10.0f; }
    else { vmin = 10.0f; vmax = 50.0f; val = 10.0f; }
}

static bool IsVariableCode(int code)
{
    return code == 1001 || code == 1002 || code == 1003 || code == 1004 || code == 999;
}




static std::string GetDualPatrolFolder()
{
    return modData->GetFile("data/dualpatrol");
}

struct DualApoioVehicle {
    std::string name;
    int vehicleModelId = 0;
    int skinModelId = 280;
    int occupants = 2;
    bool isHelicopter = false;
};

static std::vector<DualApoioVehicle> LoadApoioVehiclesFromIni(const std::string& fileName, bool isHeli)
{
    std::vector<DualApoioVehicle> list;
    std::string path = GetDualPatrolFolder() + "/" + fileName;

    if (!std::filesystem::exists(path))
        return list;

    std::ifstream in(path);
    if (!in.is_open()) return list;

    DualApoioVehicle cur;
    bool inSection = false;
    bool isPedSection = false; // evita usar ped_id como vehicle_id
    std::string line;
    auto flush = [&]() {
        // Para [PED] usamos apenas skinModelId; para [VEICULO]/[HELI] usamos vehicleModelId
        int id = isPedSection ? cur.skinModelId : (cur.vehicleModelId > 0 ? cur.vehicleModelId : cur.skinModelId);
        if (inSection && id > 0)
        {
            if (cur.name.empty()) cur.name = "Item " + std::to_string(id);
            if (!isPedSection)
            {
                // só preenche defaults em seções de veículo
                if (cur.skinModelId <= 0 && cur.vehicleModelId > 0) cur.skinModelId = 280;
                if (cur.vehicleModelId <= 0 && cur.skinModelId > 0) cur.vehicleModelId = cur.skinModelId;
            }
            else
            {
                // seção PED: nunca promove ped_id para vehicleModelId
                cur.vehicleModelId = 0;
                if (cur.skinModelId <= 0) cur.skinModelId = id;
            }
            cur.isHelicopter = isHeli;
            list.push_back(cur);
        }
        cur = DualApoioVehicle();
        inSection = false;
        isPedSection = false;
    };

    while (std::getline(in, line))
    {
        while (!line.empty() && (line.back()=='\r' || line.back()==' ' || line.back()=='\t')) line.pop_back();
        size_t a=0; while(a<line.size() && (line[a]==' '||line[a]=='\t')) a++;
        line = line.substr(a);
        if (line.empty() || line[0]=='#' || line[0]==';') continue;

        if (line.front()=='[' && line.back()==']')
        {
            flush();
            std::string sec = line.substr(1, line.size()-2);
            for (char& ch : sec) if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 'a' + 'A');
            if (sec == "VEICULO" || sec == "HELI" || sec == "PED")
            {
                inSection = true;
                isPedSection = (sec == "PED");
            }
            continue;
        }
        if (!inSection) continue;

        auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string key = line.substr(0, eq);
        std::string val = line.substr(eq+1);
        while (!key.empty() && (key.back()==' '||key.back()=='\t')) key.pop_back();
        while (!val.empty() && (val.front()==' '||val.front()=='\t'||val.front()=='"')) val.erase(val.begin());
        while (!val.empty() && (val.back()==' '||val.back()=='\t'||val.back()=='"')) val.pop_back();

        if (key == "name") cur.name = val;
        else if (key == "vehicle_id" || key == "model_id") {
            try { cur.vehicleModelId = std::stoi(val); } catch(...) {}
        }
        else if (key == "skin_id" || key == "ped_id") {
            try { cur.skinModelId = std::stoi(val); } catch(...) {}
        }
        else if (key == "occupants") {
            try { cur.occupants = std::stoi(val); } catch(...) {}
        }
    }
    flush();
    return list;
}

static void EnsureFolder()
{
    ModData::CreateFolder(modData->GetFile("data"));
    ModData::CreateFolder(GetDualPatrolFolder());

    // Gera apoioP.ini padrão se não existir (fardas para comboio e parceiros)
    std::string apoioP = GetDualPatrolFolder() + "/apoioP.ini";
    if (!std::filesystem::exists(apoioP))
    {
        std::ofstream out(apoioP);
        if (out.is_open())
        {
            out << "; Skins/policiais de apoio - adicione quantos [PED] quiser\n";
            out << "; name = nome exibido no menu\n";
            out << "; ped_id = ID do modelo do ped\n\n";
            out << "[PED]\nname = LS Officer\nped_id = 280\n\n";
            out << "[PED]\nname = SF Officer\nped_id = 281\n\n";
            out << "[PED]\nname = LV Officer\nped_id = 282\n\n";
            out << "[PED]\nname = County Sheriff\nped_id = 283\n\n";
            out << "[PED]\nname = Motorbike Cop\nped_id = 284\n\n";
            out << "[PED]\nname = SWAT\nped_id = 285\n\n";
            out << "[PED]\nname = FBI\nped_id = 286\n\n";
            out << "[PED]\nname = Army\nped_id = 287\n";
            out.close();
        }
    }

    // Gera apoioV.ini padrão se não existir — SOMENTE veículos padrão do jogo (sem ID 19000+)
    std::string apoioV = GetDualPatrolFolder() + "/apoioV.ini";
    if (!std::filesystem::exists(apoioV))
    {
        std::ofstream out(apoioV);
        if (out.is_open())
        {
            out << "; Veiculos de apoio (comboio) - adicione quantos [VEICULO] quiser\n";
            out << "; name = nome no menu\n";
            out << "; vehicle_id = ID do modelo do veiculo (padrao do jogo)\n";
            out << "; skin_id = ID da farda do policial\n";
            out << "; occupants = quantidade de ocupantes (1-4)\n";
            out << "; NAO use IDs altos (19000+) aqui a menos que voce tenha o modelo instalado.\n\n";
            out << "[VEICULO]\nname = \"Police LS\"\nvehicle_id = 596\nskin_id = 280\noccupants = 2\n\n";
            out << "[VEICULO]\nname = \"Police SF\"\nvehicle_id = 597\nskin_id = 281\noccupants = 2\n\n";
            out << "[VEICULO]\nname = \"Police LV\"\nvehicle_id = 598\nskin_id = 282\noccupants = 2\n";
            out.close();
        }
    }
}

// Orientacao do Heli Orbit (igual ao mod antigo que funcionava):
// - nariz (forward) tangencial a orbita
// - porta esquerda virada para o CENTRO
// - roll (bank) inclina a porta interna para o chao (0..60 do menu)
// IMPORTANTE: PUT_CAR_AT primeiro, matriz DEPOIS.
// NUNCA chamar SET_CAR_Z_ANGLE depois — ele zera pitch/roll e mata a inclinacao.
static void SetHeliWorldTransform(Vehicle* vehicle, float x, float y, float z,
                                  float orbitAngleRad, float bankDeg, bool clockwise)
{
    if (!vehicle || !vehicle->ptr) return;
    if (vehicle->ref <= 0 || !CAR_DEFINED(vehicle->ref)) return;

    CVehicle* pVeh = (CVehicle*)vehicle->ptr;

    // 1) Posicao primeiro (PUT_CAR_AT pode resetar orientacao)
    FREEZE_CAR_POSITION(vehicle->ref, true);
    PUT_CAR_AT(vehicle->ref, x, y, z);

    // 2) Orientacao na matriz DEPOIS (igual ApplyHeliOrbitOrientation do mod antigo)
    CMatrix* mat = pVeh->GetMatrix();
    if (!mat) return;

    float c = cosf(orbitAngleRad);
    float s = sinf(orbitAngleRad);

    float fx, fy, fz;
    float rx, ry, rz;
    if (!clockwise)
    {
        // Anti-horario: tangente (-sin, cos), direita = radial FORA
        // porta esquerda para o centro
        fx = -s; fy =  c; fz = 0.0f;
        rx =  c; ry =  s; rz = 0.0f;
    }
    else
    {
        // Horario: tangente oposta. right=(-c,-s) evita ficar de ponta-cabeca
        fx =  s; fy = -c; fz = 0.0f;
        rx = -c; ry = -s; rz = 0.0f;
    }

    float ux = 0.0f, uy = 0.0f, uz = 1.0f;

    // Bank: porta interna desce (para o centro/chao).
    // No horario o lado interno troca com o flip do right, entao inverte o sinal.
    float bank = clockwise ? -bankDeg : bankDeg;
    if (bank != 0.0f)
    {
        float b = bank * (float)M_PI / 180.0f;
        float cb = cosf(b);
        float sb = sinf(b);

        float nrx = rx * cb + ux * sb;
        float nry = ry * cb + uy * sb;
        float nrz = rz * cb + uz * sb;

        float nux = ux * cb - rx * sb;
        float nuy = uy * cb - ry * sb;
        float nuz = uz * cb - rz * sb;

        rx = nrx; ry = nry; rz = nrz;
        ux = nux; uy = nuy; uz = nuz;
    }

    mat->m_right.x = rx;    mat->m_right.y = ry;    mat->m_right.z = rz;
    mat->m_forward.x = fx;  mat->m_forward.y = fy;  mat->m_forward.z = fz;
    mat->m_up.x = ux;       mat->m_up.y = uy;       mat->m_up.z = uz;

    // Atualiza posicao na matriz tambem (sem mexer em heading via opcode)
    mat->m_pos.x = x; mat->m_pos.y = y; mat->m_pos.z = z;
    mat->pos.x = x;   mat->pos.y = y;   mat->pos.z = z;
    mat->px = x;      mat->py = y;      mat->pz = z;

    CSimpleTransform* place = pVeh->GetPlacement();
    if (place)
    {
        place->pos.x = x;
        place->pos.y = y;
        place->pos.z = z;
        // NAO setar place->heading — a orientacao completa ja esta na CMatrix.
    }
}

void DualPatrol::LoadSettings()
{
    EnsureFolder();

    std::string path = GetDualPatrolFolder() + "/settings.ini";
    bool loadedLocal = false;

    if (std::filesystem::exists(path))
    {
        IniReaderWriter ini;
        if (ini.LoadFromFile(path))
        {
            loadedLocal = true;
            selectedVehicleIndex = ini.GetInt("comboio", "vehicle_index", selectedVehicleIndex);
            selectedHeliIndex = ini.GetInt("heli", "heli_index", selectedHeliIndex);
            followDistance = (float)ini.GetDouble("comboio", "follow_distance", followDistance);
            showBlips = ini.GetBool("comboio", "show_blips", showBlips);
            followOnFoot = ini.GetBool("comboio", "follow_on_foot", followOnFoot);
            selectedOccupants = ini.GetInt("comboio", "occupants", selectedOccupants);
            selectedSkinIndex = ini.GetInt("comboio", "skin_index", selectedSkinIndex);
            selectedHeliMode = ini.GetInt("heli", "mode", selectedHeliMode);
            selectedHeliHeight = ini.GetInt("heli", "height", selectedHeliHeight);
            selectedHeliRadius = ini.GetInt("heli", "radius", selectedHeliRadius);
            selectedHeliSpeed = ini.GetInt("heli", "speed", selectedHeliSpeed);
            selectedHeliAngle = ini.GetInt("heli", "angle", selectedHeliAngle);
            selectedHeliDirection = ini.GetInt("heli", "direction", selectedHeliDirection);
            autoHeliEnabled = ini.GetBool("heli", "auto_heli", autoHeliEnabled);
            autoHeliOrbitSeconds = ini.GetInt("heli", "auto_heli_orbit_seconds", autoHeliOrbitSeconds);
        }
    }

    // Migracao unica: se so existia no settings.ini principal, le e salva no dualpatrol/
    if (!loadedLocal)
    {
        std::string mainPath = modData->GetFile("settings.ini");
        if (std::filesystem::exists(mainPath))
        {
            IniReaderWriter mainIni;
            if (mainIni.LoadFromFile(mainPath))
            {
                followDistance = (float)mainIni.GetDouble("dualpatrol", "follow_distance", followDistance);
                showBlips = mainIni.GetBool("dualpatrol", "show_blips", showBlips);
                selectedVehicleIndex = mainIni.GetInt("dualpatrol", "vehicle_index", selectedVehicleIndex);
                selectedHeliIndex = mainIni.GetInt("dualpatrol", "heli_index", selectedHeliIndex);
                selectedHeliMode = mainIni.GetInt("dualpatrol", "heli_mode", selectedHeliMode);
                selectedHeliHeight = mainIni.GetInt("dualpatrol", "heli_height", selectedHeliHeight);
                selectedHeliRadius = mainIni.GetInt("dualpatrol", "heli_radius", selectedHeliRadius);
                selectedHeliSpeed = mainIni.GetInt("dualpatrol", "heli_speed", selectedHeliSpeed);
                selectedHeliAngle = mainIni.GetInt("dualpatrol", "heli_angle", selectedHeliAngle);
                selectedHeliDirection = mainIni.GetInt("dualpatrol", "heli_direction", selectedHeliDirection);
            }
        }
    }

    if (selectedOccupants < 1) selectedOccupants = 1;
    if (selectedOccupants > 4) selectedOccupants = 4;
    if (selectedHeliRadius < 10) selectedHeliRadius = 10;
    // 1001/1002/1003 = modos de velocidade variavel
    auto isVar = [](int v) { return v == 1001 || v == 1002 || v == 1003 || v == 1004 || v == 999; };
    if (!isVar(selectedHeliSpeed))
    {
        if (selectedHeliSpeed < 10) selectedHeliSpeed = 10;
        if (selectedHeliSpeed > 200) selectedHeliSpeed = 200;
    }
    if (!isVar(selectedHeliHeight) && selectedHeliHeight < 50) selectedHeliHeight = 50;
    if (!isVar(selectedHeliRadius) && selectedHeliRadius < 10) selectedHeliRadius = 10;

    // Sempre garante o settings do dualpatrol atualizado (sem tocar no principal)
    SaveSettings();
}


void DualPatrol::SaveSettings()
{
    EnsureFolder();
    // Apenas data/dualpatrol/settings.ini — NAO grava no settings.ini principal
    std::string path = GetDualPatrolFolder() + "/settings.ini";
    IniReaderWriter ini;

    ini.SetInt("comboio", "vehicle_index", selectedVehicleIndex);
    ini.SetInt("heli", "heli_index", selectedHeliIndex);
    ini.SetDouble("comboio", "follow_distance", followDistance);
    ini.SetBool("comboio", "show_blips", showBlips);
    ini.SetBool("comboio", "follow_on_foot", followOnFoot);
    ini.SetInt("comboio", "occupants", selectedOccupants);
    ini.SetInt("comboio", "skin_index", selectedSkinIndex);
    ini.SetInt("heli", "mode", selectedHeliMode);
    ini.SetInt("heli", "height", selectedHeliHeight);
    ini.SetInt("heli", "radius", selectedHeliRadius);
    ini.SetInt("heli", "speed", selectedHeliSpeed);
    ini.SetInt("heli", "angle", selectedHeliAngle);
    ini.SetInt("heli", "direction", selectedHeliDirection);
    ini.SetBool("heli", "auto_heli", autoHeliEnabled);
    ini.SetInt("heli", "auto_heli_orbit_seconds", autoHeliOrbitSeconds);
    ini.SaveToFile(path);
}


void DualPatrol::Initialize()
{
    EnsureFolder();
    ReloadPoliceSkinsFromApoioP();

    EnsureFolder();
    LoadSettings();
}

bool DualPatrol::HasAnyUnit()
{
    return !escortVehicles.empty();
}

void DualPatrol::CheckIfVehiclesAreValid()
{
    for (int i = (int)escortVehicles.size() - 1; i >= 0; i--)
    {
        auto vehicle = escortVehicles[i];
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        {
            if (vehicle)
                g_heliStates.erase(vehicle->ref);
            escortVehicles.erase(escortVehicles.begin() + i);
        }
    }
}

void DualPatrol::RemoveAll()
{
    for (auto vehicle : escortVehicles)
    {
        if (!Vehicles::IsValid(vehicle)) continue;

        vehicle->HideBlip();
        if (CAR_DEFINED(vehicle->ref)) FREEZE_CAR_POSITION(vehicle->ref, false);
        g_heliStates.erase(vehicle->ref);
        g_escortOnFoot.erase(vehicle->ref);
        g_escortStandingStill.erase(vehicle->ref);
        g_escortStayAtLocation.erase(vehicle->ref);

        for (auto owner : vehicle->GetOwners())
        {
            auto ped = Peds::GetPed(owner);
            if (ped) ped->QueueDestroy();
        }
        vehicle->QueueDestroy(false);
    }
    escortVehicles.clear();
    g_heliStates.clear();
    BottomMessage::SetMessage("~y~Apoio removido", 2000);
}

void DualPatrol::RemoveVehiclesOnly()
{
    int removed = 0;
    for (int i = (int)escortVehicles.size() - 1; i >= 0; i--)
    {
        auto vehicle = escortVehicles[i];
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        {
            escortVehicles.erase(escortVehicles.begin() + i);
            continue;
        }

        bool isHeli = IsModelAPoliceHelicopter(vehicle->GetModelId()) ||
                      (g_heliStates.find(vehicle->ref) != g_heliStates.end());
        if (isHeli) continue;

        vehicle->HideBlip();
        FREEZE_CAR_POSITION(vehicle->ref, false);
        g_escortOnFoot.erase(vehicle->ref);
        g_escortStandingStill.erase(vehicle->ref);
        g_escortStayAtLocation.erase(vehicle->ref);

        for (auto owner : vehicle->GetOwners())
        {
            auto ped = Peds::GetPed(owner);
            if (ped) ped->QueueDestroy();
        }
        vehicle->QueueDestroy(false);
        escortVehicles.erase(escortVehicles.begin() + i);
        removed++;
    }

    if (removed > 0)
        BottomMessage::SetMessage("~y~Viaturas removidas", 2000);
    else
        BottomMessage::SetMessage("~y~Nenhuma viatura ativa", 2000);
}

void DualPatrol::RemoveHelisOnly()
{
    int removed = 0;
    for (int i = (int)escortVehicles.size() - 1; i >= 0; i--)
    {
        auto vehicle = escortVehicles[i];
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
        {
            escortVehicles.erase(escortVehicles.begin() + i);
            continue;
        }

        bool isHeli = IsModelAPoliceHelicopter(vehicle->GetModelId()) ||
                      (g_heliStates.find(vehicle->ref) != g_heliStates.end());
        if (!isHeli) continue;

        vehicle->HideBlip();
        FREEZE_CAR_POSITION(vehicle->ref, false);
        g_heliStates.erase(vehicle->ref);
        g_escortOnFoot.erase(vehicle->ref);
        g_escortStandingStill.erase(vehicle->ref);
        g_escortStayAtLocation.erase(vehicle->ref);

        for (auto owner : vehicle->GetOwners())
        {
            auto ped = Peds::GetPed(owner);
            if (ped) ped->QueueDestroy();
        }
        vehicle->QueueDestroy(false);
        escortVehicles.erase(escortVehicles.begin() + i);
        removed++;
    }

    if (removed > 0)
        BottomMessage::SetMessage("~y~Helicopteros removidos", 2000);
    else
        BottomMessage::SetMessage("~y~Nenhum helicoptero ativo", 2000);
}

void DualPatrol::SpawnEscortUnit(PoliceVehicleData* unit, bool forceHelicopter, const CVector* customSpawnPosition, bool stayAtLocation)
{
    if (!unit) return;

    fileLog->Log("DualPatrol: SpawnEscortUnit " + unit->name);

    // forceHelicopter = true quando vem do menu de Heli (apoioH.ini).
    // IsModelAPoliceHelicopter só olha data/police_vehicles/helicopters —
    // se o model_id do apoioH.ini não estiver cadastrado lá, o heli nascia no chão.
    bool isHelicopter = forceHelicopter || IsModelAPoliceHelicopter(unit->vehicleModelId);

    CVector spawnPosition;
    if (customSpawnPosition)
    {
        spawnPosition = *customSpawnPosition;
        if (!isHelicopter)
            spawnPosition = GET_CLOSEST_CAR_NODE(spawnPosition.x, spawnPosition.y, spawnPosition.z);
    }
    else
    {
        auto closePosition = GetPedPositionWithOffset(GetPlayerActor(), CVector(0, isHelicopter ? 40.0f : -12.0f, 0));
        spawnPosition = GET_CLOSEST_CAR_NODE(closePosition.x, closePosition.y, closePosition.z);
    }

    if (isHelicopter)
        spawnPosition.z += 35.0f;

    int vehicleModelId = unit->vehicleModelId;
    int skinModelId = unit->skinModelId;
    if (skinModelId <= 0 || ModelLoader::IsSpecialModel(skinModelId))
        skinModelId = 280; // ped policial padrao seguro
    if (vehicleModelId <= 0)
        vehicleModelId = isHelicopter ? 497 : 596;
    // Proteção: IDs de ped comuns (1-399) quase nunca são veículos válidos → evita crash em CColModel
    if (vehicleModelId > 0 && vehicleModelId < 400 && !isHelicopter)
    {
        fileLog->Error("DualPatrol: vehicleModelId " + std::to_string(vehicleModelId) + " parece ped/objeto, usando fallback");
        vehicleModelId = 596;
    }
    int occupants = unit->occupants;
    std::string unitName = unit->name;

    // Captura config do menu no momento do spawn
    int heliMode = selectedHeliMode;
    int heliHeight = selectedHeliHeight;
    int heliRadius = selectedHeliRadius;
    int heliSpeed = selectedHeliSpeed;
    int heliAngle = selectedHeliAngle;
    int heliDir = selectedHeliDirection;
    bool blips = showBlips;

    // Resolve remap escolhido no menu (0=Padrao, 1=Aleatorio, 2+=nome MultiRemap)
    std::string remapName = "";
    int remapIdx = forceHelicopter ? selectedHeliRemapIndex : selectedRemapIndex;
    if (multiRemap)
    {
        if (remapIdx == 1)
            remapName = "random";
        else if (remapIdx >= 2)
        {
            auto remaps = multiRemap->GetModelInfoRemaps(vehicleModelId);
            int ri = remapIdx - 2;
            if (ri >= 0 && ri < (int)remaps.size())
                remapName = remaps[ri];
        }
    }

    ModelLoader::AddModelToLoad(vehicleModelId);
    ModelLoader::AddModelToLoad(skinModelId, true); // farda apoioP pode ser 288 etc.
    ModelLoader::LoadAll([vehicleModelId, skinModelId, occupants, spawnPosition, isHelicopter, unitName,
                          heliMode, heliHeight, heliRadius, heliSpeed, heliAngle, heliDir, blips, remapName]() {
        // Garante que o modelo ainda está carregado (evita CColModel null em customs)
        if (!HAS_MODEL_LOADED(vehicleModelId))
        {
            REQUEST_MODEL(vehicleModelId);
            LOAD_REQUESTED_MODELS();
        }
        if (!HAS_MODEL_LOADED(vehicleModelId))
        {
            fileLog->Error("DualPatrol: modelo " + std::to_string(vehicleModelId) + " nao carregou (CColModel crash evitado)");
            BottomMessage::SetMessage("~r~Modelo da viatura nao carregou: " + std::to_string(vehicleModelId), 3000);
            return;
        }

        auto carRef = CREATE_CAR_AT(vehicleModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        if (!CAR_DEFINED(carRef))
        {
            fileLog->Error("DualPatrol: CREATE_CAR_AT falhou para model " + std::to_string(vehicleModelId));
            BottomMessage::SetMessage("~r~Falha ao criar viatura (modelo " + std::to_string(vehicleModelId) + ")", 2500);
            return;
        }

        // Aplica remap do MultiRemap se escolhido (opcional)
        if (multiRemap && !remapName.empty())
            multiRemap->SetVehicleRemap(carRef, remapName);

        auto car = Vehicles::RegisterVehicle(carRef);

        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, skinModelId);
        Peds::RegisterPed(driverRef);
        CLEAR_ACTOR_TASK(driverRef);

        int numOfPassengers = occupants - 1;
        if (numOfPassengers > 0)
        {
            for (int i = 0; i < numOfPassengers; i++)
            {
                auto passengerRef = CREATE_ACTOR_PEDTYPE_IN_CAR_PASSENGER_SEAT(carRef, PedType::Special, skinModelId, i);
                Peds::RegisterPed(passengerRef);
                CLEAR_ACTOR_TASK(passengerRef);
            }
        }

        if (isHelicopter)
        {
            SET_HELICOPTER_INSTANT_ROTOR_START(carRef);
            SET_CAR_ENGINE_OPERATION(carRef, true);

            HeliOrbitState st;
            st.mode = heliMode;
            if (st.mode < 0) st.mode = 0;
            if (st.mode > 2) st.mode = 2;

            // Altura
            if (IsVariableCode(heliHeight))
            {
                st.variableHeight = true;
                int code = (heliHeight == 999) ? 1004 : heliHeight;
                ApplyVariableMode(code, st.varHeightMin, st.varHeightMax, st.varHeight);
                st.varHeightDir = 1.0f;
                st.varHeightTimer = 0.0f;
                st.heightScale = st.varHeight / 100.0f;
            }
            else
            {
                st.variableHeight = false;
                st.heightScale = (float)heliHeight / 100.0f;
            }
            // Raio
            if (IsVariableCode(heliRadius))
            {
                st.variableRadius = true;
                int code = (heliRadius == 999) ? 1004 : heliRadius;
                ApplyVariableMode(code, st.varRadiusMin, st.varRadiusMax, st.varRadius);
                st.varRadiusDir = 1.0f;
                st.varRadiusTimer = 0.0f;
                st.radiusScale = st.varRadius / 100.0f;
            }
            else
            {
                st.variableRadius = false;
                st.radiusScale = (float)heliRadius / 100.0f;
            }
            // Velocidade
            if (IsVariableCode(heliSpeed))
            {
                st.variableSpeed = true;
                int code = (heliSpeed == 999) ? 1004 : heliSpeed;
                ApplyVariableMode(code, st.varSpeedMin, st.varSpeedMax, st.varSpeed);
                st.varSpeedDir = 1.0f;
                st.varSpeedTimer = 0.0f;
                st.speedScale = st.varSpeed / 100.0f;
            }
            else
            {
                st.variableSpeed = false;
                st.speedScale = (float)heliSpeed / 100.0f;
            }
            st.bankDeg = (float)heliAngle;
            st.clockwise = (heliDir == 1);
            st.fixedCenter = (st.mode == 2); // orbit lock
            st.variableRadius = (heliRadius == 999) && (st.mode != 0);
            st.variableHeight = (heliHeight == 999) && (st.mode != 0);
            st.varRadius = 115.0f;
            st.varHeight = 100.0f;
            st.varRadiusDir = 1.0f;
            st.varHeightDir = 1.0f;
            st.orbitAngle = 0.0f;
            st.followInit = false;

            auto playerPos = GetPlayerPosition();
            st.orbitCenter = playerPos;

            // Spawn um pouco afastado na orbita
            if (st.mode != 0)
            {
                float r = 75.0f * (st.variableRadius ? (st.varRadius / 100.0f) : st.radiusScale);
                float h = 42.0f * (st.variableHeight ? (st.varHeight / 100.0f) : st.heightScale);
                float x = playerPos.x + cosf(st.orbitAngle) * r;
                float y = playerPos.y + sinf(st.orbitAngle) * r;
                float z = playerPos.z + h;
                PUT_CAR_AT(carRef, x, y, z);
            }

            g_heliStates[carRef] = st;
        }

        car->SetOwners();
        if (blips)
            car->ShowBlip(COLOR_POLICE);

        for (auto pedRef : car->GetCurrentOccupants())
        {
            ModelLoader::AddModelToLoad(346);
            ModelLoader::LoadAll([pedRef]() {
                if (ACTOR_DEFINED(pedRef))
                    GIVE_ACTOR_WEAPON(pedRef, 22, 100);
            });
        }

        car->flags.isDualPatrol = true;
        DualPatrol::escortVehicles.push_back(car);
        if (stayAtLocation)
            g_escortStayAtLocation[carRef] = true;

        BottomMessage::SetMessage("~b~Apoio: " + unitName, 2500);
    });
}

void DualPatrol::SpawnEscortHeli(PoliceVehicleData* unit)
{
    if (!unit) return;
    // Sempre força tratamento de helicóptero (independente da lista police_vehicles)
    SpawnEscortUnit(unit, true);
}

void DualPatrol::UpdateSirenSync()
{
    if (escortVehicles.empty())
        return;

    int playerActor = GET_PLAYER_ACTOR(0);
    if (!ACTOR_DEFINED(playerActor))
        return;

    static bool lastSirenOn = false;
    static bool hasLast = false;

    bool sirenOn = false;
    if (IS_CHAR_IN_ANY_CAR(playerActor))
    {
        int playerCar = ACTOR_USED_CAR(playerActor);
        if (CAR_DEFINED(playerCar))
        {
            auto* playerVeh = Vehicles::GetVehicle(playerCar);
            if (playerVeh && playerVeh->ptr)
                sirenOn = ((*(uint8_t*)((uintptr_t)playerVeh->ptr + 0x42D + 4)) >> 7) != 0;
        }
    }

    if (hasLast && sirenOn == lastSirenOn)
        return;
    hasLast = true;
    lastSirenOn = sirenOn;

    for (auto* vehicle : escortVehicles)
    {
        if (!vehicle || !Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
            continue;
        if (IsModelAPoliceHelicopter(vehicle->GetModelId()))
            continue;
        ENABLE_CAR_SIREN(vehicle->ref, sirenOn);
    }
}



void DualPatrol::Update(int dt)
{
    CheckIfVehiclesAreValid();


    // ---- Auto Heli pos-ocorrencia: orbit -> subir/expandir -> sumir ----
    if (g_autoHeli.phase == 1 || g_autoHeli.phase == 2)
    {
        // Descobre o carRef do auto heli se ainda nao sabe
        if (g_autoHeli.carRef <= 0)
        {
            for (auto v : escortVehicles)
            {
                if (!Vehicles::IsValid(v) || !CAR_DEFINED(v->ref)) continue;
                if (g_heliStates.find(v->ref) != g_heliStates.end())
                {
                    g_autoHeli.carRef = v->ref;
                    break;
                }
            }
        }

        if (g_autoHeli.carRef > 0 && CAR_DEFINED(g_autoHeli.carRef))
        {
            auto it = g_heliStates.find(g_autoHeli.carRef);
            if (it != g_heliStates.end())
            {
                g_autoHeli.timer += (float)dt;

                if (g_autoHeli.phase == 1)
                {
                    // Orbitando pelo tempo configurado
                    if (g_autoHeli.timer >= (float)autoHeliOrbitSeconds * 1000.0f)
                    {
                        g_autoHeli.phase = 2;
                        g_autoHeli.timer = 0.0f;
                        g_autoHeli.leaveRadiusBoost = 0.0f;
                        g_autoHeli.leaveHeightBoost = 0.0f;
                    }
                }
                else if (g_autoHeli.phase == 2)
                {
                    // Sobe e abre o raio ~5m/s ate sumir
                    float sec = (float)dt / 1000.0f;
                    g_autoHeli.leaveRadiusBoost += 5.0f * sec;
                    g_autoHeli.leaveHeightBoost += 5.0f * sec;

                    // Aplica boost no estado de orbita (altura/raio efetivos no SetHeliWorldTransform via scales)
                    // Aumenta radiusScale e heightScale progressivamente
                    it->second.radiusScale = (it->second.radiusScale <= 0.01f ? 1.0f : it->second.radiusScale) + (5.0f * sec) / 75.0f;
                    it->second.heightScale = (it->second.heightScale <= 0.01f ? 1.0f : it->second.heightScale) + (5.0f * sec) / 42.0f;

                    // Depois de ~12s saindo ou muito longe, remove
                    auto veh = Vehicles::GetVehicle(g_autoHeli.carRef);
                    float dist = veh ? distanceBetweenPoints(veh->GetPosition(), GetPlayerPosition()) : 999.0f;
                    if (g_autoHeli.timer > 12000.0f || dist > 280.0f)
                    {
                        if (veh)
                        {
                            for (auto owner : veh->GetOwners())
                            {
                                auto ped = Peds::GetPed(owner);
                                if (ped) ped->QueueDestroy();
                            }
                            g_heliStates.erase(g_autoHeli.carRef);
                            veh->QueueDestroy(false);
                        }
                        g_autoHeli = AutoHeliState();
                    }
                }
            }
        }
        else if (g_autoHeli.phase != 0 && g_autoHeli.timer > 2000.0f)
        {
            // Heli nao encontrado / ja sumiu
            g_autoHeli = AutoHeliState();
        }
        else
        {
            g_autoHeli.timer += (float)dt;
        }
    }

    if (escortVehicles.empty()) return;

    UpdateSirenSync();

    int playerActor = GET_PLAYER_ACTOR(0);
    if (!ACTOR_DEFINED(playerActor)) return;

    bool playerInCar = IS_CHAR_IN_ANY_CAR(playerActor);
    int playerCar = playerInCar ? ACTOR_USED_CAR(playerActor) : -1;

    static int reissueTimer = 0;
    reissueTimer += dt;
    // Reissue a cada 1s (antes 2s) para a IA não “esquecer” a task
    bool shouldReissue = reissueTimer >= 1000;
    if (shouldReissue)
        reissueTimer = 0;

    for (size_t i = 0; i < escortVehicles.size(); i++)
    {
        auto vehicle = escortVehicles[i];
        if (!Vehicles::IsValid(vehicle) || !CAR_DEFINED(vehicle->ref))
            continue;

        int carRef = vehicle->ref;
        // Considera heli se estiver na lista police_vehicles OU se tiver estado de órbita
        // (permite models só configurados em dualpatrol/apoioH.ini)
        bool isHeli = IsModelAPoliceHelicopter(vehicle->GetModelId()) ||
                      (g_heliStates.find(carRef) != g_heliStates.end());

        float distPlayer = distanceBetweenPoints(vehicle->GetPosition(), GetPlayerPosition());
        if (distPlayer > 350.0f)
        {
            for (auto owner : vehicle->GetOwners())
            {
                auto ped = Peds::GetPed(owner);
                if (ped) ped->QueueDestroy();
            }
            g_heliStates.erase(carRef);
            g_escortOnFoot.erase(carRef);
            g_escortStandingStill.erase(carRef);
            g_escortStayAtLocation.erase(carRef);
            vehicle->QueueDestroy(false);
            continue;
        }

        if (isHeli)
        {
            SET_CAR_ENGINE_OPERATION(carRef, true);
            SET_HELICOPTER_INSTANT_ROTOR_START(carRef);

            // Sem limpar a task do piloto, a AI sobrescreve PUT_CAR_AT
            // (heli gira no eixo e desce — sintoma classico no mobile)
            int driverRef = GET_DRIVER_OF_CAR(carRef);
            if (ACTOR_DEFINED(driverRef))
                CLEAR_ACTOR_TASK(driverRef);

            auto it = g_heliStates.find(carRef);
            if (it == g_heliStates.end())
            {
                if (shouldReissue)
                {
                    int followCar = playerInCar ? playerCar : -1;
                    HELI_FOLLOW(carRef, playerActor, followCar, 22.0f);
                }
                continue;
            }

            HeliOrbitState& st = it->second;
            CVector playerPos = GetPedPosition(playerActor);

            if (st.mode == 0)
            {
                // FOLLOW: usa HELI_FOLLOW
                if (shouldReissue || !st.followInit)
                {
                    int followCar = playerInCar ? playerCar : -1;
                    HELI_FOLLOW(carRef, playerActor, followCar, 22.0f);
                    st.followInit = true;
                }
            }
            else
            {
                // ORBIT / ORBIT LOCK — matrix direta (unica forma estavel no mobile)
                float dirSign = st.clockwise ? -1.0f : 1.0f;
                st.orbitAngle += dirSign * 0.00045f * st.speedScale * (float)dt;
                if (st.orbitAngle > 6.2831853f) st.orbitAngle -= 6.2831853f;
                if (st.orbitAngle < 0.0f) st.orbitAngle += 6.2831853f;

                // Raio/Altura/Velocidade variavel: +10/-10 a cada 5s
                auto stepVar = [&](float& timer, float& val, float& dir, float vmin, float vmax, float& scaleOut) {
                    timer += (float)dt;
                    if (timer >= 5000.0f)
                    {
                        timer = 0.0f;
                        val += dir * 10.0f;
                        if (val >= vmax) { val = vmax; dir = -1.0f; }
                        if (val <= vmin) { val = vmin; dir = 1.0f; }
                        scaleOut = val / 100.0f;
                    }
                };
                if (st.variableRadius)
                    stepVar(st.varRadiusTimer, st.varRadius, st.varRadiusDir, st.varRadiusMin, st.varRadiusMax, st.radiusScale);
                if (st.variableHeight)
                    stepVar(st.varHeightTimer, st.varHeight, st.varHeightDir, st.varHeightMin, st.varHeightMax, st.heightScale);
                if (st.variableSpeed)
                    stepVar(st.varSpeedTimer, st.varSpeed, st.varSpeedDir, st.varSpeedMin, st.varSpeedMax, st.speedScale);

                CVector center = st.fixedCenter ? st.orbitCenter : playerPos;

                float radiusPct = st.variableRadius ? st.varRadius : (st.radiusScale * 100.0f);
                float heightPct = st.variableHeight ? st.varHeight : (st.heightScale * 100.0f);
                float radius = 75.0f * (radiusPct / 100.0f);
                float height = 42.0f * (heightPct / 100.0f);
                if (radius < 15.0f) radius = 15.0f;
                // Orbit lock / ocorrencia: nunca deixa colar no chao
                float minH = st.fixedCenter ? 30.0f : 15.0f;
                if (height < minH) height = minH;

                float x = center.x + cosf(st.orbitAngle) * radius;
                float y = center.y + sinf(st.orbitAngle) * radius;
                float z = center.z + height;

                SetHeliWorldTransform(vehicle, x, y, z, st.orbitAngle, st.bankDeg, st.clockwise);
            }
        }
        else
        {
            // Viatura terrestre
            if (g_escortStayAtLocation[carRef])
            {
                // Unidade de apoio desta ocorrencia fica estacionada no local.
                // Nao segue o jogador nem troca para modo a pe.
                SET_CAR_TRAFFIC_BEHAVIOUR(carRef, DrivingMode::AvoidCars);
                SET_CAR_MAX_SPEED(carRef, 0.0f);
                CAR_TURN_OFF_ENGINE(carRef);
                continue;
            }

            bool onFoot = g_escortOnFoot[carRef];

            if (playerInCar && CAR_DEFINED(playerCar))
            {
                // Jogador voltou pro carro: se estavam a pe, mandar entrar de novo
                if (onFoot)
                {
                    auto owners = vehicle->GetOwners();
                    int seat = 0;
                    for (size_t oi = 0; oi < owners.size(); oi++)
                    {
                        int pedRef = owners[oi];
                        if (!ACTOR_DEFINED(pedRef)) continue;
                        if (IS_CHAR_IN_ANY_CAR(pedRef)) continue;
                        CLEAR_ACTOR_TASK(pedRef);
                        if (oi == 0)
                            ENTER_CAR_AS_DRIVER_AS_ACTOR(pedRef, carRef, 10000);
                        else
                            ACTOR_ENTER_CAR_PASSENGER_SEAT(pedRef, carRef, 10000, seat++);
                    }
                    g_escortOnFoot[carRef] = false;
                    g_escortStandingStill[carRef] = false;
                    onFoot = false;
                }

                if (!onFoot && shouldReissue)
                {
                    // Cada viatura segue a da frente (ou o jogador se for a 1ª)
                    // com a MESMA distância configurada — sem acumular +i*2
                    int targetCar = playerCar;
                    if (i > 0)
                    {
                        auto prev = escortVehicles[i - 1];
                        if (Vehicles::IsValid(prev) && CAR_DEFINED(prev->ref)
                            && !IsModelAPoliceHelicopter(prev->GetModelId())
                            && !g_escortOnFoot[prev->ref])
                            targetCar = prev->ref;
                    }

                    float baseDist = followDistance;
                    if (baseDist < 5.0f) baseDist = 5.0f;

                    float gap = distanceBetweenPoints(vehicle->GetPosition(), GetCarPosition(playerCar));
                    float playerSpeed = CAR_SPEED(playerCar);

                    if (gap > 40.0f)
                    {
                        // Longe: ignora trânsito e acompanha/supera a velocidade do jogador
                        // para conseguir alcançar (sem teleporte, sem max fixo do chase)
                        SET_CAR_TRAFFIC_BEHAVIOUR(carRef, DrivingMode::PloughThrough);
                        float targetMax = playerSpeed + 15.0f;
                        if (gap > 80.0f)
                            targetMax = playerSpeed + 25.0f;
                        if (targetMax < 20.0f) targetMax = 20.0f;
                        SET_CAR_MAX_SPEED(carRef, targetMax);
                        // Distância um pouco menor ajuda a native a priorizar fechar o gap
                        baseDist = followDistance * 0.6f;
                        if (baseDist < 5.0f) baseDist = 5.0f;
                    }
                    else
                    {
                        // Perto: formação normal, velocidade alinhada à do jogador
                        SET_CAR_TRAFFIC_BEHAVIOUR(carRef, DrivingMode::AvoidCars);
                        float targetMax = playerSpeed + 5.0f;
                        if (targetMax < 15.0f) targetMax = 15.0f;
                        SET_CAR_MAX_SPEED(carRef, targetMax);
                    }

                    CAR_FOLLOW_CAR(carRef, targetCar, baseDist);
                }
            }
            else
            {
                // Jogador a pe
                if (!onFoot)
                {
                    // Desce da viatura uma vez
                    vehicle->MakeOccupantsLeave();
                    g_escortOnFoot[carRef] = true;
                    g_escortStandingStill[carRef] = false;
                    onFoot = true;
                }

                if (onFoot)
                {
                    auto owners = vehicle->GetOwners();
                    if (followOnFoot)
                    {
                        // Seguir o jogador a pe (config follow_on_foot do menu/ini)
                        if (shouldReissue)
                        {
                            for (auto pedRef : owners)
                            {
                                if (!ACTOR_DEFINED(pedRef)) continue;
                                if (IS_CHAR_IN_ANY_CAR(pedRef)) continue;
                                CLEAR_ACTOR_TASK(pedRef);
                                TASK_FOLLOW_FOOTSTEPS(pedRef, playerActor);
                            }
                        }
                        g_escortStandingStill[carRef] = false;
                    }
                    else
                    {
                        // Ficar parado ao lado da propria viatura (so uma vez)
                        if (!g_escortStandingStill[carRef])
                        {
                            for (auto pedRef : owners)
                            {
                                if (!ACTOR_DEFINED(pedRef)) continue;
                                if (IS_CHAR_IN_ANY_CAR(pedRef)) continue;
                                CLEAR_ACTOR_TASK(pedRef);
                            }
                            g_escortStandingStill[carRef] = true;
                        }
                    }
                }
            }
        }
    }
}

void DualPatrol::CreateMenu()
{
    EnsureFolder();
    ReloadPoliceSkinsFromApoioP(); // sempre recarrega apoioP.ini (novos peds no menu)
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Comboio");

    auto list = LoadApoioVehiclesFromIni("apoioV.ini", false);
    auto skinList = LoadApoioVehiclesFromIni("apoioP.ini", false);

    // Fallback skins from apoioP if empty - generate default file
    if (skinList.empty())
    {
        // Will use built-in defaults below
    }

    if (list.empty())
    {
        window->AddText("~r~Nenhum veiculo em data/dualpatrol/apoioV.ini");
        window->AddText("Crie secoes [VEICULO] com name e vehicle_id");
    }
    else
    {
        if (selectedVehicleIndex < 0 || selectedVehicleIndex >= (int)list.size())
            selectedVehicleIndex = 0;

        {
            auto options = window->AddOptions("Viatura");
            for (size_t i = 0; i < list.size(); i++)
                options->AddOption(list[i].name, (int)i);
            options->SetOptionIndex(selectedVehicleIndex);
            options->onOptionChange->Add([options]() {
                selectedVehicleIndex = options->GetCurrentOptionValue();
                selectedRemapIndex = 0; // lista de remap muda com o modelo
            });
        }

        {
            auto options = window->AddOptions("Blip no mapa");
            options->AddOption("Off", 0);
            options->AddOption("On", 1);
            options->SetOptionIndex(showBlips ? 1 : 0);
            options->onOptionChange->Add([options]() {
                showBlips = (options->GetCurrentOptionValue() == 1);
            });
        }

        {
            auto options = window->AddOptions("Seguir a pe");
            options->AddOption("Off", 0);
            options->AddOption("On", 1);
            options->SetOptionIndex(followOnFoot ? 1 : 0);
            options->onOptionChange->Add([options]() {
                followOnFoot = (options->GetCurrentOptionValue() == 1);
            });
        }

        {
            // Distancia: 2,4,6,8,10 depois 15,20,25,30
            auto options = window->AddOptions("Distancia");
            std::vector<int> dists = {2,4,6,8,10,15,20,25,30};
            int selectedIdx = 0;
            for (size_t i = 0; i < dists.size(); i++)
            {
                options->AddOption(std::to_string(dists[i]) + " m", dists[i]);
                if ((int)followDistance == dists[i])
                    selectedIdx = (int)i;
            }
            options->SetOptionIndex(selectedIdx);
            options->onOptionChange->Add([options]() {
                followDistance = (float)options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Policiais na viatura");
            for (int n = 1; n <= 4; n++)
                options->AddOption(std::to_string(n), n);
            int idx = selectedOccupants - 1;
            if (idx < 0) idx = 0;
            if (idx > 3) idx = 3;
            options->SetOptionIndex(idx);
            options->onOptionChange->Add([options]() {
                selectedOccupants = options->GetCurrentOptionValue();
                if (selectedOccupants < 1) selectedOccupants = 1;
                if (selectedOccupants > 4) selectedOccupants = 4;
            });
        }

        {
            auto options = window->AddOptions("Farda");
            // Lista = g_policeSkins (carregada de data/dualpatrol/apoioP.ini)
            if (selectedSkinIndex < 0 || selectedSkinIndex >= (int)g_policeSkins.size())
                selectedSkinIndex = 0;
            for (size_t i = 0; i < g_policeSkins.size(); i++)
            {
                auto& s = g_policeSkins[i];
                options->AddOption(s.name + " (" + std::to_string(s.id) + ")", (int)i);
            }
            options->SetOptionIndex(selectedSkinIndex);
            options->onOptionChange->Add([options]() {
                selectedSkinIndex = options->GetCurrentOptionValue();
            });
        }

                // Remap do MultiRemap para a viatura selecionada (menu nao fecha)
        {
            auto options = window->AddOptions("Remap");
            options->AddOption("Padrao", 0);
            options->AddOption("Aleatorio", 1);
            if (multiRemap && !list.empty())
            {
                int mid = list[selectedVehicleIndex].vehicleModelId;
                auto remaps = multiRemap->GetModelInfoRemaps(mid);
                for (size_t i = 0; i < remaps.size(); i++)
                    options->AddOption(remaps[i], (int)i + 2);
            }
            if (selectedRemapIndex < 0)
                selectedRemapIndex = 0;
            options->SetOptionIndex(selectedRemapIndex);
            options->onOptionChange->Add([options]() {
                selectedRemapIndex = options->GetCurrentOptionValue();
            });
            // Ao trocar viatura, reseta remap para Padrao (lista pode ser de outro model)
            // A lista de nomes e da viatura atual no momento da abertura do menu;
            // no spawn o indice e resolvido de novo para o model escolhido.
        }

        {
            auto button = window->AddButton("Spawnar unidade");
            button->onClick->Add([window, list, skinList]() {
                DualPatrol::SaveSettings();
                // Mantém o menu aberto após spawn
                if (selectedVehicleIndex < 0 || selectedVehicleIndex >= (int)list.size())
                {
                    BottomMessage::SetMessage("~r~Veiculo invalido", 2000);
                    return;
                }
                static PoliceVehicleData tmp;
                tmp.name = list[selectedVehicleIndex].name;
                tmp.vehicleModelId = list[selectedVehicleIndex].vehicleModelId;

                // Skin from apoioP.ini (g_policeSkins)
                ReloadPoliceSkinsFromApoioP();
                int skinId = 280;
                if (!g_policeSkins.empty())
                {
                    int idx = selectedSkinIndex;
                    if (idx < 0) idx = 0;
                    if (idx >= (int)g_policeSkins.size()) idx = 0;
                    skinId = g_policeSkins[idx].id;
                }
                tmp.skinModelId = skinId;
                tmp.occupants = selectedOccupants;
                DualPatrol::SpawnEscortUnit(&tmp);
            });
        }
    }

    {
        auto button = window->AddButton("Apagar todos");
        button->onClick->Add([window]() {
            DualPatrol::SaveSettings();
            DualPatrol::RemoveVehiclesOnly();
        });
    }

    {
        auto button = window->AddButton("~y~Voltar");
        button->onClick->Add([window]() {
            DualPatrol::SaveSettings();
            window->Close();
            OptionsWindow::OpenWindow();
        });
    }
}

void DualPatrol::CreateHeliMenu()
{
    EnsureFolder();
    auto window = menuSZK->CreateWindow(g_defaultMenuPosition.x, g_defaultMenuPosition.y, 800, "Apoio Helicoptero");

    auto list = LoadApoioVehiclesFromIni("apoioH.ini", true);
    if (list.empty())
    {
        window->AddText("~r~Nenhum heli em data/dualpatrol/apoioH.ini");
    }
    else
    {
        if (selectedHeliIndex < 0 || selectedHeliIndex >= (int)list.size())
            selectedHeliIndex = 0;

        {
            auto options = window->AddOptions("Helicoptero");
            for (size_t i = 0; i < list.size(); i++)
                options->AddOption(list[i].name, (int)i);
            options->SetOptionIndex(selectedHeliIndex);
            options->onOptionChange->Add([options]() {
                selectedHeliIndex = options->GetCurrentOptionValue();
                selectedHeliRemapIndex = 0;
            });
        }

        {
            auto options = window->AddOptions("Modo");
            options->AddOption("follow", 0);
            options->AddOption("orbit", 1);
            options->AddOption("orbit Lock", 2);
            options->SetOptionIndex(selectedHeliMode);
            options->onOptionChange->Add([options]() {
                selectedHeliMode = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Altura");
            int idx = 0;
            int sel = 0;
            for (int h = 50; h <= 150; h += 10, idx++)
            {
                options->AddOption(std::to_string(h), h);
                if (selectedHeliHeight == h) sel = idx;
            }
            options->AddOption("variavel 1 (10-50)", 1001);
            if (selectedHeliHeight == 1001) sel = idx; idx++;
            options->AddOption("variavel 2 (50-100)", 1002);
            if (selectedHeliHeight == 1002) sel = idx; idx++;
            options->AddOption("variavel 3 (100-160)", 1003);
            if (selectedHeliHeight == 1003) sel = idx; idx++;
            options->AddOption("variavel 4 (10-150)", 1004);
            if (selectedHeliHeight == 1004) sel = idx;
            options->SetOptionIndex(sel);
            options->onOptionChange->Add([options]() {
                selectedHeliHeight = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Raio (orbita)");
            int idx = 0;
            int sel = 0;
            for (int r = 10; r <= 150; r += 10, idx++)
            {
                options->AddOption(std::to_string(r), r);
                if (selectedHeliRadius == r) sel = idx;
            }
            options->AddOption("variavel 1 (10-50)", 1001);
            if (selectedHeliRadius == 1001) sel = idx; idx++;
            options->AddOption("variavel 2 (50-100)", 1002);
            if (selectedHeliRadius == 1002) sel = idx; idx++;
            options->AddOption("variavel 3 (100-160)", 1003);
            if (selectedHeliRadius == 1003) sel = idx; idx++;
            options->AddOption("variavel 4 (10-150)", 1004);
            if (selectedHeliRadius == 1004) sel = idx;
            options->SetOptionIndex(sel);
            options->onOptionChange->Add([options]() {
                selectedHeliRadius = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Velocidade");
            int idx = 0;
            int sel = 0;
            for (int s = 10; s <= 200; s += 10, idx++)
            {
                options->AddOption(std::to_string(s), s);
                if (selectedHeliSpeed == s) sel = idx;
            }
            options->AddOption("variavel 1 (10-50)", 1001);
            if (selectedHeliSpeed == 1001) sel = idx; idx++;
            options->AddOption("variavel 2 (50-100)", 1002);
            if (selectedHeliSpeed == 1002) sel = idx; idx++;
            options->AddOption("variavel 3 (100-160)", 1003);
            if (selectedHeliSpeed == 1003) sel = idx; idx++;
            options->AddOption("variavel 4 (10-150)", 1004);
            if (selectedHeliSpeed == 1004) sel = idx;
            options->SetOptionIndex(sel);
            options->onOptionChange->Add([options]() {
                selectedHeliSpeed = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Angulo (bank)");
            int idx = 0;
            int sel = 0;
            for (int a = 0; a <= 60; a += 5, idx++)
            {
                options->AddOption(std::to_string(a), a);
                if (selectedHeliAngle == a) sel = idx;
            }
            options->SetOptionIndex(sel);
            options->onOptionChange->Add([options]() {
                selectedHeliAngle = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Sentido");
            options->AddOption("anti-horario", 0);
            options->AddOption("horario", 1);
            options->SetOptionIndex(selectedHeliDirection);
            options->onOptionChange->Add([options]() {
                selectedHeliDirection = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Blip no mapa");
            options->AddOption("Off", 0);
            options->AddOption("On", 1);
            options->SetOptionIndex(showBlips ? 1 : 0);
            options->onOptionChange->Add([options]() {
                showBlips = (options->GetCurrentOptionValue() == 1);
            });
        }

        {
        {
            auto options = window->AddOptions("Auto Heli pos-ocorrencia");
            options->AddOption("Off", 0);
            options->AddOption("On", 1);
            options->SetOptionIndex(autoHeliEnabled ? 1 : 0);
            options->onOptionChange->Add([options]() {
                autoHeliEnabled = (options->GetCurrentOptionValue() == 1);
            });
        }

        {
            auto options = window->AddOptions("Tempo orbita auto (s)");
            int idx = 0;
            int sel = 0;
            for (int t = 5; t <= 20; t += 5, idx++)
            {
                options->AddOption(std::to_string(t) + " s", t);
                if (autoHeliOrbitSeconds == t) sel = idx;
            }
            options->SetOptionIndex(sel);
            options->onOptionChange->Add([options]() {
                autoHeliOrbitSeconds = options->GetCurrentOptionValue();
            });
        }

        {
            auto options = window->AddOptions("Remap");
            options->AddOption("Padrao", 0);
            options->AddOption("Aleatorio", 1);
            if (multiRemap && !list.empty())
            {
                int mid = list[selectedHeliIndex].vehicleModelId;
                auto remaps = multiRemap->GetModelInfoRemaps(mid);
                for (size_t i = 0; i < remaps.size(); i++)
                    options->AddOption(remaps[i], (int)i + 2);
            }
            if (selectedHeliRemapIndex < 0)
                selectedHeliRemapIndex = 0;
            options->SetOptionIndex(selectedHeliRemapIndex);
            options->onOptionChange->Add([options]() {
                selectedHeliRemapIndex = options->GetCurrentOptionValue();
            });
        }

                        auto button = window->AddButton("Spawnar helicoptero");
            button->onClick->Add([window, list]() {
                DualPatrol::SaveSettings();
                // Mantém o menu aberto após spawn
                if (selectedHeliIndex < 0 || selectedHeliIndex >= (int)list.size())
                    return;
                static PoliceVehicleData tmp;
                tmp.name = list[selectedHeliIndex].name;
                tmp.vehicleModelId = list[selectedHeliIndex].vehicleModelId;
                tmp.skinModelId = list[selectedHeliIndex].skinModelId;
                // Águia por padrão só 1 parceiro (piloto)
                tmp.occupants = 1;
                DualPatrol::SpawnEscortHeli(&tmp);
            });
        }
    }

    {
        auto button = window->AddButton("Apagar todos");
        button->onClick->Add([window]() {
            DualPatrol::SaveSettings();
            DualPatrol::RemoveHelisOnly();
        });
    }

    {
        auto button = window->AddButton("~y~Voltar");
        button->onClick->Add([window]() {
            DualPatrol::SaveSettings();
            window->Close();
            OptionsWindow::OpenWindow();
        });
    }
}


void DualPatrol::SpawnAutoHeliAfterCallout()
{
    if (!autoHeliEnabled) return;
    if (g_autoHeli.phase != 0) return; // ja tem um ativo

    auto list = LoadApoioVehiclesFromIni("apoioH.ini", true);
    if (list.empty())
    {
        BottomMessage::SetMessage("~r~Nenhum heli em apoioH.ini para auto heli", 2500);
        return;
    }

    int idx = selectedHeliIndex;
    if (idx < 0 || idx >= (int)list.size()) idx = 0;

    static PoliceVehicleData tmp;
    tmp.name = list[idx].name;
    tmp.vehicleModelId = list[idx].vehicleModelId;
    tmp.skinModelId = list[idx].skinModelId > 0 ? list[idx].skinModelId : 280;
    tmp.occupants = 1;

    // Forca modo orbit com as configs do menu
    int prevMode = selectedHeliMode;
    selectedHeliMode = 1; // orbit
    SpawnEscortHeli(&tmp);
    selectedHeliMode = prevMode;

    g_autoHeli.phase = 1;
    g_autoHeli.timer = 0.0f;
    g_autoHeli.leaveRadiusBoost = 0.0f;
    g_autoHeli.leaveHeightBoost = 0.0f;
    g_autoHeli.carRef = -1; // sera preenchido no Update quando detectar

    BottomMessage::SetMessage("~b~Aguia sobrevoando o local", 2500);
}


// Heli orbit lock fixo (ex.: assalto a banco) — ignora menu, usa config passada
void DualPatrol::SpawnOrbitLockHeliAt(CVector center, int vehicleModelId, int heightMenu, int radiusMenu, int speedMenuOrVar, int angleDeg, bool clockwise)
{
    int skinModelId = 280;
    CVector spawnPosition = center;
    spawnPosition.z += 35.0f;

    ModelLoader::AddModelToLoad(vehicleModelId);
    ModelLoader::AddModelToLoad(skinModelId, true); // farda apoioP pode ser 288 etc.
    ModelLoader::LoadAll([vehicleModelId, skinModelId, spawnPosition, center, heightMenu, radiusMenu, speedMenuOrVar, angleDeg, clockwise]() {
        if (!HAS_MODEL_LOADED(vehicleModelId))
        {
            REQUEST_MODEL(vehicleModelId);
            LOAD_REQUESTED_MODELS();
        }
        if (!HAS_MODEL_LOADED(vehicleModelId))
        {
            fileLog->Error("DualPatrol: SpawnOrbitLockHeliAt modelo " + std::to_string(vehicleModelId) + " nao carregou");
            BottomMessage::SetMessage("~r~Modelo Aguia nao carregou", 3000);
            return;
        }
        auto carRef = CREATE_CAR_AT(vehicleModelId, spawnPosition.x, spawnPosition.y, spawnPosition.z);
        if (!CAR_DEFINED(carRef))
        {
            fileLog->Log("DualPatrol: SpawnOrbitLockHeliAt FALHOU criar carro model=" + std::to_string(vehicleModelId));
            BottomMessage::SetMessage("~r~Falha ao spawnar Aguia", 3000);
            return;
        }

        auto car = Vehicles::RegisterVehicle(carRef);
        auto driverRef = CREATE_ACTOR_PEDTYPE_IN_CAR_DRIVERSEAT(carRef, PedType::Special, skinModelId);
        if (!ACTOR_DEFINED(driverRef))
        {
            fileLog->Log("DualPatrol: SpawnOrbitLockHeliAt FALHOU piloto");
            BottomMessage::SetMessage("~r~Falha piloto Aguia", 3000);
            return;
        }
        Peds::RegisterPed(driverRef);
        CLEAR_ACTOR_TASK(driverRef);

        SET_CAR_ENGINE_OPERATION(carRef, true);
        SET_HELICOPTER_INSTANT_ROTOR_START(carRef);

        HeliOrbitState st;
        st.mode = 2; // orbit lock
        st.fixedCenter = true;
        st.orbitCenter = center;
        st.heightScale = (float)heightMenu / 100.0f;
        st.radiusScale = (float)radiusMenu / 100.0f;
        st.bankDeg = (float)angleDeg;
        st.clockwise = clockwise;
        st.orbitAngle = 0.0f;

        if (IsVariableCode(speedMenuOrVar))
        {
            st.variableSpeed = true;
            int code = (speedMenuOrVar == 999) ? 1004 : speedMenuOrVar;
            ApplyVariableMode(code, st.varSpeedMin, st.varSpeedMax, st.varSpeed);
            st.varSpeedDir = 1.0f;
            st.varSpeedTimer = 0.0f;
            st.speedScale = st.varSpeed / 100.0f;
        }
        else
        {
            st.variableSpeed = false;
            st.speedScale = (float)speedMenuOrVar / 100.0f;
        }

        g_heliStates[carRef] = st;
        car->flags.isDualPatrol = true;
        escortVehicles.push_back(car);
        car->SetOwners();

        // Posiciona JA no ar (evita cair no chao ate o primeiro Update)
        {
            float radius = 75.0f * st.radiusScale;
            float height = 42.0f * st.heightScale;
            if (radius < 30.0f) radius = 30.0f;
            if (height < 35.0f) height = 35.0f; // minimo seguro acima do solo
            float x = center.x + radius;
            float y = center.y;
            float z = center.z + height;
            SetHeliWorldTransform(car, x, y, z, 0.0f, st.bankDeg, clockwise);
            // Reforca altura no state para o Update nao baixar demais
            st.heightScale = height / 42.0f;
            st.radiusScale = radius / 75.0f;
            g_heliStates[carRef] = st;
        }

        // Blip azul policial (flags; renderer do mod usa COLOR_POLICE)
        car->ShowBlip(COLOR_POLICE);

        g_bankRobberyHeliActive = true;
        g_bankRobberyHeliCarRef = carRef;

        fileLog->Log("DualPatrol: SpawnOrbitLockHeliAt OK");
        BottomMessage::SetMessage("~b~Aguia sobrevoando o local", 2500);
    });
}

void DualPatrol::StartBankHeliLeave()
{
    // Mesmo comportamento do auto heli fase 2: aumenta raio e altura ate sumir
    int carRef = g_bankRobberyHeliCarRef;
    if (carRef <= 0)
    {
        // tenta achar qualquer heli em orbit lock
        for (auto& kv : g_heliStates)
        {
            if (kv.second.mode == 2 && kv.second.fixedCenter)
            {
                carRef = kv.first;
                break;
            }
        }
    }
    if (carRef <= 0 || !CAR_DEFINED(carRef))
    {
        g_bankRobberyHeliActive = false;
        g_bankRobberyHeliCarRef = -1;
        return;
    }

    g_autoHeli.carRef = carRef;
    g_autoHeli.phase = 2; // saindo: sobe e abre raio
    g_autoHeli.timer = 0.0f;
    g_autoHeli.leaveRadiusBoost = 0.0f;
    g_autoHeli.leaveHeightBoost = 0.0f;
    g_bankRobberyHeliActive = false;
    g_bankRobberyHeliCarRef = -1;
    BottomMessage::SetMessage("~b~Aguia se afastando", 2500);
}
