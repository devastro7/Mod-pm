#pragma once

#include "../pch.h"
#include "CalloutBase.h"

#include "../AudioCollection.h"
#include "../BottomMessage.h"
#include "../ScriptTask.h"
#include "../CleoFunctions.h"
#include "../ModelLoader.h"
#include "../Peds.h"
#include "../Criminals.h"
#include "../Callouts.h"
#include "../Vehicles.h"
#include "../Escort.h"
#include "../Checkpoint.h"
#include "../DualPatrol.h"
#include "../PoliceVehicleData.h"

extern bool g_calloutReached;

class AirRescueCallout : public CalloutBase {
private:
    inline static Ped* g_injuredPed = nullptr;
    inline static std::vector<int> g_spectators;
    inline static Checkpoint* g_hospitalCheckpoint = nullptr;
    inline static bool g_goingToHospital = false;

    static constexpr float kHelicopterRadius = 12.0f;
    static constexpr float kHospitalRadius = 5.0f;

    static bool IsRescueHelicopterNearby()
    {
        auto playerPos = GetPlayerPosition();
        auto vehicles = Vehicles::GetAllCarsInSphere(playerPos, kHelicopterRadius);

        for (auto vehicle : vehicles)
        {
            if (!vehicle || !Vehicles::IsValid(vehicle)) continue;
            if (!CAR_DEFINED(vehicle->ref)) continue;

            int model = GET_CAR_MODEL(vehicle->ref);

            // 497 = Police Maverick (Águia). Também aceita qualquer
            // helicóptero cadastrado no sistema de viaturas policiais.
            if (model == 497 || IsModelAPoliceHelicopter(model))
                return true;
        }

        return false;
    }

    static void DestroySpectators()
    {
        for (int ref : g_spectators)
        {
            if (!ACTOR_DEFINED(ref)) continue;
            auto ped = Peds::GetPed(ref);
            if (ped)
                ped->QueueDestroy();
            else
                QueueDestroyPed(ref);
        }
        g_spectators.clear();
    }

public:
    std::string GetBroadcastMessage() override
    {
        return "Resgate aereo. Civil gravemente ferido necessita de transporte.";
    }

    AudioVariationGroup* GetBroadcastAudio() override
    {
        return nullptr;
    }

    int GetWeight() const override
    {
        return CALLOUT_WEIGHT_AIR_RESCUE;
    }

    int GetLevel() const override
    {
        return CALLOUT_LEVEL_AIR_RESCUE;
    }

    static void CleanupScene()
    {
        if (g_hospitalCheckpoint)
        {
            Checkpoints::DestroyCheckpoint(g_hospitalCheckpoint);
            g_hospitalCheckpoint = nullptr;
        }

        Escort::StopCarrying();
        DestroySpectators();

        if (g_injuredPed && Peds::IsValid(g_injuredPed))
        {
            g_injuredPed->flags.showWidget = false;
            g_injuredPed->HideBlip();
        }

        g_injuredPed = nullptr;
        g_goingToHospital = false;
    }

    void OnAccept() override
    {
        CleanupScene();

        BottomMessage::SetMessage(
            "~w~Resgate aereo solicitado. ~y~Pegue o Aguia e desloque-se ao local.",
            4000
        );

        const float CALLOUT_DISTANCE = 900.0f;
        auto playerActor = GET_PLAYER_ACTOR(0);

        float x = 0.0f, y = 0.0f, z = 0.0f;

        auto distX = getRandomNumber(-CALLOUT_DISTANCE, CALLOUT_DISTANCE);
        auto distY = getRandomNumber(-CALLOUT_DISTANCE, CALLOUT_DISTANCE);

        STORE_COORDS_FROM_ACTOR_WITH_OFFSET(
            playerActor,
            (float)distX,
            (float)distY,
            0.0f,
            &x,
            &y,
            &z
        );

        auto scenePosition = GET_CLOSEST_CAR_NODE(x, y, z);

        int approachMarker = CreateMarker(
            scenePosition.x,
            scenePosition.y,
            scenePosition.z,
            5,
            3,
            3
        );

        ScriptTask* taskApproach = new ScriptTask("air_rescue_approach");

        taskApproach->onBegin = []() {};

        taskApproach->onExecute = [scenePosition]() {
            auto playerPosition = GetPlayerPosition();
            auto distance = distanceBetweenPoints(playerPosition, scenePosition);

            if (distance > 150.0f)
                return SCRIPT_KEEP_GOING;

            return SCRIPT_SUCCESS;
        };

        taskApproach->onComplete = [approachMarker, scenePosition]() {
            g_calloutReached = true;
            DISABLE_MARKER(approachMarker);

            BottomMessage::SetMessage(
                "~r~Civil gravemente ferido no local.~w~ Preste socorro e leve-o ate o Aguia.",
                5000
            );

            // Civil ferido + espectadores.
            // Os modelos sao peds civis comuns, evitando policiais/criminosos.
            const int injuredModel = 7;
            static const int kSpectatorModels[] = {
                14, 15, 20, 21, 23, 29, 30, 41, 50, 60
            };

            const int spectatorCount = getRandomNumber(6, 10);

            ModelLoader::AddModelToLoad(injuredModel);
            for (int i = 0; i < spectatorCount; i++)
                ModelLoader::AddModelToLoad(kSpectatorModels[i]);

            ModelLoader::LoadAll([scenePosition, spectatorCount]() {
                // -------------------------------------------------
                // CIVIL FERIDO
                // -------------------------------------------------
                int injuredRef = CREATE_ACTOR_PEDTYPE(
                    PedType::CivMale,
                    7,
                    scenePosition.x,
                    scenePosition.y,
                    scenePosition.z
                );

                auto injured = Peds::RegisterPed(injuredRef);
                if (!injured)
                    return;

                g_injuredPed = injured;

                // Reutiliza exatamente a flag de ferido/inconsciente
                // já existente no sistema de Ped do mod.
                injured->flags.isInconcious = true;
                injured->flags.isFleeing = false;
                injured->flags.hasSurrended = false;
                injured->flags.willSurrender = true;
                injured->flags.willKillCops = false;
                injured->flags.showWidget = true;
                injured->flags.isBeingTreated = false;

                SET_ACTOR_HEALTH(injuredRef, 100);
                PERFORM_ANIMATION_AS_ACTOR(
                    injuredRef,
                    "crckdeth2",
                    "CRACK",
                    10.0f,
                    0,
                    0,
                    0,
                    1,
                    -1
                );

                // Entra na lista de criminosos somente para o sistema
                // de encerramento da ocorrência; AICriminal nao age
                // porque IsDeadOrInconcious() retorna true.
                Criminals::AddCriminal(injured);

                // -------------------------------------------------
                // TESTEMUNHAS / CURIOSOS
                // -------------------------------------------------
                for (int i = 0; i < spectatorCount; i++)
                {
                    const float angle = (360.0f / (float)spectatorCount) * i;
                    const float radius = 4.0f + (float)getRandomNumber(0, 3);
                    const float ox = cosf(angle * 0.0174532925f) * radius;
                    const float oy = sinf(angle * 0.0174532925f) * radius;

                    auto pos = STORE_PED_PATH_COORDS_CLOSEST_TO(
                        scenePosition.x + ox,
                        scenePosition.y + oy,
                        scenePosition.z
                    );

                    int model = kSpectatorModels[i];
                    int ref = CREATE_ACTOR_PEDTYPE(
                        (i % 3 == 0) ? PedType::CivFemale : PedType::CivMale,
                        model,
                        pos.x,
                        pos.y,
                        pos.z
                    );

                    auto spectator = Peds::RegisterPed(ref);
                    if (!spectator) continue;

                    spectator->flags.showWidget = false;
                    spectator->SetAnim("IDLE_stance", "PED");
                    FREEZE_CHAR_POSITION(ref, true);
                    spectator->PerformAnims();
                    g_spectators.push_back(ref);
                }

                // -------------------------------------------------
                // VIATURA DE APOIO + 3 PMs
                // Reutiliza o sistema de apoio/comboio existente.
                // -------------------------------------------------
                PoliceVehicleData support;
                support.name = "Apoio Resgate";
                support.vehicleModelId = 596;
                support.skinModelId = 280;
                support.occupants = 3;
                support.chance = 1.0f;

                DualPatrol::SpawnEscortUnit(&support, false, &scenePosition, true);
            });
        };

        taskApproach->Start();
    }

    // Deve ser chamado a cada frame enquanto esta ocorrencia estiver ativa.
    static void UpdateScene()
    {
        if (!g_injuredPed || !Peds::IsValid(g_injuredPed))
            return;

        if (g_goingToHospital)
        {
            if (!g_hospitalCheckpoint)
                return;

            g_hospitalCheckpoint->CheckEntered(GetPlayerPosition());
            return;
        }

        // A opcao de carregar aparece pelo widget normal do Ped.
        // Quando o civil estiver sendo carregado, procure o Aguia proximo.
        if (Escort::IsPedBeeingCarried(g_injuredPed) && IsRescueHelicopterNearby())
        {
            Escort::StopCarrying();

            g_injuredPed->flags.isBeingTreated = true;
            g_injuredPed->flags.showWidget = false;
            g_injuredPed->ClearAnim();

            BottomMessage::SetMessage(
                "~b~Civil embarcado no Aguia.~w~ Leve-o ao Hospital de San Fierro.",
                5000
            );

            const CVector hospitalPosition(
                -2653.11f,
                634.78f,
                14.45f
            );

            g_hospitalCheckpoint = Checkpoints::CreateCheckpoint(hospitalPosition);
            g_hospitalCheckpoint->radius = kHospitalRadius;
            g_hospitalCheckpoint->onEnterCheckpoint = []() {
                if (!g_injuredPed || !Peds::IsValid(g_injuredPed))
                    return;

                if (g_hospitalCheckpoint)
                {
                    Checkpoints::DestroyCheckpoint(g_hospitalCheckpoint);
                    g_hospitalCheckpoint = nullptr;
                }

                g_injuredPed->flags.showWidget = false;
                g_injuredPed->flags.isBeingTreated = true;

                DestroySpectators();

                g_customCalloutEndMessage = "Civil entregue ao hospital";

                auto injured = g_injuredPed;
                g_injuredPed = nullptr;
                g_goingToHospital = true;

                Escort::StopCarrying();
                Criminals::RemoveCriminal(injured);
                injured->QueueDestroy();

                g_goingToHospital = false;
            };

            g_goingToHospital = true;
        }
    }
};
