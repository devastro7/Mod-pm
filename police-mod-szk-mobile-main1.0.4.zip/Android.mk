LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := PoliceModSZK

LOCAL_CPP_EXTENSION := .cpp .cc
LOCAL_CPP_FEATURES := exceptions rtti
LOCAL_CPPFLAGS += -std=c++20
LOCAL_CFLAGS += -O2 -DNDEBUG -DANDROID

LOCAL_SRC_FILES := \
    src/main.cpp \
    src/hooks.cpp \
    src/AIController.cpp \
    src/AICop.cpp \
    src/AICriminal.cpp \
    src/AIHelicopterCop.cpp \
    src/AIMedic.cpp \
    src/AIFireman.cpp \
    src/AIPed.cpp \
    src/AIVehicle.cpp \
    src/ATMSystem.cpp \
    src/AudioCollection.cpp \
    src/AudioSequence.cpp \
    src/AudioVariationGroup.cpp \
    src/BackupUnits.cpp \
    src/Biqueiras.cpp \
    src/BottomMessage.cpp \
    src/DispatchPanel.cpp \
    src/FriskPanel.cpp \
    src/NotifStack.cpp \
    src/CNHWindow.cpp \
    src/Callouts.cpp \
    src/Chase.cpp \
    src/Checkpoint.cpp \
    src/CleoFunctions.cpp \
    src/Criminals.cpp \
    src/DocsWindow.cpp \
    src/DualPatrol.cpp \
    src/DocumentWindow.cpp \
    src/Escort.cpp \
    src/FriskWindow.cpp \
    src/Inventory.cpp \
    src/InventoryItemManager.cpp \
    src/Logger.cpp \
    src/ModData.cpp \
    src/ModPolicia.cpp \
    src/ModelLoader.cpp \
    src/Names.cpp \
    src/NearbyStolenSystem.cpp \
    src/OptionsWindow.cpp \
    src/Partners.cpp \
    src/Ped.cpp \
    src/Peds.cpp \
    src/PoliceBase.cpp \
    src/PoliceBases.cpp \
    src/PoliceMod.cpp \
    src/PoliceVehicles.cpp \
    src/Pullover.cpp \
    src/Conversas.cpp \
    src/Bafometro.cpp \
    src/RGWindow.cpp \
    src/RadioSounds.cpp \
    src/RadioConfigWindow.cpp \
    src/CalloutConfigWindow.cpp \
    src/RadioWindow.cpp \
    src/ScriptTask.cpp \
    src/TestWindow.cpp \
    src/TicketWindow.cpp \
    src/TopMessage.cpp \
    src/TrafficControl.cpp \
    src/RadioExtrasWindow.cpp \
    src/Trunk.cpp \
    src/Vehicle.cpp \
    src/Vehicles.cpp \
    src/WorldWidgets.cpp \
    src/callouts/ATMCallout.cpp \
    src/callouts/AirRescueCallout.cpp \
    src/callouts/DrugDealerCallout.cpp \
    src/callouts/HomeInvasionCallout.cpp \
    src/callouts/KidnapCallout.cpp \
    src/callouts/BankRobberyCallout.cpp \
    src/callouts/StolenCarCallout.cpp \
    src/callouts/WantedSearchCallout.cpp \
    src/callouts/ShootoutCallout.cpp \
    src/callouts/FavelaShootoutCallout.cpp \
    src/callouts/TestCallout.cpp \
    aml/mod/logger.cpp \
    aml/mod/config.cpp

LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/include \
    $(LOCAL_PATH)/aml \
    $(LOCAL_PATH)/src \
    $(LOCAL_PATH)

LOCAL_LDLIBS := -llog

include $(BUILD_SHARED_LIBRARY)
